# Privacy Policy

mediator reklam, hesap, analitik veya kullanici takibi icermez.

Uygulama su ag isteklerini yapar:

- TV kanal listeleri icin iptv-org API.
- Radyo kanal listeleri icin Radio Browser API.
- Oynatilan kanal veya radyo stream adresleri.
- Guncelleme kontrolu icin `update.json`.

Favoriler, son kanal, kanal sirasi ve ayarlar cihaz uzerinde yerel olarak saklanir. Bu bilgiler uygulama tarafindan herhangi bir sunucuya gonderilmez.
