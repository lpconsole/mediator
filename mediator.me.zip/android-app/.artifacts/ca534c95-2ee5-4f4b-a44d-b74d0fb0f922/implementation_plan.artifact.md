# UI Refactor: Side Navigation Panel

Refactor the main screen UI to implement a dual-block side navigation panel as per the user's sketch. The layout will consist of a far-left icon rail and a secondary channel list, both overlaying the background player.

## User Review Required

> [!IMPORTANT]
> The side menu will be structured into two distinct vertical blocks:
> 1. **Block 1 (Navigation Rail):** Narrow vertical bar with Search, TV, Radio, and Settings icons.
> 2. **Block 2 (Content List):** Dynamic list showing channels based on the selected type (TV/Radio).

## Proposed Changes

### [app]

#### [MODIFY] [SideMenu.kt](file:///C:/OSPanel/domains/mediator.me/android-app/app/src/main/java/com/lpconsole/mediator/ui/features/main/SideMenu.kt)
- Redesign to be a slim navigation rail.
- Implement icons in the specific order: Search (top), TV, Radio, and Settings (bottom).
- Remove the text-expansion logic to keep it as a "rail" of circles/icons.

#### [MODIFY] [ChannelList.kt](file:///C:/OSPanel/domains/mediator.me/android-app/app/src/main/java/com/lpconsole/mediator/ui/features/main/ChannelList.kt)
- Adjust styling to seamlessly align with the SideMenu rail.
- Ensure proper focus handling when navigating between the rail and the list.

#### [MODIFY] [MainScreen.kt](file:///C:/OSPanel/domains/mediator.me/android-app/app/src/main/java/com/lpconsole/mediator/ui/features/main/MainScreen.kt)
- Update the layout structure to wrap both `SideMenu` and `ChannelList` into a single logical "Side Panel" overlay.

## Verification Plan

### Manual Verification
- Deploy to a TV device/emulator.
- Verify that the Search icon is at the top and Settings is at the bottom.
- Check that the Channel List appears next to the icons.
- Verify that the player background is visible behind the entire navigation area.
- Test navigation: moving left from the list should focus the rail, and moving right from the rail should focus the list.
