# MediatorApi ve ChannelRepository Hatalarını Düzeltme

Kullanıcı `MediatorApi.kt` dosyasına bazı eklemeler yapmış ancak Retrofit ve Kotlin sözdizimi kurallarına uymayan bazı hatalar oluşmuş. Bu plan, bu hataları gidermeyi ve API yapısını kullanıcı yorumlarındaki isteğe uygun hale getirmeyi amaçlar.

## Kullanıcı İncelemesi Gerekenler

- **Radyo Sunucusu Seçimi:** Şu anki kodda radyo kanalları için "DE" (Almanya) sunucusu varsayılan olarak kullanılacak şekilde ayarlanacak. Gelecekte bunu dinamik hale getirmek isterseniz `getChannels` fonksiyonuna bir parametre eklenebilir.

## Önerilen Değişiklikler

### Ağ ve Veri Katmanı

#### [MODIFY] [MediatorApi.kt](file:///C:/OSPanel/domains/mediator.me/android-app/app/src/main/java/com/lpconsole/mediator/data/remote/api/MediatorApi.kt)
- `@GET` anotasyonlarındaki tam URL'leri temizle (Base URL zaten `NetworkModule` içinde tanımlı).
- `getRadioChannels` fonksiyonuna `@Url` parametresi ekle.
- Geçersiz `RADIO_SERVERS[DE]` kullanımını kaldır.
- Yardımcı bir `getRadioUrl` fonksiyonu ekle (isteğe bağlı ama temizlik için iyi olur).

#### [MODIFY] [ChannelRepository.kt](file:///C:/OSPanel/domains/mediator.me/android-app/app/src/main/java/com/lpconsole/mediator/data/remote/ChannelRepository.kt)
- `refreshChannels` içinde radyo kanallarını çekerken tam URL'yi oluştur ve API'ye pasla.

## Doğrulama Planı

### Otomatik Testler
- Projeyi derleyerek derleme hatalarının (Compilation Error) giderildiğini kontrol et.

### Manuel Doğrulama
- Uygulamayı çalıştırarak TV ve Radyo kanallarının başarıyla yüklenip yüklenmediğini kontrol et.
