plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.google.ksp)
}

val appName = "MediaTor"
val appVersionName = "1.0.0"
val appVersionCode = 18
val supportMail = "supportmediator@gmail.com"
val githubRepository = "lpconsole/mediator"
val gClientId = ""

android {
    namespace = "com.lpconsole.mediator"
    compileSdk = 37
    defaultConfig {
        applicationId = "com.lpconsole.mediator"
        minSdk = 26
        //noinspection OldTargetApi
        targetSdk = 36
        versionCode = appVersionCode
        versionName = appVersionName
        buildConfigField("String", "APP_NAME", "\"$appName\"")
        buildConfigField("String", "VERSION_CODE", "\"$appVersionCode\"")
        buildConfigField("String", "VERSION_NAME", "\"$appVersionName\"")
        buildConfigField("String", "GITHUB_REPOSITORY", "\"$githubRepository\"")
        buildConfigField("String", "GCLIENT_ID", "\"$gClientId\"")
        buildConfigField("String", "SUPPORT_MAIL", "\"$supportMail\"")
        buildConfigField("String", "USER_AGENT", "\"Mediator/$appVersionName ($appVersionCode)\"")
    }
    buildFeatures {
        buildConfig = true
        compose = true
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

tasks.register("publishDebugUpdate") {
    // ... (unchanged)
}

tasks.register("publishReleaseUpdate") {
    // ... (unchanged)
}

tasks.matching { it.name == "assembleDebug" }.configureEach {
    finalizedBy("publishDebugUpdate")
}

tasks.matching { it.name == "assembleRelease" }.configureEach {
    finalizedBy("publishReleaseUpdate")
}

dependencies {
    implementation(libs.androidx.compose.foundation.layout)
    implementation(libs.androidx.compose.ui.test)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.media)
    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.exoplayer.hls)
    implementation(libs.androidx.media3.datasource.okhttp)
    implementation(libs.androidx.media3.ui)
    implementation(libs.androidx.media3.session)
    implementation(libs.androidsvg.aar)
    // TV Material
    implementation(libs.androidx.tv.material)
    implementation(libs.androidx.tv.foundation)
    // Hilt Dependency Injection
    implementation(libs.hilt.android)
    ksp(libs.hilt.android.compiler)
    implementation(libs.androidx.hilt.navigation.compose)
    // Room Database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    // Networking
    implementation(libs.retrofit)
    implementation(libs.converter.gson)
    implementation(libs.logging.interceptor)
    // Image Loading
    implementation(libs.coil.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.compose.icons.extended)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
