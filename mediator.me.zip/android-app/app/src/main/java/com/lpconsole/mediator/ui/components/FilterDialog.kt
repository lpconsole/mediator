package com.lpconsole.mediator.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.ui.theme.GlassBackground
import com.lpconsole.mediator.ui.theme.Primary

@Composable
fun FilterDialog(
    countries: List<String>,
    categories: List<String>,
    selectedCountry: String,
    selectedCategory: String,
    sortMode: String,
    hideNsfw: Boolean,
    onCountrySelect: (String) -> Unit,
    onCategorySelect: (String) -> Unit,
    onSortSelect: (String) -> Unit,
    onNsfwToggle: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.7f))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .width(800.dp)
                .fillMaxHeight(0.8f)
                .clip(RoundedCornerShape(24.dp))
                .background(GlassBackground)
                .clickable(enabled = false) {}
                .padding(32.dp)
        ) {
            Column {
                Text(
                    text = "Filter & Sort",
                    color = Primary,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(modifier = Modifier.fillMaxSize()) {
                    // Countries
                    FilterSection(
                        title = "Country",
                        items = countries,
                        selected = selectedCountry,
                        onSelect = onCountrySelect,
                        modifier = Modifier.weight(1f)
                    )
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    // Categories
                    FilterSection(
                        title = "Category",
                        items = categories,
                        selected = selectedCategory,
                        onSelect = onCategorySelect,
                        modifier = Modifier.weight(1f)
                    )
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    // Sort & NSFW
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Sort Mode", color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        val sorts = listOf(Prefs.SORT_NAME, Prefs.SORT_COUNTRY, Prefs.SORT_POPULAR)
                        sorts.forEach { sort ->
                            FilterItem(
                                text = sort,
                                isSelected = sort == sortMode,
                                onClick = { onSortSelect(sort) }
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        Text(text = "Safety", color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        FilterItem(
                            text = if (hideNsfw) "NSFW Hidden" else "NSFW Shown",
                            isSelected = false,
                            onClick = { onNsfwToggle(!hideNsfw) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FilterSection(
    title: String,
    items: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(text = title, color = Color.White.copy(alpha = 0.5f), fontSize = 16.sp)
        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn(
            modifier = Modifier.fillMaxHeight(),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(items) { item ->
                FilterItem(
                    text = item,
                    isSelected = item == selected,
                    onClick = { onSelect(item) }
                )
            }
        }
    }
}

@Composable
fun FilterItem(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
                when {
                    isFocused -> Primary.copy(alpha = 0.2f)
                    isSelected -> Primary.copy(alpha = 0.1f)
                    else -> Color.White.copy(alpha = 0.05f)
                }
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            text = text,
            color = if (isFocused || isSelected) Primary else Color.White,
            fontSize = 16.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
