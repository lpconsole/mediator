package com.lpconsole.mediator.ui.features.main.logic

import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.data.remote.ChannelRepository
import com.lpconsole.mediator.data.remote.models.CountryDto
import javax.inject.Inject

class ChannelManager @Inject constructor(
    private val repository: ChannelRepository
) {
    val syncStatus = repository.syncStatus
    val syncProgressFraction = repository.syncProgressFraction
    val syncError = repository.syncError
    val isSyncActive = repository.isSyncActive

    private var allChannels = emptyList<Channel>()

    suspend fun startInitialSync(initialType: String, force: Boolean = false) {
        repository.startInitialSync(initialType, force)
    }

    suspend fun triggerBackgroundGlobalSync() {
        repository.triggerBackgroundGlobalSync()
    }

    suspend fun getCountriesList(): List<CountryDto> {
        return repository.getCountriesList()
    }

    suspend fun getExpectedTotalCount(type: String, selectedCountries: Set<String>): Int {
        return repository.getExpectedTotalCount(type, selectedCountries)
    }

    suspend fun getChannels(
        type: String, 
        country: String = "", 
        category: String = "", 
        sortMode: String = "DEFAULT", 
        favoritesOnly: Boolean = false, 
        recentsOnly: Boolean = false, 
        hideNsfw: Boolean = true, 
        forceRefresh: Boolean = false
    ): List<Channel> {
        return repository.getChannels(type, country, category, sortMode, favoritesOnly, recentsOnly, hideNsfw, forceRefresh)
    }

    suspend fun getChannelsPaged(type: String, country: String, category: String, sortMode: String, favoritesOnly: Boolean, recentsOnly: Boolean, hideNsfw: Boolean, limit: Int, offset: Int): List<Channel> {
        return repository.getChannelsPaged(type, country, category, sortMode, favoritesOnly, recentsOnly, hideNsfw, limit, offset)
    }

    suspend fun getTotalCount(type: String, country: String, category: String, favoritesOnly: Boolean, recentsOnly: Boolean): Int {
        return repository.getTotalCount(type, country, category, favoritesOnly, recentsOnly)
    }

    suspend fun updateLastViewed(channelId: String) {
        repository.updateLastViewed(channelId)
    }

    suspend fun clearRecents() {
        repository.clearRecents()
    }

    suspend fun getFilterOptions(type: String): Pair<List<String>, List<String>> {
        return repository.getFilterOptions(type)
    }

    suspend fun getChannelById(id: String): Channel? {
        return repository.getChannelById(id)
    }

    suspend fun search(query: String, type: String?): List<Channel> {
        return repository.search(query, type)
    }

    suspend fun searchGlobal(query: String): List<Channel> {
        return repository.searchGlobal(query)
    }

    suspend fun toggleFavorite(channelId: String, isFavorite: Boolean) {
        repository.setFavorite(channelId, isFavorite)
    }

    suspend fun swapOrder(c1: Channel, c2: Channel) {
        repository.swapOrder(c1, c2)
    }

    suspend fun refreshChannels(type: String) {
        repository.getChannels(type, forceRefresh = true)
    }

    suspend fun syncBackupStreams(force: Boolean = false) {
        repository.syncBackupStreams(force)
    }

    fun filterChannels(query: String): List<Channel> {
        if (query.isEmpty()) return allChannels
        return allChannels.filter { it.name.contains(query, ignoreCase = true) }
    }
}
