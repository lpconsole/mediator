package com.lpconsole.mediator.ui.features.main

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.annotation.OptIn
import androidx.core.content.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import com.lpconsole.mediator.BuildConfig
import com.lpconsole.mediator.LyricsProvider
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.RadioPosterCatalog
import com.lpconsole.mediator.TvProgramGuide
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.ui.features.main.logic.ChannelManager
import com.lpconsole.mediator.ui.features.main.logic.PlaybackService
import com.lpconsole.mediator.ui.features.main.logic.PlayerManager
import com.lpconsole.mediator.ui.features.settings.logic.SettingsManager
import com.lpconsole.mediator.util.GitHubManager
import com.lpconsole.mediator.util.LogoManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import kotlin.time.Duration.Companion.milliseconds

@HiltViewModel
class MainViewModel @Inject constructor(
    application: Application,
    private val channelManager: ChannelManager,
    private val playerManager: PlayerManager,
    val settingsManager: SettingsManager,
    private val gitHubManager: GitHubManager,
    val logoManager: LogoManager
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()
    private var autoHideJob: Job? = null
    private var infoHideJob: Job? = null
    private var zapHideJob: Job? = null
    private var zapPlaybackJob: Job? = null
    private var programInfoJob: Job? = null
    private var lastErrorZapTimeMs: Long = 0L
    private var isStartupComplete = false
    private val tvProgramGuide = TvProgramGuide()
    val player get() = playerManager.player

    init {
        playerManager.setOnWaveformData { amplitudes ->
            if (_uiState.value.currentType == Prefs.TYPE_FM &&
                _uiState.value.selectedPosterCode.equals("visualizer", ignoreCase = true)
            ) {
                _uiState.update { it.copy(audioAmplitudes = amplitudes) }
            }
        }
        val prefs = getApplication<Application>().getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        val isFirstRun = prefs.getBoolean(Prefs.KEY_IS_FIRST_RUN, true)
        _uiState.update { it.copy(isFirstRun = isFirstRun) }
        syncSettings()
        resetAutoHideTimer()

        // Observe Sync Progress - Do it even on first run so we can see progress
        viewModelScope.launch {
            channelManager.syncStatus.collect { status ->
                _uiState.update { it.copy(SYNC_PROGRESS = status) }
                if (isStartupComplete && status.isEmpty() && _uiState.value.channels.isEmpty() && !_uiState.value.isFirstRun) {
                    loadChannels(_uiState.value.currentType)
                }
            }
        }
        viewModelScope.launch {
            channelManager.syncProgressFraction.collect { fraction ->
                _uiState.update { it.copy(syncProgressFraction = fraction) }
            }
        }
        viewModelScope.launch {
            channelManager.syncError.collect { error ->
                _uiState.update { it.copy(syncError = error) }
            }
        }
        viewModelScope.launch {
            channelManager.isSyncActive.collect { isActive ->
                _uiState.update { it.copy(isSyncActive = isActive) }
            }
        }

        // Fetch countries for setup wizard
        viewModelScope.launch {
            val countries = channelManager.getCountriesList()
            _uiState.update { it.copy(countryList = countries) }
        }

        playerManager.setOnErrorAction {
            val now = System.currentTimeMillis()
            if (now - lastErrorZapTimeMs < 2000L) {
                return@setOnErrorAction
            }
            lastErrorZapTimeMs = now
            val currentChannel = _uiState.value.CURRENT_CHANNEL
            val streamUrl = playerManager.getCurrentStreamUrl()?.takeIf { it.isNotBlank() } ?: "(Yayın URL'si yok)"
            val channelName = currentChannel?.name ?: "Kanal"
            if (_uiState.value.autoSkipBroken) {
                _uiState.update { it.copy(playbackError = "$channelName açılamadı!\nStream: $streamUrl\nOtomatik sonraki kanala geçiliyor...") }
                viewModelScope.launch {
                    delay(5000.milliseconds)
                    _uiState.update { it.copy(playbackError = null) }
                }
                zapNext()
            } else {
                _uiState.update { it.copy(playbackError = "$channelName yüklenemedi.\nStream: $streamUrl") }
                viewModelScope.launch {
                    delay(6000.milliseconds)
                    _uiState.update { it.copy(playbackError = null) }
                }
            }
        }

        playerManager.setOnStateChange { isBuffering ->
            _uiState.update { it.copy(isBuffering = isBuffering) }
            if (!isBuffering) {
                updateTracks()
            }
        }

        var lastProcessedMetadata: String? = null
        playerManager.setOnMetadataChange { metadata, artwork ->
            if (metadata == _uiState.value.nowPlayingMetadata && artwork == _uiState.value.nowPlayingArtwork) {
                return@setOnMetadataChange
            }
            songStartSystemTimeMs = System.currentTimeMillis()
            _uiState.update { it.copy(nowPlayingMetadata = metadata, nowPlayingArtwork = artwork) }
            if (_uiState.value.isLyricsVisible) {
                fetchLyrics()
            }
            val channelName = _uiState.value.CURRENT_CHANNEL?.name ?: "MediaTor"
            playerManager.updateMediaSessionMetadata()
            if (_uiState.value.currentType == Prefs.TYPE_FM && !metadata.isNullOrBlank() && metadata != lastProcessedMetadata) {
                lastProcessedMetadata = metadata
                viewModelScope.launch {
                    val iTunesArtwork = logoManager.fetchITunesArtwork(channelName, metadata)
                    if (!iTunesArtwork.isNullOrEmpty() && iTunesArtwork != _uiState.value.nowPlayingArtwork) {
                        _uiState.update { it.copy(nowPlayingArtwork = iTunesArtwork) }
                        playerManager.updateMediaSessionMetadata()
                    }
                }
            }
        }

        playerManager.setOnZapRequest { direction ->
            if (direction > 0) zapNext() else zapPrevious()
        }

        playerManager.setOnStreamIndexChanged { index ->
            _uiState.update { it.copy(selectedStreamIndex = index) }
        }
        
        // --- ULTRA FAST INSTANT STARTUP SEQUENCE ---
        viewModelScope.launch {
            val startupMode = withContext(Dispatchers.IO) { settingsManager.getStartupMode() }
            val initialType = when (startupMode) {
                "LAST" -> {
                    withContext(Dispatchers.IO) { settingsManager.getLastType() }
                }
                "FM" -> {
                    Prefs.TYPE_FM
                }
                else -> {
                    Prefs.TYPE_TV
                }
            }
            _uiState.update { it.copy(currentType = initialType) }
            if (_uiState.value.isFirstRun) {
                isStartupComplete = true
                return@launch
            }
            // STEP 1: IMMEDIATE RESUME FROM ROOM DB (Sub-100ms)
            val lastIdForType = withContext(Dispatchers.IO) { settingsManager.getLastChannelId(initialType) }
            val channel = if (lastIdForType != null) withContext(Dispatchers.IO) { channelManager.getChannelById(lastIdForType) } else null
            
            withContext(Dispatchers.Main) {
                if (channel != null && channel.streams.isNotEmpty()) {
                    selectChannel(channel)
                } else {
                    // Channel was removed/deleted from list or doesn't exist
                    val chs = withContext(Dispatchers.IO) { channelManager.getChannels(initialType) }
                    val fallback = chs.firstOrNull()
                    if (fallback != null) {
                        if (lastIdForType != null) {
                            _uiState.update { it.copy(playbackError = "İzlediğiniz kanal kullanımdan kaldırıldı. Başka bir kanala geçiliyor...") }
                            viewModelScope.launch {
                                delay(5000.milliseconds)
                                _uiState.update { it.copy(playbackError = null) }
                            }
                        }
                        selectChannel(fallback)
                    }
                }
            }

            // STEP 2: LOAD LIST IN BACKGROUND
            loadChannels(initialType)
            isStartupComplete = true

            // Defer update and backup check so startup is instant
            viewModelScope.launch(Dispatchers.IO) {
                channelManager.syncBackupStreams(force = false)
            }
            delay(5000.milliseconds)
            checkUpdate()
        }
    }

    fun resumePlaybackIfNeeded() {
        val current = _uiState.value.CURRENT_CHANNEL ?: return
        val state = playerManager.player.playbackState
        if (state == Player.STATE_IDLE || state == Player.STATE_ENDED) {
            playerManager.play(current)
        }
    }

    private fun syncSettings() {
        viewModelScope.launch {
            val (posters, code) = withContext(Dispatchers.IO) {
                val rawPosters = settingsManager.getAvailablePosters()
                val visualizerPoster = RadioPosterCatalog.Poster(
                    code = "visualizer",
                    label = "Ses Görselleştirici",
                    downloadUrl = ""
                )
                val mergedPosters = rawPosters.filter { !it.code.equals("visualizer", ignoreCase = true) } + visualizerPoster
                val selectedCode = settingsManager.getSelectedPosterCode()
                val startupMode = settingsManager.getStartupMode()
                val videoScale = settingsManager.getVideoScale()
                val autoSkipBroken = settingsManager.getAutoSkipBroken()
                val autoHideSeconds = settingsManager.getAutoHideSeconds()
                val countryScope = settingsManager.getCountryScope()
                val hideNsfw = settingsManager.getHideNsfw()
                val selectedRadioServer = settingsManager.getRadioServer()
                _uiState.update { state ->
                    state.copy(
                        startupMode = startupMode,
                        videoScale = videoScale,
                        autoSkipBroken = autoSkipBroken,
                        autoHideSeconds = autoHideSeconds,
                        countryScope = countryScope,
                        hideNsfw = hideNsfw,
                        selectedPosterCode = selectedCode,
                        selectedRadioServer = selectedRadioServer,
                        availablePosters = mergedPosters
                    )
                }
                mergedPosters to selectedCode
            }
            updateRadioPoster(posters, code)
        }
    }

    @OptIn(UnstableApi::class)
    private fun updateRadioPoster(posters: List<RadioPosterCatalog.Poster>, code: String) {
        if (code.equals("visualizer", ignoreCase = true)) {
            _uiState.update { it.copy(radioPoster = null, isRadioPosterLoading = false) }
            startVisualizer()
            return
        }
        stopVisualizer()
        viewModelScope.launch {
            val selected = gitHubManager.selectedPoster(posters, code)
            if (selected != null) {
                try {
                    _uiState.update { it.copy(isRadioPosterLoading = true) }
                    // Cleanup old unneeded poster caches in background
                    withContext(Dispatchers.IO) {
                        try {
                            gitHubManager.cleanupOldPosterCaches(posters)
                        } catch (e: Exception) { e.printStackTrace() }
                    }
                    val file = gitHubManager.downloadRadioPoster(selected)
                    _uiState.update { it.copy(radioPoster = file, isRadioPosterLoading = false) }
                } catch (e: Exception) {
                    e.printStackTrace()
                    _uiState.update { it.copy(isRadioPosterLoading = false) }
                }
            }
        }
    }

    fun startVisualizer() {
        val shouldEnable = _uiState.value.currentType == Prefs.TYPE_FM &&
            _uiState.value.selectedPosterCode.equals("visualizer", ignoreCase = true)
        playerManager.isVisualizerEnabled = shouldEnable
        if (!shouldEnable) {
            _uiState.update { it.copy(audioAmplitudes = null) }
        }
    }

    fun stopVisualizer() {
        playerManager.isVisualizerEnabled = false
        _uiState.update { it.copy(audioAmplitudes = null) }
    }

    private fun updateTracks() {
        val tracks = playerManager.player.currentTracks
        val audio = mutableListOf<String>()
        val subs = mutableListOf<String>()
        tracks.groups.forEach { group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    audio.add(format.language ?: "Ses ${audio.size + 1}")
                }
            } else if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    subs.add(format.language ?: "Altyazı ${subs.size + 1}")
                }
            }
        }
        _uiState.update { it.copy(audioTracks = audio, subtitleTracks = subs) }
    }

    fun toggleTrackSelector() {
        val newState = !_uiState.value.isTrackSelectorVisible
        _uiState.update { 
            it.copy(
                isTrackSelectorVisible = newState,
                isMenuVisible = false
            ) 
        }
        if (newState) {
            updateTracks() // Ensure tracks are fresh before opening
            autoHideJob?.cancel() 
        } else {
            resetAutoHideTimer()
        }
    }

    fun selectStream(index: Int) {
        playerManager.switchStream(index)
        _uiState.update { it.copy(selectedStreamIndex = index) }
    }

    fun selectAudioTrack(index: Int) {
        val tracks = playerManager.player.currentTracks
        var audioGroupIndex = -1
        var count = 0
        tracks.groups.forEachIndexed { i, group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
                if (count == index) {
                    audioGroupIndex = i
                    return@forEachIndexed
                }
                count++
            }
        }
        if (audioGroupIndex != -1) {
            playerManager.selectTrack(audioGroupIndex, 0) // Select first track in group
            _uiState.update { it.copy(selectedAudioIndex = index) }
        }
    }

    fun selectSubtitleTrack(index: Int) {
        val tracks = playerManager.player.currentTracks
        var subGroupIndex = -1
        var count = 0
        tracks.groups.forEachIndexed { i, group ->
            if (group.type == C.TRACK_TYPE_TEXT) {
                if (count == index) {
                    subGroupIndex = i
                    return@forEachIndexed
                }
                count++
            }
        }
        if (subGroupIndex != -1) {
            playerManager.selectTrack(subGroupIndex, 0)
            playerManager.player.trackSelectionParameters = playerManager.player.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .build()
            _uiState.update { it.copy(selectedSubtitleIndex = index) }
        } else if (index == -1) {
            // Disable subtitles
            playerManager.player.trackSelectionParameters = playerManager.player.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            _uiState.update { it.copy(selectedSubtitleIndex = -1) }
        }
    }

    fun onInteraction() {
        if (_uiState.value.isLyricsVisible || 
            _uiState.value.isSettingsVisible || 
            _uiState.value.isSearchVisible || 
            _uiState.value.isTrackSelectorVisible ||
            _uiState.value.isFilterDialogVisible) {
            return
        }
        if (!_uiState.value.isMenuVisible) {
            _uiState.update { it.copy(isMenuVisible = true) }
        }
        showInfo()
        resetAutoHideTimer()
    }

    private fun resetAutoHideTimer() {
        autoHideJob?.cancel()
        val seconds = _uiState.value.autoHideSeconds
        if (seconds <= 0) return
        // Don't hide if user is in a dialog or typing search or editing
        if (_uiState.value.isSettingsVisible || 
            _uiState.value.isSearchVisible || 
            _uiState.value.isTrackSelectorVisible ||
            _uiState.value.isFilterDialogVisible ||
            _uiState.value.isEditMode) return
        autoHideJob = viewModelScope.launch {
            delay((seconds * 1000L).milliseconds)
            if (!_uiState.value.isSettingsVisible && 
                !_uiState.value.isSearchVisible && 
                !_uiState.value.isTrackSelectorVisible &&
                !_uiState.value.isFilterDialogVisible &&
                !_uiState.value.isEditMode) {
                _uiState.update { it.copy(isMenuVisible = false) }
            }
        }
    }

    fun showInfo() {
        infoHideJob?.cancel()
        _uiState.update { it.copy(isInfoVisible = true) }
        infoHideJob = viewModelScope.launch {
            delay(8000.milliseconds) // Increased from 4000
            _uiState.update { it.copy(isInfoVisible = false) }
        }
    }

    fun enterDigit(digit: Int) {
        val currentZap = _uiState.value.zapNumber
        val newZap = if (currentZap.length >= 4) {
            digit.toString()
        } else {
            currentZap + digit
        }
        _uiState.update { it.copy(zapNumber = newZap) }
        zapHideJob?.cancel()
        zapHideJob = viewModelScope.launch {
            delay(2200.milliseconds)
            val channelIndex = newZap.toIntOrNull() ?: 0
            if (channelIndex > 0) {
                jumpToIndex(channelIndex - 1)
            }
            _uiState.update { it.copy(zapNumber = "") }
        }
    }

    private fun jumpToIndex(index: Int) {
        val list = _uiState.value.channels
        if (index < list.size) {
            selectChannel(list[index])
        }
    }

    fun zapNext() {
        val current = _uiState.value.CURRENT_CHANNEL ?: return
        val list = _uiState.value.channels
        val index = list.indexOfFirst { it.id == current.id }
        if (index != -1 && index < list.size - 1) {
            selectChannel(list[index + 1])
        } else if (index == list.size - 1) {
            loadMore()
        }
    }

    fun zapPrevious() {
        val current = _uiState.value.CURRENT_CHANNEL ?: return
        val list = _uiState.value.channels
        val index = list.indexOfFirst { it.id == current.id }
        if (index > 0) {
            selectChannel(list[index - 1])
        }
    }

    fun startSyncForType(selectedCountries: Set<String>, type: String, onReady: () -> Unit = {}) {
        viewModelScope.launch {
            _uiState.update { 
                it.copy(
                    isSyncActive = true,
                    syncError = null,
                    SYNC_PROGRESS = if (type == Prefs.TYPE_TV) "TV sunucusuna bağlanılıyor..." else "Radyo sunucusuna bağlanılıyor...",
                    syncProgressFraction = 0.05f
                ) 
            }
            try {
                val prefs = getApplication<Application>().getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
                val preferredCountry = if (selectedCountries.contains("ALL")) "TR" else (selectedCountries.firstOrNull() ?: "TR")
                settingsManager.setDefaultCountry(Prefs.TYPE_TV, preferredCountry)
                settingsManager.setDefaultCountry(Prefs.TYPE_FM, preferredCountry)
                prefs.edit { putStringSet("selected_countries", selectedCountries) }

                val expected = channelManager.getExpectedTotalCount(type, selectedCountries)
                if (type == Prefs.TYPE_TV) {
                    _uiState.update { it.copy(expectedTvCount = expected) }
                } else {
                    _uiState.update { it.copy(expectedRadioCount = expected) }
                }

                channelManager.startInitialSync(type, force = true)

                val tvCount = channelManager.getTotalCount(Prefs.TYPE_TV, "", "", favoritesOnly = false, recentsOnly = false)
                val radioCount = channelManager.getTotalCount(Prefs.TYPE_FM, "", "", favoritesOnly = false, recentsOnly = false)
                val currentCount = if (type == Prefs.TYPE_TV) tvCount else radioCount

                if (currentCount == 0 && _uiState.value.syncError == null) {
                    val errorMsg = if (type == Prefs.TYPE_TV) {
                        "TV kanalları yüklenemedi. Lütfen internet bağlantınızı kontrol edip tekrar deneyin."
                    } else {
                        "Radyo istasyonları yüklenemedi. Lütfen internet bağlantınızı kontrol edip tekrar deneyin."
                    }
                    _uiState.update { 
                        it.copy(
                            TV_COUNT = tvCount, 
                            RADIO_COUNT = radioCount,
                            syncError = errorMsg,
                            SYNC_PROGRESS = errorMsg,
                            isSyncActive = false
                        ) 
                    }
                } else {
                    _uiState.update { 
                        it.copy(
                            TV_COUNT = tvCount, 
                            RADIO_COUNT = radioCount,
                            isSyncActive = false
                        ) 
                    }
                    if (_uiState.value.syncError == null && currentCount > 0) {
                        onReady()
                    }
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Sync failed for $type", e)
                val tvCount = channelManager.getTotalCount(Prefs.TYPE_TV, "", "", favoritesOnly = false, recentsOnly = false)
                val radioCount = channelManager.getTotalCount(Prefs.TYPE_FM, "", "", favoritesOnly = false, recentsOnly = false)
                val errText = e.localizedMessage ?: "Sunucuya bağlanırken bir hata oluştu."
                _uiState.update { 
                    it.copy(
                        TV_COUNT = tvCount,
                        RADIO_COUNT = radioCount,
                        syncError = errText,
                        SYNC_PROGRESS = "Hata oluştu: $errText",
                        isSyncActive = false
                    ) 
                }
            } finally {
                _uiState.update { it.copy(isSyncActive = false) }
            }
        }
    }

    fun completeSetup() {
        val prefs = getApplication<Application>().getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        prefs.edit { putBoolean(Prefs.KEY_IS_FIRST_RUN, false) }
        _uiState.update { it.copy(isFirstRun = false) }
        val initialType = _uiState.value.currentType
        loadChannels(initialType)
    }

    fun loadChannels(type: String, forceRefresh: Boolean = false) {
        settingsManager.setLastType(type)
        viewModelScope.launch {
            // Load saved filters for this type
            val savedCountry = settingsManager.getDefaultCountry(type)
            val savedCategory = settingsManager.getSelectedCategory(type)
            _uiState.update { it.copy(
                selectedCountry = savedCountry,
                selectedCategory = savedCategory
            ) }
            val currentCount = channelManager.getTotalCount(type, "", "", false, false)
            val isSwitchingType = _uiState.value.currentType != type
            // Optimization: Only clear list if switching type and DB is empty or we are forced
            if (isSwitchingType && (currentCount == 0 || forceRefresh)) {
                _uiState.update { it.copy(isLoading = true, currentType = type, channels = emptyList()) }
            } else {
                _uiState.update { it.copy(currentType = type) }
            }
            val isFavMode = _uiState.value.listMode == ListMode.FAVORITES
            val isRecentMode = _uiState.value.listMode == ListMode.RECENTS
            val chs = withContext(Dispatchers.IO) {
                channelManager.getChannels(
                    type, savedCountry, savedCategory, _uiState.value.sortMode.name, isFavMode, isRecentMode, 
                    _uiState.value.hideNsfw, forceRefresh
                )
            }
            val total = withContext(Dispatchers.IO) { channelManager.getTotalCount(type, savedCountry, savedCategory, isFavMode, isRecentMode) }
            val tvCount = withContext(Dispatchers.IO) { channelManager.getTotalCount(Prefs.TYPE_TV, "", "", favoritesOnly = false, recentsOnly = false) }
            val radioCount = withContext(Dispatchers.IO) { channelManager.getTotalCount(Prefs.TYPE_FM, "", "", favoritesOnly = false, recentsOnly = false) }
            val filters = withContext(Dispatchers.IO) { channelManager.getFilterOptions(type) }
            _uiState.update { it.copy(
                channels = chs, 
                TOTAL_COUNT = total,
                TV_COUNT = tvCount,
                RADIO_COUNT = radioCount,
                countryOptions = filters.first,
                categoryOptions = filters.second,
                isLoading = false
            )}
            // Preload logos for better performance
            preloadLogos(chs)
            val current = _uiState.value.CURRENT_CHANNEL
            if (current == null || current.type != type) {
                val lastIdForType = withContext(Dispatchers.IO) { settingsManager.getLastChannelId(type) }
                val channel = if (lastIdForType != null) withContext(Dispatchers.IO) { channelManager.getChannelById(lastIdForType) } else null
                if (channel != null) {
                    selectChannel(channel)
                } else if (chs.isNotEmpty()) {
                    if (lastIdForType != null) {
                        _uiState.update { it.copy(playbackError = "İzlediğiniz kanal kullanımdan kaldırıldı. Başka bir kanala geçiliyor...") }
                        viewModelScope.launch {
                            delay(5000.milliseconds)
                            _uiState.update { it.copy(playbackError = null) }
                        }
                    }
                    selectChannel(chs.first())
                }
            } else {
                val updatedCurrent = chs.firstOrNull { it.id == current.id }
                if (updatedCurrent != null) {
                    _uiState.update { it.copy(CURRENT_CHANNEL = updatedCurrent) }
                } else if (chs.isNotEmpty()) {
                    // Current channel was removed from DB list
                    _uiState.update { it.copy(playbackError = "İzlediğiniz kanal kullanımdan kaldırıldı. Başka bir kanala geçiliyor...") }
                    viewModelScope.launch {
                        delay(5000.milliseconds)
                        _uiState.update { it.copy(playbackError = null) }
                    }
                    selectChannel(chs.first())
                }
            }
        }
    }

    fun toggleFilterDialog() {
        onInteraction()
        val newState = !_uiState.value.isFilterDialogVisible
        _uiState.update { it.copy(isFilterDialogVisible = newState) }
        if (newState) {
            autoHideJob?.cancel()
        } else {
            resetAutoHideTimer()
        }
    }

    fun setListMode(mode: ListMode) {
        if (mode == ListMode.FILTER) {
            toggleFilterDialog()
            return
        }
        _uiState.update { it.copy(listMode = mode) }
        loadChannels(_uiState.value.currentType)
        resetAutoHideTimer()
    }

    fun setTypeAndMode(type: String, mode: ListMode) {
        _uiState.update { it.copy(listMode = mode, currentType = type) }
        settingsManager.setLastType(type)
        loadChannels(type)
        resetAutoHideTimer()
    }

    fun setSortMode(mode: SortMode) {
        _uiState.update { it.copy(sortMode = mode) }
        loadChannels(_uiState.value.currentType)
        resetAutoHideTimer()
    }

    fun setFilters(country: String, category: String) {
        val type = _uiState.value.currentType
        settingsManager.setDefaultCountry(type, country)
        settingsManager.setSelectedCategory(type, category)
        _uiState.update { it.copy(selectedCountry = country, selectedCategory = category) }
        loadChannels(type)
        resetAutoHideTimer()
    }

    fun loadMore() {
        if (_uiState.value.isLoading) return
        val type = _uiState.value.currentType
        val isFavMode = _uiState.value.listMode == ListMode.FAVORITES
        val isRecentMode = _uiState.value.listMode == ListMode.RECENTS
        val currentSize = _uiState.value.channels.size
        val total = _uiState.value.TOTAL_COUNT
        if (currentSize >= total) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val newChannels = channelManager.getChannelsPaged(
                type, 
                _uiState.value.selectedCountry, 
                _uiState.value.selectedCategory, 
                _uiState.value.sortMode.name,
                isFavMode,
                isRecentMode,
                _uiState.value.hideNsfw,
                100, 
                currentSize
            )
            _uiState.update { 
                it.copy(
                    channels = it.channels + newChannels,
                    isLoading = false
                )
            }
        }
    }

    @OptIn(UnstableApi::class)
    fun selectChannel(channel: Channel) {
        if (_uiState.value.isMenuVisible) {
            resetAutoHideTimer()
        }
        showInfo()
        val prevId = _uiState.value.CURRENT_CHANNEL?.id
        songStartSystemTimeMs = System.currentTimeMillis()
        _uiState.update { it.copy(CURRENT_CHANNEL = channel, previousChannelId = prevId, programInfo = null, currentType = channel.type) }
        settingsManager.setGlobalLastChannelId(channel.id)
        settingsManager.setLastChannelId(channel.type, channel.id)
        settingsManager.setLastType(channel.type)
        viewModelScope.launch {
            channelManager.updateLastViewed(channel.id)
        }
        // Rapid Zapping Debounce Protection: Immediate UI banner update, 150ms debounced ExoPlayer loading
        zapPlaybackJob?.cancel()
        zapPlaybackJob = viewModelScope.launch {
            delay(150.milliseconds)
            playerManager.play(channel)
            if (channel.type == Prefs.TYPE_FM) {
                startVisualizer()
            } else {
                stopVisualizer()
            }
            startProgramInfoJob(channel)
            startPlaybackService()
            playerManager.updateMediaSessionMetadata()
        }
    }

    private fun startPlaybackService() {
        try {
            val serviceIntent = Intent(getApplication(), PlaybackService::class.java)
            getApplication<Application>().startService(serviceIntent)
        } catch (e: Exception) {
            Log.e("MainViewModel", "Failed to start PlaybackService", e)
        }
    }

    private fun startProgramInfoJob(channel: Channel) {
        programInfoJob?.cancel()
        if (channel.type != Prefs.TYPE_TV) return
        programInfoJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                val info = tvProgramGuide.currentProgram(getApplication(), channel.name, channel.country)
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(programInfo = info) }
                }
                delay(60000.milliseconds) // Update every minute
            }
        }
    }

    fun jumpToPreviousChannel() {
        val prevId = _uiState.value.previousChannelId ?: return
        viewModelScope.launch {
            val channel = channelManager.getChannelById(prevId)
            if (channel != null) {
                selectChannel(channel)
            }
        }
    }

    fun toggleFavorite(channel: Channel) {
        onInteraction()
        viewModelScope.launch {
            val newState = !channel.isFavorite
            channelManager.toggleFavorite(channel.id, newState)
            _uiState.update { state ->
                state.copy(channels = state.channels.map {
                    if (it.id == channel.id) it.copy(isFavorite = newState) else it
                })
            }
        }
    }

    fun toggleEditMode() {
        onInteraction()
        val newState = !_uiState.value.isEditMode
        _uiState.update { it.copy(isEditMode = newState, isFilterDialogVisible = false) }
        if (newState) {
            autoHideJob?.cancel()
        } else {
            resetAutoHideTimer()
        }
    }

    fun moveChannel(channel: Channel, direction: Int) {
        val list = _uiState.value.channels
        val index = list.indexOfFirst { it.id == channel.id }
        if (index == -1) return
        
        val targetIndex = index + direction
        if (targetIndex in list.indices) {
            viewModelScope.launch {
                channelManager.swapOrder(list[index], list[targetIndex])
                loadChannels(_uiState.value.currentType)
            }
        }
    }

    fun syncBackupsNow(onComplete: ((Boolean) -> Unit)? = null) {
        onInteraction()
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                channelManager.syncBackupStreams(force = true)
                loadChannels(_uiState.value.currentType, forceRefresh = true)
                onComplete?.invoke(true)
            } catch (e: Exception) {
                e.printStackTrace()
                onComplete?.invoke(false)
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun forceRefresh(onComplete: ((Boolean) -> Unit)? = null) {
        onInteraction()
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                channelManager.syncBackupStreams(force = true)
                channelManager.refreshChannels(Prefs.TYPE_TV)
                channelManager.refreshChannels(Prefs.TYPE_FM)
                loadChannels(_uiState.value.currentType, forceRefresh = true)
                onComplete?.invoke(true)
            } catch (e: Exception) {
                e.printStackTrace()
                onComplete?.invoke(false)
            } finally {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun checkUpdate(forceCheck: Boolean = false) {
        viewModelScope.launch {
            try {
                val info = gitHubManager.checkForUpdate(BuildConfig.VERSION_NAME, forceCheck)
                if (info != null) {
                    _uiState.update { 
                        it.copy(
                            updateAvailable = true, 
                            updateUrl = info.downloadUrl,
                            updateVersion = info.latestVersion,
                            updateNotes = info.releaseNotes,
                            updateApkSize = info.apkSize,
                            isUpdateDialogVisible = true,
                            isUpdateToastVisible = false,
                            updateError = null
                        ) 
                    }
                } else if (forceCheck) {
                    _uiState.update { it.copy(updateAvailable = false, isUpdateDialogVisible = false, isUpdateToastVisible = false) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun toggleUpdateDialog(visible: Boolean) {
        _uiState.update { it.copy(isUpdateDialogVisible = visible, updateError = if (!visible) null else it.updateError) }
    }

    fun hideUpdateToast() {
        _uiState.update { it.copy(isUpdateToastVisible = false) }
    }

    fun downloadAndInstallUpdate() {
        val urlStr = _uiState.value.updateUrl ?: return
        _uiState.update { 
            it.copy(
                isUpdating = true, 
                isUpdateDialogVisible = true, 
                updateProgress = 0f, 
                downloadedBytes = 0L, 
                updateError = null
            ) 
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val apkFile = gitHubManager.downloadUpdateApk(urlStr, _uiState.value.updateApkSize) { progress, bytes ->
                    _uiState.update { it.copy(updateProgress = progress, downloadedBytes = bytes) }
                }
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(updateProgress = 100f) }
                    kotlinx.coroutines.delay(400)
                    _uiState.update { it.copy(isUpdating = false, updateAvailable = false, isUpdateDialogVisible = false) }
                    gitHubManager.installApk(apkFile)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    _uiState.update { 
                        it.copy(
                            isUpdating = false, 
                            updateError = e.localizedMessage ?: "İndirme başarısız oldu. Lütfen internet bağlantınızı kontrol edin."
                        ) 
                    }
                }
            }
        }
    }

    fun search(query: String) {
        onInteraction()
        if (query.isEmpty()) {
            loadChannels(_uiState.value.currentType)
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, channels = emptyList()) }
            val results = channelManager.search(query, _uiState.value.currentType)
            val filteredResults = results.filter { channel ->
                val countryMatch = _uiState.value.selectedCountry.isEmpty() || channel.country == _uiState.value.selectedCountry
                val categoryMatch = _uiState.value.selectedCategory.isEmpty() || channel.category == _uiState.value.selectedCategory
                countryMatch && categoryMatch
            }
            _uiState.update { it.copy(channels = filteredResults, TOTAL_COUNT = filteredResults.size, isLoading = false) }
        }
    }

    fun toggleSearch() {
        onInteraction()
        val newState = !_uiState.value.isSearchVisible
        _uiState.update { it.copy(isSearchVisible = newState) }
        if (newState) {
            autoHideJob?.cancel()
        } else {
            resetAutoHideTimer()
        }
    }

    private var songStartSystemTimeMs: Long = System.currentTimeMillis()
    private var lyricsTimerJob: Job? = null

    private fun startLyricsTimer() {
        lyricsTimerJob?.cancel()
        lyricsTimerJob = viewModelScope.launch {
            while (isActive) {
                val elapsed = System.currentTimeMillis() - songStartSystemTimeMs
                val result = _uiState.value.lyricsResult
                if (result != null && result.synced && result.lines.isNotEmpty()) {
                    val lines = result.lines
                    val idx = lines.indexOfLast { it.timeMs <= elapsed }.coerceAtLeast(0)
                    _uiState.update { it.copy(lyricsCurrentIndex = idx) }
                } else if (result != null && result.lines.isNotEmpty()) {
                    val idx = ((elapsed.coerceAtLeast(0L)) / 4000L).toInt().coerceIn(0, result.lines.size - 1)
                    _uiState.update { it.copy(lyricsCurrentIndex = idx) }
                }
                delay(100.milliseconds)
            }
        }
    }

    private fun stopLyricsTimer() {
        lyricsTimerJob?.cancel()
        lyricsTimerJob = null
    }

    fun toggleLyrics() {
        val newState = !_uiState.value.isLyricsVisible
        _uiState.update { it.copy(isLyricsVisible = newState) }
        if (newState) {
            fetchLyrics()
            startLyricsTimer()
            autoHideJob?.cancel()
        } else {
            stopLyricsTimer()
            resetAutoHideTimer()
        }
    }

    private fun fetchLyrics() {
        val metadata = _uiState.value.nowPlayingMetadata ?: _uiState.value.CURRENT_CHANNEL?.name ?: return
        val parts = metadata.split(" - ")
        val artist = parts.getOrNull(0) ?: ""
        val track = parts.getOrNull(1) ?: metadata
        
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = LyricsProvider.find(getApplication(), artist, track)
                withContext(Dispatchers.Main) {
                    _uiState.update { 
                        it.copy(
                            lyricsResult = result,
                            lyricsCurrentIndex = 0
                        )
                    }
                    startLyricsTimer()
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update { 
                        it.copy(
                            lyricsResult = null
                        )
                    }
                }
            }
        }
    }

    fun toggleSettings() {
        if (!_uiState.value.isSettingsVisible) {
            syncSettings()
        }
        val newState = !_uiState.value.isSettingsVisible
        _uiState.update { it.copy(isSettingsVisible = newState) }
        if (newState) {
            autoHideJob?.cancel()
        } else {
            resetAutoHideTimer()
        }
    }

    fun hideMenuManually() {
        autoHideJob?.cancel()
        _uiState.update { it.copy(isMenuVisible = false) }
    }

    fun updateSetting(action: (SettingsManager) -> Unit) {
        action(settingsManager)
        syncSettings()
        loadChannels(_uiState.value.currentType)
    }

    fun clearRecents() {
        viewModelScope.launch {
            channelManager.clearRecents()
            loadChannels(_uiState.value.currentType)
        }
    }

    private var posterIndicatorJob: Job? = null

    fun cycleRadioPoster(direction: Int) {
        val currentCode = _uiState.value.selectedPosterCode
        val posters = _uiState.value.availablePosters
        if (posters.isEmpty()) return
        val currentIndex = posters.indexOfFirst { it.code == currentCode }
        val nextIndex = if (currentIndex == -1) 0 else (currentIndex + direction + posters.size) % posters.size
        val nextPoster = posters[nextIndex]
        updateSetting { it.setSelectedPosterCode(nextPoster.code) }
        _uiState.update { it.copy(isPosterIndicatorVisible = true) }
        posterIndicatorJob?.cancel()
        posterIndicatorJob = viewModelScope.launch {
            delay(2500.milliseconds)
            _uiState.update { it.copy(isPosterIndicatorVisible = false) }
        }
    }

    private fun preloadLogos(channels: List<Channel>) {
        viewModelScope.launch(Dispatchers.IO) {
            logoManager.preloadLogos(channels)
        }
    }

    @SuppressLint("EmptySuperCall")
    override fun onCleared() {
        super.onCleared()
        stopVisualizer()
        playerManager.release()
    }
}
