package com.lpconsole.mediator.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lpconsole.mediator.LyricsProvider
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.ui.theme.Primary

@Composable
fun LyricsOverlay(
    lines: List<LyricsProvider.Line>,
    currentIndex: Int,
    artist: String,
    track: String,
    modifier: Modifier = Modifier,
    channel: Channel? = null,
    nowPlayingArtwork: Any? = null,
    onClose: () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            // Sol ve sağ kenar boşluğunu kıstık, sol blok sola yanaştı:
            .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sol Blok: Poster alanı daraltılıp sola yaklaştırıldı (0.28f)
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(0.28f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(modifier = Modifier.size(140.dp), contentAlignment = Alignment.Center) {
                    ChannelLogo(
                        channel = channel,
                        nowPlayingArtwork = nowPlayingArtwork,
                        modifier = Modifier.fillMaxSize().padding(4.dp),
                        iconSize = 70.dp
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = track.ifBlank { "Bilinmeyen Parça" },
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1,
                    style = TextStyle(
                        shadow = Shadow(
                            color = Color.Black,
                            offset = Offset(0f, 2f),
                            blurRadius = 4f
                        )
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = artist.ifBlank { channel?.name ?: "Canlı Yayın" },
                    color = Primary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    style = TextStyle(
                        shadow = Shadow(
                            color = Color.Black,
                            offset = Offset(0f, 2f),
                            blurRadius = 4f
                        )
                    )
                )
            }

            // Arayı biraz daralttık
            Spacer(modifier = Modifier.width(20.dp))

            // Sağ Blok: Şarkı sözleri alanı genişletildi (0.72f)
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(0.72f)
            ) {
                val centerPadding = maxHeight / 2
                val listState = rememberLazyListState()

                LaunchedEffect(currentIndex) {
                    if (currentIndex >= 0 && lines.isNotEmpty()) {
                        listState.animateScrollToItem(currentIndex, scrollOffset = 0)
                    }
                }

                if (lines.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Şarkı sözü bulunamadı.",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 19.sp,
                            textAlign = TextAlign.Center,
                            style = TextStyle(
                                shadow = Shadow(
                                    color = Color.Black,
                                    offset = Offset(0f, 2f),
                                    blurRadius = 4f
                                )
                            )
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        contentPadding = PaddingValues(top = centerPadding, bottom = centerPadding)
                    ) {
                        itemsIndexed(lines) { index, line ->
                            val isCurrent = index == currentIndex
                            Text(
                                text = line.text,
                                color = if (isCurrent) Primary else Color.White.copy(alpha = 0.5f),
                                fontSize = if (isCurrent) 22.sp else 17.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                textAlign = TextAlign.Center,
                                style = TextStyle(
                                    shadow = Shadow(
                                        color = Color.Black.copy(alpha = 0.8f),
                                        offset = Offset(0f, 2f),
                                        blurRadius = 6f
                                    )
                                )
                            )
                        }
                    }
                }
            }
        }

        // Kapatma Butonu (artık yapay offset olmadan doğal sağ üstte)
        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(44.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Kapat",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
