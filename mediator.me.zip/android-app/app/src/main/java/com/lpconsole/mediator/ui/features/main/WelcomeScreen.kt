package com.lpconsole.mediator.ui.features.main

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLocale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.lpconsole.mediator.BuildConfig
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.R
import com.lpconsole.mediator.data.remote.models.CountryDto
import com.lpconsole.mediator.ui.theme.Primary
import java.util.Locale

@Composable
fun WelcomeScreen(
    uiState: MainUiState,
    onStartSync: (Set<String>, String, () -> Unit) -> Unit,
    onComplete: () -> Unit
) {
    val countryCode = LocalLocale.current.platformLocale.country.ifEmpty { "TR" }
    var currentStep by remember { mutableIntStateOf(1) }
    var selectedCountries by remember { mutableStateOf(setOf(countryCode)) }
    
    val isTvLoading = currentStep == 3 && uiState.isSyncActive
    val isRadioLoading = currentStep == 4 && uiState.isSyncActive
    val isDownloading = isTvLoading || isRadioLoading
    val bgColor = Color(0xFF0F1015)
    val surfaceColor = Color(0xFF1E1F26)

    BackHandler(enabled = currentStep in 2..<5 && !isDownloading) {
        if (!isDownloading) {
            currentStep -= 1
        }
    }

    LaunchedEffect(currentStep) {
        if (currentStep == 3) {
            if (uiState.TV_COUNT == 0 || uiState.syncError != null) {
                onStartSync(selectedCountries, Prefs.TYPE_TV) {}
            }
        } else if (currentStep == 4) {
            if (uiState.RADIO_COUNT == 0 || uiState.syncError != null) {
                onStartSync(selectedCountries, Prefs.TYPE_FM) {}
            }
        }
    }

    Row(modifier = Modifier.fillMaxSize().background(surfaceColor)) {
        // SOL ALAN (%35)
        Column(
            modifier = Modifier.fillMaxHeight().weight(0.35f).background(bgColor).padding(horizontal = 24.dp, vertical = 24.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(
                    imageVector = Icons.Default.Tv,
                    contentDescription = null,
                    tint = Primary,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = BuildConfig.APP_NAME,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Primary.copy(alpha = 0.2f))
                        .border(1.dp, Primary.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = countryCode.uppercase(),
                        color = Primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                AnimatedContent(targetState = currentStep, label = "title") { step ->
                    Text(
                        text = when (step) {
                            1 -> "Hoşgeldiniz"
                            2 -> "Bölgenizi Seçin"
                            3 -> "TV Kanalları Kuruluyor"
                            4 -> "Radyo Kanalları Kuruluyor"
                            5 -> "Her Şey Hazır!"
                            else -> ""
                        },
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontSize = 24.sp,
                            lineHeight = 32.sp
                        ),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2
                    )
                }
                Spacer(modifier = Modifier.height(15.dp))
                AnimatedContent(targetState = currentStep, label = "desc") { step ->
                    Text(
                        text = when (step) {
                            1 -> "Televizyon ve radyo istasyonları tek bir yerde. Başlamak için kuruluma geçin."
                            2 -> "Yerel kanallar ve istasyonlar için ülkenizi belirleyin."
                            3 -> "Ulusal ve küresel TV kanalları ekleniyor..."
                            4 -> "Radyo istasyonları ve frekans bilgileri senkronize ediliyor..."
                            5 -> "Tüm kanallar başarıyla yüklendi. Artık yayına başlayabilirsiniz."
                            else -> ""
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        maxLines = 3
                    )
                }
            }

            Text(
                text = "Adım $currentStep / 5",
                style = MaterialTheme.typography.labelMedium,
                color = Primary,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 15.sp,
                textAlign = TextAlign.Start
            )
        }

        // SAĞ ALAN (%65)
        Column(
            modifier = Modifier.fillMaxHeight().weight(0.65f).background(surfaceColor)
        ) {
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                AnimatedContent(targetState = currentStep, label = "content") { step ->
                    when (step) {
                        1 -> Step1Content()
                        2 -> Step2Content(
                            countryList = uiState.countryList,
                            selectedCountries = selectedCountries,
                            onCountriesChanged = { selectedCountries = it }
                        )
                        3 -> Step3Content(
                            uiState = uiState,
                            onRetry = {
                                onStartSync(selectedCountries, Prefs.TYPE_TV) {}
                            }
                        )
                        4 -> Step4Content(
                            uiState = uiState,
                            onRetry = {
                                onStartSync(selectedCountries, Prefs.TYPE_FM) {}
                            }
                        )
                        5 -> Step5Content()
                    }
                }
            }

            // ALT BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(bgColor)
                    .padding(horizontal = 32.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.width(130.dp), contentAlignment = Alignment.CenterStart) {
                    if (currentStep in 2..4) {
                        BottomNavButton("Geri", false, isEnabled = !isDownloading) {
                            if (!isDownloading) {
                                currentStep -= 1
                            }
                        }
                    }
                }

                Box(modifier = Modifier.width(160.dp), contentAlignment = Alignment.CenterEnd) {
                    when (currentStep) {
                        1 -> BottomNavButton("Başla", isPrimary = true, isEnabled = true) { currentStep = 2 }
                        2 -> {
                            BottomNavButton(
                                text = "İleri",
                                isPrimary = true,
                                isEnabled = selectedCountries.isNotEmpty(),
                                isLoading = false
                            ) {
                                currentStep = 3
                            }
                        }
                        3 -> {
                            val canProceedTv = !uiState.isSyncActive && uiState.TV_COUNT > 0 && uiState.syncError == null
                            BottomNavButton(
                                text = "İleri",
                                isPrimary = true,
                                isEnabled = canProceedTv,
                                isLoading = uiState.isSyncActive
                            ) {
                                currentStep = 4
                            }
                        }
                        4 -> {
                            val canProceedRadio = !uiState.isSyncActive && uiState.RADIO_COUNT > 0 && uiState.syncError == null
                            BottomNavButton(
                                text = "İleri",
                                isPrimary = true,
                                isEnabled = canProceedRadio,
                                isLoading = uiState.isSyncActive
                            ) {
                                currentStep = 5
                            }
                        }
                        5 -> BottomNavButton("İzlemeye Başla", isPrimary = true, isEnabled = true) { onComplete() }
                    }
                }
            }
        }
    }
}

@Composable
fun Step3Content(
    uiState: MainUiState,
    onRetry: () -> Unit
) {
    BaseSyncContent(
        type = "TV",
        status = uiState.SYNC_PROGRESS,
        realCount = uiState.TV_COUNT,
        icon = Icons.Default.Tv,
        progressFraction = uiState.syncProgressFraction,
        syncError = uiState.syncError,
        isSyncActive = uiState.isSyncActive,
        onRetry = onRetry
    )
}

@Composable
fun Step4Content(
    uiState: MainUiState,
    onRetry: () -> Unit
) {
    BaseSyncContent(
        type = "Radyo",
        status = uiState.SYNC_PROGRESS,
        realCount = uiState.RADIO_COUNT,
        icon = Icons.Default.Radio,
        progressFraction = uiState.syncProgressFraction,
        syncError = uiState.syncError,
        isSyncActive = uiState.isSyncActive,
        onRetry = onRetry
    )
}

@Composable
private fun BaseSyncContent(
    type: String,
    status: String,
    realCount: Int,
    icon: ImageVector,
    progressFraction: Float,
    syncError: String?,
    isSyncActive: Boolean,
    onRetry: () -> Unit
) {
    val isError = syncError != null || (!isSyncActive && realCount == 0 && progressFraction > 0f)
    val progressColor = if (isError) Color(0xFFFF5252) else if (realCount > 0 && !isSyncActive) Color(0xFF00E676) else Primary
    val targetProgress = if (isError) 1f else if (realCount > 0 && !isSyncActive) 1f else progressFraction.coerceIn(0.02f, 0.98f)

    val animatedProgress by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = tween(durationMillis = 350, easing = LinearEasing),
        label = "SyncProgress"
    )

    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp, horizontal = 24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (isError) Color(0xFFFF5252).copy(alpha = 0.15f) else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isError) Color(0xFFFF5252) else Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = "$type Kanalları ${if (isError) "Yüklenemedi" else if (!isSyncActive && realCount > 0) "Yüklendi" else "Yükleniyor"}",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                val headerSubtitle = when {
                    isError -> syncError ?: "Sunucuya bağlanılamadı."
                    !isSyncActive && realCount > 0 -> "Kurulum başarıyla tamamlandı."
                    else -> "Lütfen bekleyin, kanallar hazırlanıyor..."
                }
                AnimatedContent(
                    targetState = headerSubtitle,
                    label = "HeaderSubtitle"
                ) { currentSubtitle ->
                    Text(
                        text = currentSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isError) Color(0xFFFF8A80) else Color.Gray,
                        modifier = Modifier.padding(top = 2.dp),
                        fontSize = 13.sp
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(20.dp))

        // Progress Bar
        LinearProgressIndicator(
            progress = { animatedProgress },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = progressColor,
            trackColor = Color.White.copy(alpha = 0.08f)
        )
        Spacer(modifier = Modifier.height(14.dp))

        if (isError) {
            // ERROR STATE CARD WITH RETRY BUTTON
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2C1010))
                    .border(1.dp, Color(0xFFFF5252).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f).padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFFF5252),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Yükleme sırasında hata oluştu. Lütfen tekrar deneyin.",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp
                        )
                    }
                    Surface(
                        onClick = onRetry,
                        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(8.dp)),
                        colors = ClickableSurfaceDefaults.colors(
                            containerColor = Color(0xFFFF5252),
                            focusedContainerColor = Color.White,
                            contentColor = Color.White,
                            focusedContentColor = Color.Black
                        ),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 12.dp)) {
                            Text("Yeniden Dene", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            val syncDisplay = remember(status, realCount, isSyncActive, type) {
                parseSyncStatus(status, type, realCount, isSyncActive)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AnimatedContent(
                    targetState = syncDisplay.label,
                    label = "SyncLabel"
                ) { currentLabel ->
                    Text(
                        text = currentLabel,
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 15.sp
                    )
                }
                AnimatedContent(
                    targetState = syncDisplay.countText,
                    label = "SyncCount"
                ) { currentCount ->
                    Text(
                        text = currentCount,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }
            }
        }
    }
}

@Composable
fun Step1Content() {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "Kuruluma Başlamadan Önce",
            style = MaterialTheme.typography.headlineSmall,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp
        )
        Text(
            text = "${BuildConfig.APP_NAME}, dünya genelindeki açık kaynaklı ve ücretsiz canlı yayınları tek bir platformda birleştiren akıllı bir medya merkezidir.\nKullanımı tamamen ücretsizdir, herhangi bir üyelik veya abonelik gerektirmez.",
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White.copy(alpha = 0.6f),
            lineHeight = 22.sp,
            fontSize = 15.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(24.dp).clip(RoundedCornerShape(6.dp)).background(Primary),
                contentAlignment = Alignment.Center
            ) {
                Text("✓", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "Kullanım Koşulları ve Gizlilik Politikasını okudum, kabul ediyorum.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun Step2Content(
    countryList: List<CountryDto>,
    selectedCountries: Set<String>,
    onCountriesChanged: (Set<String>) -> Unit
) {
    val itemsList = remember(countryList) { listOf(CountryDto("Tüm Ülkeler", "ALL")) + countryList }
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) {
        val targetIndex = itemsList.indexOfFirst { country ->
            selectedCountries.contains(country.code)
        }
        if (targetIndex != -1) {
            listState.scrollToItem(targetIndex)
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        LazyColumn(
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().height(260.dp).padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            items(
                items = itemsList,
                key = { it.code ?: it.name ?: "" }
            ) { country ->
                val code = country.code ?: ""
                val name = country.name ?: code
                val isSelected = selectedCountries.contains(code)
                CountryMultiSelectionItem(
                    text = "$name ($code)",
                    isSelected = isSelected,
                    onClick = {
                        val next = if (code.equals("ALL", true)) {
                            setOf("ALL")
                        } else {
                            val withoutAll = selectedCountries - "ALL"
                            if (isSelected) {
                                if (withoutAll.size > 1) withoutAll - code else withoutAll
                            } else {
                                withoutAll + code
                            }
                        }
                        onCountriesChanged(next)
                    }
                )
            }
        }
    }
}

@Composable
fun CountryMultiSelectionItem(text: String, isSelected: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    Surface(
        onClick = onClick,
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.02f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (isSelected) Primary.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f),
            focusedContainerColor = Primary,
            contentColor = if (isSelected) Primary else Color.White,
            focusedContentColor = Color.Black
        ),
        interactionSource = interactionSource,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(10.dp)),
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .then(
                if (isFocused) Modifier.border(2.dp, Color.White, RoundedCornerShape(10.dp))
                else if (isSelected) Modifier.border(1.dp, Primary, RoundedCornerShape(10.dp))
                else Modifier
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isFocused || isSelected) FontWeight.Bold else FontWeight.Normal
            )
            if (isSelected) {
                Box(
                    modifier = Modifier.size(20.dp).clip(RoundedCornerShape(4.dp)).background(Primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✓", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun Step5Content() {
    val infiniteTransition = rememberInfiniteTransition(label = "AmbientNeonPulse")
    val ambientAlpha by infiniteTransition.animateFloat(
        initialValue = 0.05f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AmbientAlpha"
    )
    Box(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    brush = Brush.verticalGradient(colors = listOf(Color.Transparent, Color(0xFF00FF88).copy(alpha = ambientAlpha), Color.Transparent))
                )
        )
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_tv_satellite_ready),
                contentDescription = null,
                colorFilter = ColorFilter.tint(Color(0xFF3DDC84)),
                modifier = Modifier.size(100.dp)
            )
            Text(
                text = "İyi Seyirler!",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "Kişisel listeniz oluşturuldu. Şimdi arkanıza yaslanın, kumandanızla dilediğiniz içeriğin keyfini çıkarın.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.6f),
                lineHeight = 20.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun BottomNavButton(
    text: String,
    isPrimary: Boolean,
    isEnabled: Boolean,
    isLoading: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val canInteract = isEnabled && !isLoading
    val bgColor = if (!canInteract) Color.White.copy(alpha = 0.05f)
    else if (isPrimary) Primary.copy(alpha = 0.2f)
    else Color.White.copy(alpha = 0.1f)
    val contentColor = if (!canInteract) Color.White.copy(alpha = 0.3f)
    else if (isPrimary) Primary
    else Color.White

    Surface(
        onClick = { if (canInteract) onClick() },
        scale = ClickableSurfaceDefaults.scale(focusedScale = if (canInteract) 1.05f else 1f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = bgColor,
            focusedContainerColor = if (canInteract) Primary else bgColor,
            contentColor = if (canInteract) Color.Black else contentColor
        ),
        interactionSource = interactionSource,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(20.dp)),
        modifier = modifier
            .height(40.dp)
            .defaultMinSize(minWidth = 120.dp)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = canInteract
            ) {
                onClick()
            }
            .then(
                if (isFocused && canInteract) Modifier.border(2.dp, Color.White, RoundedCornerShape(20.dp))
                else if (isPrimary && canInteract) Modifier.border(1.dp, Primary, RoundedCornerShape(20.dp))
                else Modifier
            )
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            if (isLoading) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Bekleyin...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 13.sp
                    )
                }
            } else {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (isFocused || isPrimary) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 14.sp
                )
            }
        }
    }
}

private data class SyncStatusDisplay(
    val label: String,
    val countText: String
)

private fun parseSyncStatus(status: String, type: String, realCount: Int, isSyncActive: Boolean): SyncStatusDisplay {
    if (!isSyncActive && realCount > 0) {
        val formattedCount = String.format(Locale.US, "%,d", realCount).replace(',', '.')
        return SyncStatusDisplay(
            label = "Toplam $type Sayısı",
            countText = formattedCount
        )
    }
    if (status.isBlank()) {
        val formattedCount = if (realCount > 0) String.format(Locale.US, "%,d", realCount).replace(',', '.') else "0"
        return SyncStatusDisplay(
            label = if (isSyncActive) "Veriler senkronize ediliyor..." else "Toplam $type Sayısı",
            countText = formattedCount
        )
    }
    val parenIndex = status.indexOf('(')
    if (parenIndex != -1) {
        var label = status.substring(0, parenIndex).trim()
        if (label.endsWith("...")) {
            label = label.substring(0, label.length - 3).trim() + "..."
        } else if (!label.endsWith(".")) {
            label = "$label..."
        }
        val parenContent = status.substring(parenIndex + 1).removeSuffix(")").removeSuffix(").").trim()
        val countText = formatParenCount(parenContent, realCount)
        return SyncStatusDisplay(
            label = label,
            countText = countText
        )
    }
    val formattedCount = if (realCount > 0) String.format(Locale.US, "%,d", realCount).replace(',', '.') else "0"
    return SyncStatusDisplay(
        label = status,
        countText = formattedCount
    )
}

private fun formatParenCount(rawParen: String, fallbackRealCount: Int): String {
    val parts = rawParen.split(" ")
    if (parts.size == 1 && parts[0].all { it.isDigit() }) {
        val num = parts[0].toIntOrNull() ?: return rawParen
        return String.format(Locale.US, "%,d", num).replace(',', '.')
    }
    if (parts.size == 2 && parts[0].all { it.isDigit() }) {
        val num = parts[0].toIntOrNull() ?: return rawParen
        return String.format(Locale.US, "%,d", num).replace(',', '.')
    }
    if (parts.size == 3 && parts[1] == "/" && parts[0].all { it.isDigit() } && parts[2].all { it.isDigit() }) {
        val num1 = parts[0].toIntOrNull() ?: return rawParen
        val num2 = parts[2].toIntOrNull() ?: return rawParen
        val f1 = String.format(Locale.US, "%,d", num1).replace(',', '.')
        val f2 = String.format(Locale.US, "%,d", num2).replace(',', '.')
        return "$f1 / $f2"
    }
    if (fallbackRealCount > 0) {
        return String.format(Locale.US, "%,d", fallbackRealCount).replace(',', '.')
    }
    return rawParen
}
