package com.lpconsole.mediator.ui.features.main

import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.Surface
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.ui.theme.Primary
import com.lpconsole.mediator.ui.util.dualControl

@Composable
fun SideMenu(
    selectedType: String,
    onTypeAndModeSelect: (String, ListMode) -> Unit,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onInteraction: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(80.dp)
            .fillMaxHeight()
            .background(Color.Transparent)
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            RailItem(
                icon = Icons.Default.Search,
                isSelected = false,
                onClick = onSearchClick,
                onFocus = onInteraction
            )
            RailItem(
                icon = Icons.Default.Tv,
                isSelected = selectedType == Prefs.TYPE_TV,
                onClick = { onTypeAndModeSelect(Prefs.TYPE_TV, ListMode.ALL) },
                onFocus = onInteraction
            )
            RailItem(
                icon = Icons.Default.Radio,
                isSelected = selectedType == Prefs.TYPE_FM,
                onClick = { onTypeAndModeSelect(Prefs.TYPE_FM, ListMode.ALL) },
                onFocus = onInteraction
            )
        }
        RailItem(
            icon = Icons.Default.Settings,
            isSelected = false,
            onClick = onSettingsClick,
            onFocus = onInteraction
        )
    }
}

@Composable
fun RailItem(
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    onFocus: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    Surface(
        onClick = onClick,
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.15f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (isSelected) Primary else Color.Transparent,
            contentColor = if (isSelected) Color.Black else Color.White.copy(alpha = 0.6f),
            focusedContainerColor = Primary,
            focusedContentColor = Color.Black
        ),
        interactionSource = interactionSource,
        modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .dualControl(
                onClick = onClick,
                onFocus = onFocus,
                interactionSource = interactionSource
            )
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(26.dp)
            )
        }
    }
}
