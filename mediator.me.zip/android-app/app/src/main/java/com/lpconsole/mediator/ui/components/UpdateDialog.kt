package com.lpconsole.mediator.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.lpconsole.mediator.BuildConfig
import com.lpconsole.mediator.ui.features.main.MainUiState
import com.lpconsole.mediator.ui.theme.Primary
import com.lpconsole.mediator.ui.util.dualControl
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.time.Duration.Companion.milliseconds

@Composable
fun UpdateDialog(
    state: MainUiState,
    onConfirmUpdate: () -> Unit,
    onDismiss: () -> Unit
) {
    if (!state.isUpdateDialogVisible) return

    val installFocusRequester = remember { FocusRequester() }
    val retryFocusRequester = remember { FocusRequester() }

    LaunchedEffect(state.isUpdateDialogVisible, state.isUpdating, state.updateError) {
        if (state.isUpdateDialogVisible && !state.isUpdating) {
            delay(120.milliseconds)
            try {
                if (state.updateError != null) {
                    retryFocusRequester.requestFocus()
                } else {
                    installFocusRequester.requestFocus()
                }
            } catch (_: Exception) {}
        }
    }

    Dialog(onDismissRequest = {
        if (!state.isUpdating) onDismiss()
    }) {
        BackHandler(enabled = !state.isUpdating) {
            onDismiss()
        }

        Box(
            modifier = Modifier
                .width(480.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF161821))
                .border(1.5.dp, Primary.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .padding(26.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // --- 1. HEADER ---
                val isError = state.updateError != null && !state.isUpdating
                val headerIcon = when {
                    isError -> Icons.Default.ErrorOutline
                    state.isUpdating -> Icons.Default.Download
                    else -> Icons.Default.SystemUpdate
                }
                val headerIconColor = if (isError) Color(0xFFFF5252) else Primary

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(headerIconColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = headerIcon,
                            contentDescription = null,
                            tint = headerIconColor,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = when {
                                isError -> "Güncelleme Başarısız Oldu"
                                state.isUpdating -> if (state.updateProgress >= 100f) "Kurulum Başlatılıyor..." else "Yeni Sürüm İndiriliyor..."
                                else -> "Yeni Güncelleme Mevcut!"
                            },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "v${state.updateVersion} (Mevcut Sürüm: v${BuildConfig.VERSION_NAME})",
                            style = MaterialTheme.typography.labelMedium,
                            color = Primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- 2. BODY CONTENT ---
                when {
                    // CASE A: Active Downloading Progress
                    state.isUpdating -> {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (state.updateProgress >= 100f) "Tamamlandı! %100" else "%${state.updateProgress.toInt()}",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Primary
                                )
                                if (state.updateApkSize > 0) {
                                    val downloadedMB = String.format(Locale.US, "%.1f", state.downloadedBytes / (1024f * 1024f))
                                    val totalMB = String.format(Locale.US, "%.1f", state.updateApkSize / (1024f * 1024f))
                                    Text(
                                        text = "$downloadedMB MB / $totalMB MB",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = Color.White.copy(alpha = 0.7f),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            LinearProgressIndicator(
                                progress = { (state.updateProgress / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(5.dp)),
                                color = Primary,
                                trackColor = Color.White.copy(alpha = 0.12f)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = if (state.updateProgress >= 100f)
                                    "Paket hazırlandı. Sistem yükleyicisi açılıyor, lütfen bekleyin..."
                                else
                                    "İndirme tamamlandığında kurulum ekranı otomatik olarak açılacaktır.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.5f),
                                lineHeight = 18.sp
                            )
                        }
                    }

                    // CASE B: Error during download
                    isError -> {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFFF5252).copy(alpha = 0.12f))
                                    .border(1.dp, Color(0xFFFF5252).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                    .padding(14.dp)
                            ) {
                                Text(
                                    text = state.updateError,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFFFF8A80),
                                    lineHeight = 20.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UpdateActionButton(
                                    text = "Kapat",
                                    isPrimary = false,
                                    onClick = onDismiss
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                UpdateActionButton(
                                    text = "Tekrar Dene",
                                    isPrimary = true,
                                    focusRequester = retryFocusRequester,
                                    onClick = onConfirmUpdate
                                )
                            }
                        }
                    }

                    // CASE C: Default prompt with Release Notes & Install buttons
                    else -> {
                        if (state.updateNotes.isNotBlank()) {
                            Text(
                                text = "Yenilikler:",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 140.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.05f))
                                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                    .padding(12.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Text(
                                    text = state.updateNotes,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.9f),
                                    lineHeight = 20.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        if (state.updateApkSize > 0) {
                            val totalMB = String.format(Locale.US, "%.1f", state.updateApkSize / (1024f * 1024f))
                            Text(
                                text = "İndirme Boyutu: ~$totalMB MB",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(18.dp))
                        } else {
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        // Action Buttons: "Daha Sonra" and "Şimdi Yükle"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UpdateActionButton(
                                text = "Daha Sonra",
                                isPrimary = false,
                                onClick = onDismiss
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            UpdateActionButton(
                                text = "Şimdi Yükle",
                                isPrimary = true,
                                focusRequester = installFocusRequester,
                                onClick = onConfirmUpdate
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Hem TV kumandası (D-Pad Focus + Enter/Center) hem de dokunmatik ekran (Touch Tap)
 * ile %100 uyumlu, yüksek kontrastlı buton bileşeni.
 */
@Composable
private fun UpdateActionButton(
    text: String,
    isPrimary: Boolean,
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val isPressed by interactionSource.collectIsPressedAsState()

    val containerColor = when {
        isPrimary -> if (isFocused || isPressed) Color(0xFF00FF88) else Primary
        else -> if (isFocused || isPressed) Color.White.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f)
    }

    val contentColor = when {
        isPrimary -> Color(0xFF0D0E15)
        else -> if (isFocused || isPressed) Color.White else Color.White.copy(alpha = 0.85f)
    }

    val borderModifier = when {
        isFocused -> Modifier.border(2.5.dp, Color.White, RoundedCornerShape(12.dp))
        isPrimary -> Modifier.border(1.dp, Primary.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
        else -> Modifier.border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
    }

    Surface(
        onClick = onClick,
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.05f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = containerColor,
            contentColor = contentColor,
            focusedContainerColor = containerColor,
            focusedContentColor = contentColor
        ),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(12.dp)),
        interactionSource = interactionSource,
        modifier = Modifier
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .then(borderModifier)
            .dualControl(
                onClick = onClick,
                interactionSource = interactionSource
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .padding(horizontal = 22.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = contentColor,
                fontSize = 14.sp
            )
        }
    }
}
