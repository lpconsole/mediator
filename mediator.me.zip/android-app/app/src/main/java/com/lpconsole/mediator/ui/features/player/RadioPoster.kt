package com.lpconsole.mediator.ui.features.player

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.lpconsole.mediator.GifPosterView
import java.io.File

@Composable
fun RadioPoster(
    posterFile: File?,
    modifier: Modifier = Modifier,
    selectedPosterCode: String? = null,
    audioAmplitudes: FloatArray? = null
) {
    if (selectedPosterCode.equals("visualizer", ignoreCase = true)) {
        AudioVisualizerView(
            amplitudes = audioAmplitudes,
            modifier = modifier.fillMaxSize()
        )
    } else {
        val context = LocalContext.current
        val posterView = remember { GifPosterView(context) }
        AndroidView(
            factory = { posterView },
            update = { view -> view.setPosterFile(posterFile) },
            modifier = modifier.fillMaxSize()
        )
        DisposableEffect(posterView) {
            onDispose {
                posterView.release()
            }
        }
    }
}
