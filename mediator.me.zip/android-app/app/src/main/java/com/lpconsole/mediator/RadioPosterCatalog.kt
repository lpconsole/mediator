package com.lpconsole.mediator

import android.content.Context
import com.lpconsole.mediator.util.GitHubManager
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.IOException
import java.util.Locale

/**
 * Static catalog facade for Radio Posters, backed by [GitHubManager].
 */
object RadioPosterCatalog {
    val GIFS_API_URL: String get() = "https://api.github.com/repos/${BuildConfig.GITHUB_REPOSITORY}/contents/gifs?ref=main"
    const val DEFAULT_POSTER_CODE = GitHubManager.DEFAULT_POSTER_CODE

    @JvmStatic
    @Throws(IOException::class)
    suspend fun loadAsync(context: Context, preferFresh: Boolean): List<Poster> {
        return GitHubManager(context).loadRadioPosters(preferFresh)
    }

    @JvmStatic
    @Throws(IOException::class)
    fun load(context: Context, preferFresh: Boolean): List<Poster> {
        return runBlocking {
            loadAsync(context, preferFresh)
        }
    }

    @JvmStatic
    fun selectedPoster(posters: List<Poster>?, savedCode: String?): Poster? {
        if (posters.isNullOrEmpty()) return null
        val normalized = normalizeCode(savedCode)
        return posters.find { it.code.equals(normalized, ignoreCase = true) } ?: posters.firstOrNull()
    }

    private fun normalizeCode(code: String?): String {
        var value = code?.trim() ?: ""
        if (value.isEmpty() || value.equals("default", ignoreCase = true) || value.equals("default.gif", ignoreCase = true)) {
            return DEFAULT_POSTER_CODE
        }
        if (value.startsWith("poster_")) { value = value.removePrefix("poster_") }
        if (!value.lowercase(Locale.US).endsWith(".gif")) { value += ".gif" }
        return value
    }

    @JvmStatic
    fun cleanupOldCaches(context: Context, validPosters: List<Poster>) {
        GitHubManager(context).cleanupOldPosterCaches(validPosters)
    }

    @JvmStatic
    @Throws(IOException::class)
    suspend fun downloadPosterAsync(context: Context, poster: Poster): File {
        return GitHubManager(context).downloadRadioPoster(poster)
    }

    @JvmStatic
    @Throws(IOException::class)
    fun downloadPoster(context: Context, poster: Poster): File {
        return runBlocking {
            downloadPosterAsync(context, poster)
        }
    }

    data class Poster(
        val code: String,
        val label: String,
        val downloadUrl: String
    )
}
