package com.lpconsole.mediator.ui.features.main

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.LocalContentColor
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.ui.components.ChannelLogo
import com.lpconsole.mediator.ui.theme.Primary
import com.lpconsole.mediator.ui.util.dualControl

@Composable
fun ChannelList(
    channels: List<Channel>,
    totalCount: Int,
    currentChannel: Channel?,
    nowPlayingMetadata: String? = null,
    onChannelClick: (Channel) -> Unit,
    onToggleFavorite: (Channel) -> Unit,
    onMoveChannel: (Channel, Int) -> Unit = { _, _ -> },
    isEditMode: Boolean = false,
    onLoadMore: () -> Unit,
    onInteraction: () -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
    focusRequester: FocusRequester? = null
) {
    val isScrolling by remember { derivedStateOf { listState.isScrollInProgress } }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemScrollOffset }.collect {
            if (isScrolling) {
                onInteraction()
            }
        }
    }

    val shouldLoadMore by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex >= channels.size - 15 && channels.size < totalCount
        }
    }

    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) {
            onLoadMore()
        }
    }

    LazyColumn(
        state = listState,
        verticalArrangement = Arrangement.spacedBy(2.dp),
        contentPadding = PaddingValues(vertical = 12.dp),
        modifier = modifier.fillMaxSize()
    ) {
        itemsIndexed(
            items = channels,
            key = { _, channel -> channel.id },
            contentType = { _, _ -> "channel" }
        ) { index, channel ->
            val isTargetFocus = (currentChannel?.id == channel.id) || (currentChannel == null && index == 0)
            val itemModifier = if (isTargetFocus && focusRequester != null) {
                Modifier.focusRequester(focusRequester)
            } else {
                Modifier
            }

            ChannelItem(
                channel = channel,
                index = index + 1,
                isSelected = currentChannel?.id == channel.id,
                nowPlayingMetadata = nowPlayingMetadata,
                isEditMode = isEditMode,
                onClick = { onChannelClick(channel) },
                onLongClick = { onToggleFavorite(channel) },
                onMove = { onMoveChannel(channel, it) },
                onFocus = onInteraction,
                modifier = itemModifier
            )
        }
        
        if (channels.size < totalCount) {
            item(key = "loading_indicator") {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = Primary,
                        modifier = Modifier.size(28.dp),
                        strokeWidth = 2.dp
                    )
                }
            }
        }
    }
}

@Composable
fun PlayingIndicator(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "playing")
    val bar1 by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(400, easing = LinearEasing), RepeatMode.Reverse), label = ""
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(500, easing = LinearEasing), RepeatMode.Reverse), label = ""
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue = 0.1f, targetValue = 0.7f,
        animationSpec = infiniteRepeatable(tween(350, easing = LinearEasing), RepeatMode.Reverse), label = ""
    )
    Canvas(modifier = modifier.size(18.dp, 14.dp)) {
        val spacing = 3.dp.toPx()
        val barWidth = 3.dp.toPx()
        val height = size.height
        drawRect(Primary, Offset(0f, height * (1 - bar1)), Size(barWidth, height * bar1))
        drawRect(Primary, Offset(barWidth + spacing, height * (1 - bar2)), Size(barWidth, height * bar2))
        drawRect(Primary, Offset((barWidth + spacing) * 2, height * (1 - bar3)), Size(barWidth, height * bar3))
    }
}

@Composable
fun ChannelItem(
    channel: Channel,
    index: Int,
    isSelected: Boolean,
    nowPlayingMetadata: String? = null,
    isEditMode: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onMove: (Int) -> Unit = {},
    onFocus: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    
    val subtitleText = remember(channel.id, isSelected, nowPlayingMetadata) {
        if (isSelected && !nowPlayingMetadata.isNullOrBlank()) {
            nowPlayingMetadata
        } else {
            val info = channel.category.takeIf { it.isNotEmpty() } 
                ?: channel.network.takeIf { it.isNotEmpty() } 
                ?: channel.owner.takeIf { it.isNotEmpty() }
            info ?: channel.country.takeIf { it.isNotEmpty() } ?: "Canlı"
        }
    }

    val quality = remember(channel.id) {
        channel.streams.firstOrNull()?.quality?.takeIf { it.isNotEmpty() } ?: "HD"
    }

    Surface(
        onClick = onClick,
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.02f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (isSelected) Primary.copy(alpha = 0.1f) else Color.Transparent,
            focusedContainerColor = Color(0xFF2F80FF).copy(alpha = 0.35f),
            contentColor = if (isSelected || isFocused) Color.White else Color.White.copy(alpha = 0.7f),
            focusedContentColor = Color.White
        ),
        interactionSource = interactionSource,
        modifier = modifier
            .fillMaxWidth()
            .height(68.dp)
            .dualControl(
                onClick = onClick,
                onLongClick = onLongClick,
                onFocus = onFocus,
                interactionSource = interactionSource
            )
            .then(if (isSelected && !isFocused) Modifier.border(1.dp, Primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp)) else Modifier)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxSize()
        ) {
            Box(modifier = Modifier.width(44.dp), contentAlignment = Alignment.CenterStart) {
                if (isSelected) {
                    PlayingIndicator()
                } else {
                    Text(
                        text = index.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isFocused) Primary else Color.White.copy(alpha = 0.4f),
                        fontSize = 15.sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.04f)),
                contentAlignment = Alignment.Center
            ) {
                ChannelLogo(
                    channel = channel,
                    modifier = Modifier.size(28.dp),
                    iconSize = 22.dp
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = channel.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    fontSize = 17.sp,
                    color = if (isSelected) Primary else Color.White
                )
                
                Text(
                    text = subtitleText,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Quality Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Primary.copy(alpha = 0.15f))
                    .border(1.dp, Primary.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = quality,
                    color = Primary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (isEditMode) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onMove(-1) }, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.KeyboardArrowUp, contentDescription = "Up", tint = Primary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = { onMove(1) }, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "Down", tint = Primary)
                    }
                }
            } else if (channel.isFavorite) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = Primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
