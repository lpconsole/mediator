package com.lpconsole.mediator.util

import android.content.Context
import coil.ImageLoader
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.data.Channel
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

@EntryPoint
@InstallIn(SingletonComponent::class)
interface LogoManagerEntryPoint {
    fun logoManager(): LogoManager
}

@Singleton
class LogoManager @Inject constructor(@ApplicationContext private val context: Context) {
    private val candidateCache = ConcurrentHashMap<String, List<Any>>()
    private val iTunesArtworkCache = ConcurrentHashMap<String, String>()
    private val failedUrls = ConcurrentHashMap.newKeySet<String>()
    private val imageLoader = ImageLoader(context)
    fun getLogoCandidates(channel: Channel?, nowPlayingArtwork: Any? = null): List<Any> {
        if (channel == null) return emptyList()
        val cacheKey = "${channel.id}_${nowPlayingArtwork?.hashCode() ?: 0}"
        candidateCache[cacheKey]?.let { cached ->
            return cached.filter { candidate -> (candidate as? String)?.let { !failedUrls.contains(it) } ?: true }
        }
        val list = mutableListOf<Any>()
        if (channel.type == Prefs.TYPE_FM) {
            if (nowPlayingArtwork != null) {
                list.add(nowPlayingArtwork)
            }
        }
        if (channel.logo.isNotBlank() && !failedUrls.contains(channel.logo)) {
            list.add(channel.logo)
        }
        val domain = getDomain(channel)
        if (!domain.isNullOrBlank()) {
            val faviconUrl = "https://www.google.com/s2/favicons?domain=$domain&sz=128"
            if (!failedUrls.contains(faviconUrl)) {
                list.add(faviconUrl)
            }
        }
        candidateCache[cacheKey] = list
        return list
    }

    fun markCandidateFailed(channelId: String, failedUrl: Any) {
        if (failedUrl is String && failedUrl.isNotBlank()) {
            failedUrls.add(failedUrl)
            candidateCache.keys.filter { it.startsWith(channelId) }.forEach { key ->
                candidateCache.remove(key)
            }
        }
    }

    suspend fun fetchITunesArtwork(channelName: String, metadata: String): String? = withContext(Dispatchers.IO) {
        if (metadata.isBlank()) return@withContext null
        val cacheKey = "$channelName-$metadata"
        iTunesArtworkCache[cacheKey]?.let { return@withContext it }
        try {
            val query = if (metadata.contains(" - ")) metadata else "$channelName $metadata"
            val encoded = URLEncoder.encode(query, "UTF-8")
            val searchUrl = "https://itunes.apple.com/search?media=music&entity=song&limit=1&term=$encoded"
            val conn = URL(searchUrl).openConnection()
            conn.connectTimeout = 3000
            conn.readTimeout = 3000
            val jsonStr = conn.getInputStream().bufferedReader().use { it.readText() }
            val root = JSONObject(jsonStr)
            val results = root.optJSONArray("results")
            if (results != null && results.length() > 0) {
                val first = results.getJSONObject(0)
                val artworkUrl100 = first.optString("artworkUrl100", "")
                if (artworkUrl100.isNotBlank()) {
                    val highResArtwork = artworkUrl100.replace("100x100bb", "600x600bb")
                    iTunesArtworkCache[cacheKey] = highResArtwork
                    return@withContext highResArtwork
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext null
    }

    fun preloadLogos(channels: List<Channel>) {
        val targets = channels.take(30)
        for (channel in targets) {
            val candidates = getLogoCandidates(channel)
            for (candidate in candidates) {
                if (candidate is String && candidate.startsWith("http")) {
                    val request = ImageRequest.Builder(context)
                        .data(candidate)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .memoryCachePolicy(CachePolicy.ENABLED)
                        .build()
                    imageLoader.enqueue(request)
                }
            }
        }
    }

    fun extractDomain(url: String?): String? {
        if (url.isNullOrBlank()) return null
        return runCatching {
            val formatted = if (!url.startsWith("http://") && !url.startsWith("https://")) { "https://$url" } else url
            val uri = URI(formatted)
            val host = uri.host ?: return null
            if (host.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}$"))) return null
            if (host.startsWith("www.")) host.removePrefix("www.") else host
        }.getOrNull()
    }

    private fun getDomain(channel: Channel): String? {
        extractDomain(channel.website)?.let { return it }
        extractDomain(channel.streams.firstOrNull()?.url)?.let { return it }
        return null
    }
}
