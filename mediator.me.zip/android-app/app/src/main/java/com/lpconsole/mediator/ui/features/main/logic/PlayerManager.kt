package com.lpconsole.mediator.ui.features.main.logic

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.OptIn
import androidx.core.net.toUri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Metadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.UnrecognizedInputFormatException
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.metadata.icy.IcyInfo
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.session.MediaSession
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.data.StreamInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import kotlin.math.abs

@OptIn(UnstableApi::class)
@Singleton
class PlayerManager @Inject constructor(@ApplicationContext private val context: Context) {
    private var onErrorAction: (() -> Unit)? = null
    private var onStateChange: ((Boolean) -> Unit)? = null
    private var onMetadataChange: ((String?, Any?) -> Unit)? = null
    private var onZapRequest: ((Int) -> Unit)? = null
    private var onStreamIndexChanged: ((Int) -> Unit)? = null
    @Volatile
    private var onWaveformData: ((FloatArray?) -> Unit)? = null
    @Volatile
    var isVisualizerEnabled: Boolean = false
    private var mediaSession: MediaSession? = null
    private var currentChannel: Channel? = null
    private var currentStreamIndex: Int = 0
    private var currentRetryCount: Int = 0
    private val maxRetriesPerStream: Int = 1
    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentForcedMimeType: String? = null
    private val attemptedMimeTypes = mutableSetOf<String?>()
    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var streamResolveJob: Job? = null
    private var bufferingWatchdogRunnable: Runnable? = null
    private val bufferingTimeoutMs = 12_000L
    private var retryRunnable: Runnable? = null
    private fun cancelRetryRunnable() {
        retryRunnable?.let { mainHandler.removeCallbacks(it) }
        retryRunnable = null
    }
    private fun cancelBufferingWatchdog() {
        bufferingWatchdogRunnable?.let { mainHandler.removeCallbacks(it) }
        bufferingWatchdogRunnable = null
    }
    private fun startBufferingWatchdog() {
        cancelBufferingWatchdog()
        val watchdog = Runnable {
            if (player.playbackState == Player.STATE_BUFFERING && currentChannel != null) {
                Log.w("PlayerManager", "Playback buffering stalled (>12s) on '${currentChannel?.name}'. Triggering fallback/retry...")
                handlePlaybackError(java.net.SocketTimeoutException("Yayın akışı zaman aşımına uğradı (Donma algılandı)"))
            }
        }
        bufferingWatchdogRunnable = watchdog
        mainHandler.postDelayed(watchdog, bufferingTimeoutMs)
    }

    private val okHttpClient: OkHttpClient by lazy {
        val trustAllCerts = arrayOf<TrustManager>(
        @SuppressLint("CustomX509TrustManager")
        object : X509TrustManager {
            @SuppressLint("TrustAllX509TrustManager", "BadHostnameVerifier")
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            @SuppressLint("TrustAllX509TrustManager", "BadHostnameVerifier")
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        })
        val sslContext = SSLContext.getInstance("TLS").apply { init(null, trustAllCerts, SecureRandom()) }
        OkHttpClient.Builder()
            .protocols(listOf(Protocol.HTTP_1_1))
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .sslSocketFactory(sslContext.socketFactory, trustAllCerts[0] as X509TrustManager)
            .hostnameVerifier { _, _ -> true }
            .build()
    }

    fun setOnWaveformData(listener: ((FloatArray?) -> Unit)?) {
        onWaveformData = listener
    }
    private fun handleWaveformData(amplitudes: FloatArray?) {
        if (!isVisualizerEnabled && amplitudes != null) return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            onWaveformData?.invoke(amplitudes)
        } else {
            mainHandler.post {
                onWaveformData?.invoke(amplitudes)
            }
        }
    }
    private fun getInferredReferrer(streamInfo: StreamInfo?): String? {
        val customReferrer = streamInfo?.referrer?.takeIf { it.isNotBlank() }
        if (customReferrer != null) return customReferrer
        val rawUrl = streamInfo?.url ?: return null
        val lowerUrl = rawUrl.lowercase()
        return try {
            val uri = rawUrl.toUri()
            val host = uri.host?.lowercase() ?: ""
            when {
                host.contains("daioncdn.net") || host.contains("turkuvaz") || lowerUrl.contains("/atv") -> "https://www.atv.com.tr/"
                host.contains("ahaber") || lowerUrl.contains("/ahaber") -> "https://www.ahaber.com.tr/"
                host.contains("a2tv") || lowerUrl.contains("/a2") -> "https://www.a2tv.com.tr/"
                host.contains("aspor") || lowerUrl.contains("/aspor") -> "https://www.aspor.com.tr/"
                host.contains("showtv") || host.contains("ciner") || lowerUrl.contains("/show") -> "https://www.showtv.com.tr/"
                host.contains("kanald") || host.contains("demiroren") || lowerUrl.contains("/kanald") -> "https://www.kanald.com.tr/"
                host.contains("startv") || host.contains("dogus") || lowerUrl.contains("/star") -> "https://www.startv.com.tr/"
                host.contains("tv8") || lowerUrl.contains("/tv8") -> "https://www.tv8.com.tr/"
                host.contains("trt") -> "https://www.trttv.com.tr/"
                uri.scheme != null && host.isNotBlank() && !host.contains("cdn") && !host.contains("stream") && !host.contains("ercdn") -> "${uri.scheme}://$host/"
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }
    private fun getCurrentStreamInfo(): StreamInfo? {
        return currentChannel?.streams?.getOrNull(currentStreamIndex)
    }
    @get:OptIn(UnstableApi::class)
    val player: ExoPlayer by lazy {
        val renderersFactory = CustomRenderersFactory(context, ::handleWaveformData) { isVisualizerEnabled }
        val dataSourceFactory = DynamicHttpDataSourceFactory(
            context = context,
            okHttpClient = okHttpClient,
            getCurrentStreamInfo = ::getCurrentStreamInfo,
            getRetryAttempt = { currentRetryCount },
            getInferredReferrer = ::getInferredReferrer
        )
        val extractorsFactory = DefaultExtractorsFactory().apply {
            setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
            setTsExtractorTimestampSearchBytes(1500 * 188)
            setConstantBitrateSeekingEnabled(true)
        }
        val loadErrorHandlingPolicy = object : DefaultLoadErrorHandlingPolicy(1) {
            override fun getRetryDelayMsFor(loadErrorInfo: LoadErrorHandlingPolicy.LoadErrorInfo): Long {
                val exception = loadErrorInfo.exception
                if (exception is HttpDataSource.InvalidResponseCodeException) {
                    val code = exception.responseCode
                    if (code == 403 || code == 401 || code == 404 || code == 410) {
                        return C.TIME_UNSET
                    }
                } else if (exception is HttpDataSource.HttpDataSourceException || exception is UnrecognizedInputFormatException) {
                    return C.TIME_UNSET
                }
                return super.getRetryDelayMsFor(loadErrorInfo)
            }
        }
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory).setLoadErrorHandlingPolicy(loadErrorHandlingPolicy)
        ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    Log.e("PlayerManager", "Playback Error on '${currentChannel?.name}' (Stream $currentStreamIndex): ${error.message}", error)
                    handlePlaybackError(error)
                }
                override fun onPlaybackStateChanged(state: Int) {
                    val isBuffering = state == Player.STATE_BUFFERING
                    onStateChange?.invoke(isBuffering)
                    if (isBuffering) {
                        startBufferingWatchdog()
                    } else {
                        cancelBufferingWatchdog()
                    }
                    if (state == Player.STATE_ENDED) {
                        onWaveformData?.invoke(null)
                        if (currentChannel != null) {
                            Log.w("PlayerManager", "Live stream unexpectedly ended/disconnected on '${currentChannel?.name}'. Retrying or switching to next stream...")
                            handlePlaybackError(IllegalStateException("Canlı yayın sunucu tarafından sonlandırıldı"))
                        }
                    } else if (state == Player.STATE_IDLE) {
                        onWaveformData?.invoke(null)
                    }
                }
                override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                    val title = mediaMetadata.title?.toString()
                    val artist = mediaMetadata.artist?.toString()
                    val nowPlaying = if (title != null && artist != null) "$artist - $title" else title ?: artist
                    val artwork = mediaMetadata.artworkData ?: mediaMetadata.artworkUri
                    onMetadataChange?.invoke(nowPlaying, artwork)
                }
                @OptIn(UnstableApi::class)
                override fun onMetadata(metadata: Metadata) {
                    for (i in 0 until metadata.length()) {
                        val entry = metadata.get(i)
                        if (entry is IcyInfo) {
                            val title = entry.title
                            if (!title.isNullOrBlank()) {
                                onMetadataChange?.invoke(title, null)
                            }
                        }
                    }
                }
                override fun onVideoSizeChanged(videoSize: VideoSize) {}
                override fun onTracksChanged(tracks: Tracks) {}
            })
        }
    }

    fun setOnErrorAction(action: (() -> Unit)?) {
        onErrorAction = action
    }

    private fun invokeOnErrorAction() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            onErrorAction?.invoke()
        } else {
            mainHandler.post { onErrorAction?.invoke() }
        }
    }
    fun setOnStateChange(action: (Boolean) -> Unit) { onStateChange = action }
    fun setOnMetadataChange(action: (String?, Any?) -> Unit) { onMetadataChange = action }
    fun setOnZapRequest(action: (Int) -> Unit) { onZapRequest = action }
    fun setOnStreamIndexChanged(action: (Int) -> Unit) { onStreamIndexChanged = action }
    fun play(channel: Channel) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { play(channel) }
            return
        }
        cancelRetryRunnable()
        cancelBufferingWatchdog()
        streamResolveJob?.cancel()
        currentChannel = channel
        currentStreamIndex = 0
        currentRetryCount = 0
        currentForcedMimeType = null
        attemptedMimeTypes.clear()
        onStreamIndexChanged?.invoke(0)
        playCurrentStream()
    }

    private suspend fun resolveStreamUrl(rawUrl: String): String = withContext(Dispatchers.IO) {
        var url = rawUrl.trim()
        if (url.startsWith("icy://", ignoreCase = true)) {
            url = "http://" + url.substring(6)
        } else if (url.startsWith("itpc://", ignoreCase = true) || url.startsWith("pnm://", ignoreCase = true)) {
            url = "http://" + url.substring(7)
        }
        val lower = url.lowercase()
        val isPlaylistExt = lower.endsWith(".pls") || (lower.endsWith(".m3u") && !lower.endsWith(".m3u8")) || lower.endsWith(".asx") || lower.contains("type=pls") || lower.contains("format=pls") || lower.contains("type=m3u")
        if (!isPlaylistExt) { return@withContext url }
        try {
            val streamInfo = getCurrentStreamInfo()
            val customUa = streamInfo?.userAgent?.takeIf { it.isNotBlank() }
            val ua = customUa ?: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            val requestBuilder = Request.Builder().url(url).header("User-Agent", ua).header("Accept", "*/*")
            val customReferrer = getInferredReferrer(streamInfo)
            if (customReferrer != null) {
                requestBuilder.header("Referer", customReferrer)
                try {
                    val uri = customReferrer.toUri()
                    if (uri.scheme != null && uri.host != null) {
                        requestBuilder.header("Origin", "${uri.scheme}://${uri.host}")
                    }
                } catch (_: Exception) {}
            }
            okHttpClient.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) return@withContext url
                val finalUrl = response.request.url.toString()
                val body = response.body
                val contentType = body.contentType()?.toString()?.lowercase() ?: ""
                val isPlaylistContent = contentType.contains("audio/x-scpls") || contentType.contains("audio/x-mpegurl") || contentType.contains("text/playlist") || contentType.contains("audio/mpegurl")
                if (isPlaylistContent) {
                    val bodyText = body.string()
                    val parsed = parsePlaylistContent(bodyText)
                    if (!parsed.isNullOrBlank()) {
                        Log.i("PlayerManager", "Resolved playlist URL '$url' -> '$parsed'")
                        return@withContext parsed
                    }
                }
                return@withContext finalUrl
            }
        } catch (e: Exception) {
            Log.w("PlayerManager", "Could not resolve stream URL $url: ${e.message}")
            return@withContext url
        }
    }

    private fun parsePlaylistContent(content: String): String? {
        val lines = content.lines().map { it.trim() }
        for (line in lines) {
            if (line.startsWith("File", ignoreCase = true) && line.contains("=")) {
                val candidate = line.substringAfter("=").trim()
                if (candidate.startsWith("http://", ignoreCase = true) || candidate.startsWith("https://", ignoreCase = true)) {
                    return candidate
                }
            }
        }
        for (line in lines) {
            if (!line.startsWith("#") && (line.startsWith("http://", ignoreCase = true) || line.startsWith("https://", ignoreCase = true))) {
                return line
            }
        }
        return null
    }

    private fun inferMimeType(url: String): String? {
        val lower = url.lowercase()
        return when {
            lower.contains(".m3u8") || lower.contains("format=m3u8") ||
            lower.contains("format=hls") || lower.contains("output=hls") ||
            lower.contains("output=m3u8") || lower.contains("/hls/") || lower.contains("/hls?") -> {
                MimeTypes.APPLICATION_M3U8
            }
            lower.contains(".mpd") || lower.contains("type=mpd") || lower.contains("format=mpd") || lower.contains("/dash/") -> {
                MimeTypes.APPLICATION_MPD
            }
            lower.contains(".ism") || lower.contains("/manifest") -> {
                MimeTypes.APPLICATION_SS
            }
            lower.endsWith(".mp3") || lower.contains("format=mp3") -> MimeTypes.AUDIO_MPEG
            lower.endsWith(".aac") || lower.contains("format=aac") -> MimeTypes.AUDIO_AAC
            lower.endsWith(".flac") -> MimeTypes.AUDIO_FLAC
            lower.endsWith(".ogg") || lower.endsWith(".oga") -> MimeTypes.AUDIO_OGG
            lower.endsWith(".wav") -> MimeTypes.AUDIO_WAV
            lower.endsWith(".mp4") || lower.endsWith(".m4v") || lower.endsWith(".m4a") -> MimeTypes.VIDEO_MP4
            lower.endsWith(".mkv") || lower.endsWith(".webm") -> MimeTypes.VIDEO_WEBM
            lower.endsWith(".flv") -> MimeTypes.VIDEO_FLV
            else -> null
        }
    }

    private fun isUnrecognizedFormat(error: Throwable?): Boolean {
        var cause: Throwable? = error
        while (cause != null) {
            if (cause is UnrecognizedInputFormatException) return true
            val msg = cause.message
            if (msg != null) {
                if (msg.contains("UnrecognizedInputFormatException", ignoreCase = true) ||
                    msg.contains("None of the available extractors", ignoreCase = true) ||
                    msg.contains("sniff failures", ignoreCase = true)
                ) {
                    return true
                }
            }
            cause = cause.cause
        }
        return false
    }

    fun playCurrentStream() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { playCurrentStream() }
            return
        }
        cancelRetryRunnable()
        streamResolveJob?.cancel()
        val channel = currentChannel ?: return
        if (channel.streams.isEmpty()) {
            invokeOnErrorAction()
            return
        }
        val streamInfo = channel.streams.getOrNull(currentStreamIndex) ?: run {
            invokeOnErrorAction()
            return
        }
        val rawStreamUrl = streamInfo.url
        if (rawStreamUrl.isBlank()) {
            invokeOnErrorAction()
            return
        }
        streamResolveJob = coroutineScope.launch {
            val resolvedUrl = resolveStreamUrl(rawStreamUrl)
            if (!isActive) return@launch
            try {
                val mimeTypeToUse = currentForcedMimeType ?: inferMimeType(resolvedUrl)
                attemptedMimeTypes.add(mimeTypeToUse)
                val mediaItemBuilder = MediaItem.Builder().setUri(resolvedUrl.toUri())
                if (!mimeTypeToUse.isNullOrBlank()) {
                    mediaItemBuilder.setMimeType(mimeTypeToUse)
                }
                val mediaItem = mediaItemBuilder.build()
                Log.d("PlayerManager", "Playing stream index $currentStreamIndex for '${channel.name}', Raw URL: $rawStreamUrl, Resolved URL: $resolvedUrl, MimeType: ${mimeTypeToUse ?: "AUTO"}")
                player.setMediaItem(mediaItem, true)
                player.prepare()
                player.playWhenReady = true
            } catch (e: Exception) {
                Log.w("PlayerManager", "Error preparing stream $resolvedUrl: ${e.message}")
                handlePlaybackError(e)
            }
        }
    }

    private fun getHttpInvalidResponseCode(error: Throwable?): Int? {
        var cause: Throwable? = error
        while (cause != null) {
            if (cause is HttpDataSource.InvalidResponseCodeException) {
                return cause.responseCode
            }
            cause = cause.cause
        }
        return null
    }

    private fun handlePlaybackError(error: Throwable) {
        cancelRetryRunnable()
        cancelBufferingWatchdog()
        val channel = currentChannel
        val streamUrl = getCurrentStreamUrl()
        if (isUnrecognizedFormat(error) && streamUrl != null) {
            if (!attemptedMimeTypes.contains(MimeTypes.APPLICATION_M3U8)) {
                Log.w("PlayerManager", "Unrecognized input format for '$streamUrl'. Falling back to HLS...")
                currentForcedMimeType = MimeTypes.APPLICATION_M3U8
                playCurrentStream()
                return
            } else if (!attemptedMimeTypes.contains(MimeTypes.VIDEO_MP2T)) {
                Log.w("PlayerManager", "Unrecognized input format for '$streamUrl'. Falling back to TS container...")
                currentForcedMimeType = MimeTypes.VIDEO_MP2T
                playCurrentStream()
                return
            } else if (!attemptedMimeTypes.contains(null)) {
                Log.w("PlayerManager", "Unrecognized input format for '$streamUrl'. Falling back to Progressive AUTO...")
                currentForcedMimeType = null
                playCurrentStream()
                return
            }
        }
        val httpCode = getHttpInvalidResponseCode(error)
        val maxAllowedRetries = if (httpCode == 403 || httpCode == 401) 1 else maxRetriesPerStream

        if (currentRetryCount < maxAllowedRetries) {
            currentRetryCount++
            val delayMs = currentRetryCount * 400L
            Log.w("PlayerManager", "Retrying stream index $currentStreamIndex for '${channel?.name}' (${error.message ?: "HTTP $httpCode"}, attempt $currentRetryCount/$maxAllowedRetries) in ${delayMs}ms...")
            val runnable = Runnable { playCurrentStream() }
            retryRunnable = runnable
            mainHandler.postDelayed(runnable, delayMs)
            return
        }
        currentRetryCount = 0
        currentForcedMimeType = null
        attemptedMimeTypes.clear()
        if (!retryWithNextStream()) {
            invokeOnErrorAction()
        }
    }

    private fun retryWithNextStream(): Boolean {
        val channel = currentChannel ?: return false
        if (currentStreamIndex + 1 < channel.streams.size) {
            currentStreamIndex++
            currentRetryCount = 0
            currentForcedMimeType = null
            attemptedMimeTypes.clear()
            onStreamIndexChanged?.invoke(currentStreamIndex)
            Log.i("PlayerManager", "Switching to next stream index $currentStreamIndex for '${channel.name}'...")
            playCurrentStream()
            return true
        }
        return false
    }

    fun switchStream(index: Int) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { switchStream(index) }
            return
        }
        val channel = currentChannel ?: return
        if (index in channel.streams.indices) {
            cancelRetryRunnable()
            cancelBufferingWatchdog()
            streamResolveJob?.cancel()
            currentStreamIndex = index
            currentRetryCount = 0
            currentForcedMimeType = null
            attemptedMimeTypes.clear()
            onStreamIndexChanged?.invoke(index)
            Log.i("PlayerManager", "Switched to stream index $index for '${channel.name}'...")
            playCurrentStream()
        }
    }

    fun getCurrentStreamUrl(): String? {
        return currentChannel?.streams?.getOrNull(currentStreamIndex)?.url
    }

    fun getMediaSession(): MediaSession? {
        if (mediaSession == null) {
            try {
                mediaSession = MediaSession.Builder(context, player).build()
            } catch (e: Exception) {
                Log.e("PlayerManager", "Failed to create MediaSession: ${e.message}")
            }
        }
        return mediaSession
    }

    @OptIn(UnstableApi::class)
    fun selectTrack(groupIndex: Int, trackIndex: Int) {
        val tracks = player.currentTracks
        var currentGroupIndex = 0
        tracks.groups.forEach { group ->
            if (currentGroupIndex == groupIndex) {
                val override = TrackSelectionOverride(group.mediaTrackGroup, trackIndex)
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setOverrideForType(override)
                    .build()
                return
            }
            currentGroupIndex++
        }
    }

    fun updateMediaSessionMetadata() { }

    fun release() {
        cancelRetryRunnable()
        cancelBufferingWatchdog()
        streamResolveJob?.cancel()
        coroutineScope.cancel()
        onWaveformData?.invoke(null)
        try {
            mediaSession?.release()
            mediaSession = null
        } catch (_: Exception) {}
        player.release()
    }
}

@OptIn(UnstableApi::class)
private class DynamicHttpDataSourceFactory(
    private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val getCurrentStreamInfo: () -> StreamInfo?,
    private val getRetryAttempt: () -> Int,
    private val getInferredReferrer: (StreamInfo?) -> String?
) : DataSource.Factory {
    private val fallbackUserAgents = listOf(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "VLC/3.0.20 LibVLC/3.0.20",
        "IPTVSmarters/3.1.5",
        "Mozilla/5.0 (SmartHub; SMART-TV; U; Linux/SmartTV) AppleWebKit/537.36 (KHTML, like Gecko) Internet TV Safari/537.36",
        "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 ExoPlayer/2.18.0",
        "GTS/1.0"
    )
    override fun createDataSource(): DataSource {
        val streamInfo = getCurrentStreamInfo()
        val retryCount = getRetryAttempt()
        val customUa = streamInfo?.userAgent?.takeIf { it.isNotBlank() }
        val selectedUa = if (retryCount == 0 && customUa != null) {
            customUa
        } else {
            fallbackUserAgents.getOrElse(retryCount % fallbackUserAgents.size) { fallbackUserAgents[0] }
        }
        val headers = mutableMapOf(
            "Accept" to "*/*",
            "Accept-Language" to "en-US,en;q=0.9,tr;q=0.8",
            "Connection" to "keep-alive"
        )
        val currentUrl = streamInfo?.url?.lowercase() ?: ""
        val isVideoOrHls =
                currentUrl.contains(".m3u8") || currentUrl.contains(".mpd") ||
                currentUrl.contains(".ts") || currentUrl.contains(".mp4") ||
                currentUrl.contains("/hls/") || currentUrl.contains("format=m3u8")
        if (retryCount == 0 && !isVideoOrHls) { headers["Icy-MetaData"] = "1" }
        val inferredReferrer = getInferredReferrer(streamInfo)
        if (inferredReferrer != null) {
            headers["Referer"] = inferredReferrer
            try {
                val uri = inferredReferrer.toUri()
                if (uri.scheme != null && uri.host != null) { headers["Origin"] = "${uri.scheme}://${uri.host}" }
            } catch (_: Exception) {}
        }
        val httpDataSourceFactory = OkHttpDataSource.Factory(okHttpClient).setUserAgent(selectedUa).setDefaultRequestProperties(headers)
        return DefaultDataSource.Factory(context, httpDataSourceFactory).createDataSource()
    }
}

@OptIn(UnstableApi::class)
private class CustomRenderersFactory(
    context: Context,
    private val onWaveformData: (FloatArray?) -> Unit,
    private val isVisualizerEnabled: () -> Boolean
) : DefaultRenderersFactory(context) {
    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink {
        return DefaultAudioSink.Builder(context)
            .setAudioProcessors(arrayOf(VisualizerAudioProcessor(onWaveformData, isVisualizerEnabled)))
            .build()
    }
}

@OptIn(UnstableApi::class)
private class VisualizerAudioProcessor(
    private val onWaveformData: (FloatArray?) -> Unit,
    private val isVisualizerEnabled: () -> Boolean
) : AudioProcessor {
    private var audioEncoding = C.ENCODING_INVALID
    private var isActive = false
    private var outputBuffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER
    private var buffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER
    private val bandCount = 32
    private val smoothedAmplitudes = FloatArray(bandCount)
    private val reusableResultBands = FloatArray(bandCount)
    private var lastEmitTimeMs = 0L

    override fun configure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        this.audioEncoding = inputAudioFormat.encoding
        val supported = inputAudioFormat.encoding == C.ENCODING_PCM_16BIT ||
                inputAudioFormat.encoding == C.ENCODING_PCM_8BIT ||
                inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        isActive = supported && isVisualizerEnabled()
        return if (isActive) inputAudioFormat else AudioProcessor.AudioFormat.NOT_SET
    }

    override fun isActive(): Boolean = isActive && isVisualizerEnabled()

    override fun queueInput(inputBuffer: ByteBuffer) {
        val position = inputBuffer.position()
        val limit = inputBuffer.limit()
        val remaining = limit - position
        if (remaining < 4) {
            outputBuffer = AudioProcessor.EMPTY_BUFFER
            return
        }
        val now = System.currentTimeMillis()
        if (isVisualizerEnabled() && now - lastEmitTimeMs >= 60L) {
            lastEmitTimeMs = now
            val is16Bit = audioEncoding == C.ENCODING_PCM_16BIT
            val totalShorts = if (is16Bit) remaining / 2 else remaining
            val shortsPerBand = (totalShorts / bandCount).coerceAtLeast(1)
            var totalMaxEnergy = 0f
            for (b in 0 until bandCount) {
                var sumEnergy = 0f
                val startIdx = position + (b * shortsPerBand * (if (is16Bit) 2 else 1))
                val sampleCount = shortsPerBand.coerceAtMost(32)
                for (s in 0 until sampleCount) {
                    val bytePos = startIdx + (s * (if (is16Bit) 2 else 1))
                    if (bytePos + (if (is16Bit) 1 else 0) < limit) {
                        val rawNorm = if (is16Bit) {
                            abs(inputBuffer.getShort(bytePos).toFloat()) / 32768f
                        } else {
                            abs((inputBuffer.get(bytePos).toInt() and 0xFF) - 128) / 128f
                        }
                        sumEnergy += rawNorm
                    }
                }
                val bandAvg = if (sampleCount > 0) sumEnergy / sampleCount else 0f
                if (bandAvg > totalMaxEnergy) totalMaxEnergy = bandAvg
                smoothedAmplitudes[b] = smoothedAmplitudes[b] * 0.55f + bandAvg * 0.45f
            }
            if (totalMaxEnergy < 0.015f) {
                smoothedAmplitudes.fill(0f)
                onWaveformData(null)
            } else {
                for (i in 0 until bandCount) {
                    val sign = if (i % 2 == 0) 1f else -1f
                    reusableResultBands[i] = smoothedAmplitudes[i] * sign
                }
                onWaveformData(reusableResultBands.clone())
            }
        }
        if (buffer.capacity() < remaining) {
            buffer = ByteBuffer.allocateDirect(remaining).order(ByteOrder.nativeOrder())
        } else {
            buffer.clear()
        }
        buffer.put(inputBuffer)
        buffer.flip()
        outputBuffer = buffer
    }

    override fun queueEndOfStream() {
        smoothedAmplitudes.fill(0f)
        if (isVisualizerEnabled()) onWaveformData(null)
    }

    override fun getOutput(): ByteBuffer {
        val b = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return b
    }

    override fun isEnded(): Boolean = false

    @Deprecated("Deprecated in Java")
    override fun flush() {
        smoothedAmplitudes.fill(0f)
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        buffer = AudioProcessor.EMPTY_BUFFER
        if (isVisualizerEnabled()) onWaveformData(null)
    }

    override fun reset() {
        smoothedAmplitudes.fill(0f)
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        buffer = AudioProcessor.EMPTY_BUFFER
        if (isVisualizerEnabled()) onWaveformData(null)
        isActive = false
    }
}
