package com.lpconsole.mediator.util

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.core.content.FileProvider
import androidx.core.content.edit
import com.lpconsole.mediator.BuildConfig
import com.lpconsole.mediator.RadioPosterCatalog
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Centralized manager for all GitHub API interactions, releases, updates, and asset downloads.
 */
@Singleton
class GitHubManager @Inject constructor(@ApplicationContext private val context: Context) {
    val repository: String = BuildConfig.GITHUB_REPOSITORY
    val latestReleaseApiUrl: String = "https://api.github.com/repos/$repository/releases/latest"
    val gifsApiUrl: String = "https://api.github.com/repos/$repository/contents/gifs?ref=main"
    val rawGifsBaseUrl: String = "https://raw.githubusercontent.com/$repository/main/gifs/"
    private val userAgent = "Mediator/${BuildConfig.VERSION_NAME}"
    private val updatePrefs: SharedPreferences = context.getSharedPreferences("update_prefs", Context.MODE_PRIVATE)
    companion object {
        private const val MANIFEST_CACHE_NAME = "radio_posters.json"
        private const val POSTER_CACHE_DIR = "radio_posters"
        private const val MANIFEST_MAX_AGE_MS = 48L * 60L * 60L * 1000L // 2 gün
        private const val MAX_POSTER_BYTES = 50L * 1024L * 1024L // 50MB
        const val DEFAULT_POSTER_CODE = "1.gif"
    }
    data class UpdateInfo(
        val latestVersion: String,
        val downloadUrl: String,
        val apkSize: Long,
        val releaseNotes: String
    )
    // ==========================================
    // 1. APP UPDATES & RELEASES
    // ==========================================
    suspend fun checkForUpdate(currentVersion: String, forceCheck: Boolean = false): UpdateInfo? = withContext(Dispatchers.IO) {
        val lastCheckTime = updatePrefs.getLong("last_check_time", 0L)
        val now = System.currentTimeMillis()
        val checkIntervalMs = 15L * 60L * 1000L // 15 dakika
        if (!forceCheck && (now - lastCheckTime < checkIntervalMs)) {
            return@withContext null
        }
        try {
            val connection = openConnection(latestReleaseApiUrl)
            if (connection.responseCode == 200) {
                updatePrefs.edit { putLong("last_check_time", now) }
                val json = connection.inputStream.bufferedReader().use { it.readText() }
                val release = JSONObject(json)
                val tagName = release.getString("tag_name").trim().trimStart('v', 'V', '.').trim()
                val cleanCurrent = currentVersion.trim().trimStart('v', 'V', '.').trim()
                val releaseNotes = release.optString("body", "Yeni performans iyileştirmeleri ve hata düzeltmeleri.").trim()
                if (isVersionNewer(tagName, cleanCurrent)) {
                    val assets = release.getJSONArray("assets")
                    var downloadUrl = ""
                    var apkSize = 0L
                    for (i in 0 until assets.length()) {
                        val asset = assets.getJSONObject(i)
                        val name = asset.getString("name")
                        if (name.endsWith(".apk", ignoreCase = true)) {
                            downloadUrl = asset.getString("browser_download_url")
                            apkSize = asset.optLong("size", 0L)
                            if (name.equals("app-release.apk", ignoreCase = true)) {
                                break
                            }
                        }
                    }
                    if (downloadUrl.isNotEmpty()) {
                        return@withContext UpdateInfo(
                            latestVersion = tagName,
                            downloadUrl = downloadUrl,
                            apkSize = apkSize,
                            releaseNotes = releaseNotes.ifEmpty { "Yeni güncellemeler ve iyileştirmeler içerir." }
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        null
    }

    suspend fun downloadUpdateApk(
        downloadUrl: String,
        expectedSize: Long,
        onProgress: (progress: Float, downloadedBytes: Long) -> Unit
    ): File = withContext(Dispatchers.IO) {
        var currentUrl = downloadUrl
        var connection: HttpURLConnection? = null
        var redirects = 0
        val maxRedirects = 6

        while (redirects < maxRedirects) {
            val conn = openConnection(currentUrl)
            conn.instanceFollowRedirects = true
            val status = conn.responseCode
            if (status in 300..399) {
                val newUrl = conn.getHeaderField("Location")
                conn.disconnect()
                if (!newUrl.isNullOrEmpty()) {
                    currentUrl = newUrl
                    redirects++
                    continue
                }
            }
            connection = conn
            break
        }

        val finalConn = connection ?: throw IOException("Bağlantı kurulamadı: $downloadUrl")
        if (finalConn.responseCode !in 200..299) {
            val code = finalConn.responseCode
            finalConn.disconnect()
            throw IOException("Sunucu yanıtı geçersiz: HTTP $code")
        }

        val fileLength = if (finalConn.contentLengthLong > 0) finalConn.contentLengthLong else expectedSize
        val updatesDir = File(context.cacheDir, "updates")
        if (!updatesDir.exists()) {
            updatesDir.mkdirs()
        }
        val apkFile = File(updatesDir, "app-release.apk")
        val tempFile = File(updatesDir, "app-release.apk.tmp")
        if (tempFile.exists()) tempFile.delete()

        try {
            finalConn.inputStream.use { input ->
                FileOutputStream(tempFile).use { output ->
                    val data = ByteArray(16384)
                    var total: Long = 0
                    var count: Int
                    var lastUpdateMs = 0L

                    while (input.read(data).also { count = it } != -1) {
                        output.write(data, 0, count)
                        total += count.toLong()

                        val now = System.currentTimeMillis()
                        if (now - lastUpdateMs > 80 || total == fileLength) {
                            lastUpdateMs = now
                            val progress = if (fileLength > 0) (total * 100f / fileLength).coerceIn(0f, 100f) else 0f
                            onProgress(progress, total)
                        }
                    }
                    output.flush()
                }
            }
            if (apkFile.exists()) apkFile.delete()
            if (!tempFile.renameTo(apkFile)) {
                tempFile.copyTo(apkFile, overwrite = true)
                tempFile.delete()
            }
            onProgress(100f, apkFile.length())
            apkFile
        } catch (e: Exception) {
            if (tempFile.exists()) tempFile.delete()
            throw e
        } finally {
            finalConn.disconnect()
        }
    }

    fun installApk(file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    private fun isVersionNewer(latest: String, current: String): Boolean {
        if (latest == current) return false
        val latestParts = latest.split(".").mapNotNull { it.toIntOrNull() }
        val currentParts = current.split(".").mapNotNull { it.toIntOrNull() }
        val maxLength = maxOf(latestParts.size, currentParts.size)
        for (i in 0 until maxLength) {
            val l = latestParts.getOrElse(i) { 0 }
            val c = currentParts.getOrElse(i) { 0 }
            if (l > c) return true
            if (l < c) return false
        }
        return false
    }

    // ==========================================
    // 2. RADIO POSTER CATALOG & REPO ASSETS
    // ==========================================
    suspend fun loadRadioPosters(preferFresh: Boolean = false): List<RadioPosterCatalog.Poster> = withContext(Dispatchers.IO) {
        val cacheFile = File(context.cacheDir, MANIFEST_CACHE_NAME)
        if (!preferFresh && cacheFile.exists() && System.currentTimeMillis() - cacheFile.lastModified() < MANIFEST_MAX_AGE_MS) {
            try {
                val cached = parsePosterManifest(readFile(cacheFile))
                if (cached.isNotEmpty()) return@withContext cached
            } catch (_: IOException) {}
        }
        try {
            val fresh = readUrlText(gifsApiUrl)
            val posters = parsePosterManifest(fresh)
            if (posters.isNotEmpty()) {
                writeFileText(cacheFile, fresh)
                posters
            } else {
                emptyList()
            }
        } catch (_: IOException) {
            if (cacheFile.exists()) {
                try {
                    val cached = parsePosterManifest(readFile(cacheFile))
                    if (cached.isNotEmpty()) return@withContext cached
                } catch (_: IOException) {}
            }
            emptyList()
        }
    }

    fun selectedPoster(posters: List<RadioPosterCatalog.Poster>?, savedCode: String?): RadioPosterCatalog.Poster? {
        if (posters.isNullOrEmpty()) return null
        val normalized = normalizePosterCode(savedCode)
        return posters.find { it.code.equals(normalized, ignoreCase = true) } ?: posters.firstOrNull()
    }

    fun normalizePosterCode(code: String?): String {
        var value = code?.trim() ?: ""
        if (value.isEmpty() || value.equals("default", ignoreCase = true) || value.equals("default.gif", ignoreCase = true)) {
            return DEFAULT_POSTER_CODE
        }
        if (value.startsWith("poster_")) { value = value.removePrefix("poster_") }
        if (!value.lowercase(Locale.US).endsWith(".gif")) { value += ".gif" }
        return value
    }

    fun cleanupOldPosterCaches(validPosters: List<RadioPosterCatalog.Poster>) {
        try {
            val dir = File(context.cacheDir, POSTER_CACHE_DIR)
            if (!dir.exists() || !dir.isDirectory) return
            val validNames = validPosters.map { safeFileName(it.code) }.toSet()
            val files = dir.listFiles() ?: return
            for (file in files) {
                if (file.isFile && !validNames.contains(file.name)) {
                    file.delete()
                }
            }
        } catch (_: Exception) {}
    }

    suspend fun downloadRadioPoster(poster: RadioPosterCatalog.Poster): File = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, POSTER_CACHE_DIR)
        if (!dir.exists() && !dir.mkdirs()) {
            throw IOException("Poster cache hazırlanamadı")
        }
        val target = File(dir, safeFileName(poster.code))
        if (target.exists() && target.length() > 0L) {
            return@withContext target
        }
        val temp = File(dir, target.name + ".tmp")
        var lastError: IOException? = null
        val candidates = listOf(poster.downloadUrl, rawGifsBaseUrl + URLEncoder.encode(poster.code, "UTF-8"))
        for (url in candidates) {
            var connection: HttpURLConnection? = null
            try {
                connection = openConnection(url)
                if (connection.responseCode !in 200..299) continue
                if (connection.contentLengthLong > MAX_POSTER_BYTES) {
                    throw IOException("Poster dosyası çok büyük")
                }
                connection.inputStream.use { input ->
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            output.write(buffer, 0, read)
                        }
                    }
                }
                if (temp.renameTo(target)) return@withContext target
            } catch (error: IOException) {
                lastError = error
                if (temp.exists()) temp.delete()
            } finally {
                connection?.disconnect()
            }
        }
        throw lastError ?: IOException("Poster indirilemedi: ${poster.code}")
    }

    private fun parsePosterManifest(json: String): List<RadioPosterCatalog.Poster> {
        val posters = mutableListOf<RadioPosterCatalog.Poster>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                if (!"file".equals(obj.optString("type", ""), ignoreCase = true)) continue
                val name = obj.optString("name", "").trim()
                if (!name.lowercase(Locale.US).endsWith(".gif")) continue
                val downloadUrl = obj.optString("download_url", "").trim()
                if (downloadUrl.isNotEmpty()) {
                    posters.add(RadioPosterCatalog.Poster(name, labelFromPosterCode(name), downloadUrl))
                }
            }
        } catch (_: Exception) {}
        posters.sortWith(compareBy({ extractNumber(it.code) }, { it.code.lowercase() }))
        return posters
    }

    private fun labelFromPosterCode(code: String): String {
        var name = code
        if (name.lowercase(Locale.US).endsWith(".gif")) {
            name = name.substring(0, name.length - 4)
        }
        return "Poster $name"
    }

    private fun extractNumber(s: String): Int {
        val digits = s.filter { it.isDigit() }
        return digits.toIntOrNull() ?: Int.MAX_VALUE
    }

    private fun safeFileName(value: String): String {
        return value.replace("[^A-Za-z0-9._-]".toRegex(), "_")
    }

    private fun readUrlText(urlString: String): String {
        var connection: HttpURLConnection? = null
        try {
            connection = openConnection(urlString)
            if (connection.responseCode !in 200..299) throw IOException("HTTP ${connection.responseCode}")
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection?.disconnect()
        }
    }

    // ==========================================
    // 3. COMMON NETWORK UTILS
    // ==========================================
    @Throws(IOException::class)
    fun openConnection(urlString: String): HttpURLConnection {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.connectTimeout = 10000
        connection.readTimeout = 20000
        connection.setRequestProperty("User-Agent", userAgent)
        connection.instanceFollowRedirects = true
        return connection
    }

    private fun readFile(file: File): String {
        return String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8)
    }

    private fun writeFileText(file: File, value: String) {
        file.writeText(value)
    }
}