package com.lpconsole.mediator

import android.content.Context
import android.util.Log
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.zip.GZIPInputStream

class TvProgramGuide {
    companion object {
        private const val USER_AGENT = "MediatorTV/${BuildConfig.VERSION_NAME}"
        private const val EPG_CACHE_MAX_AGE_MS = 60L * 60L * 1000L
        private val GUIDE_ZONE: ZoneId = ZoneId.of("Europe/Istanbul")
        private val XMLTV_TIME_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss Z", Locale.US)
    }

    private var epgIndexMap = mutableMapOf<String, String>()
    private var lastIndexTime = 0L
    private val indexLock = Any()

    fun currentProgram(context: Context, channelName: String, country: String): String? {
        val cCode = clean(country).uppercase().ifEmpty { "TR" }
        val normalizedChannelName = normalizeName(channelName)
        if (normalizedChannelName.isEmpty()) {
            return null
        }
        synchronized(indexLock) {
            val nowMs = System.currentTimeMillis()
            if (epgIndexMap.isEmpty() || nowMs - lastIndexTime > 15 * 60 * 1000L) {
                val map = loadAndParseTvGuide(context, cCode)
                if (map.isNotEmpty()) {
                    epgIndexMap = map
                    lastIndexTime = nowMs
                }
            }
        }
        epgIndexMap[normalizedChannelName]?.let { return it }
        for ((guideNormName, progText) in epgIndexMap) {
            if (namesMatch(normalizedChannelName, guideNormName)) {
                return progText
            }
        }
        return null
    }

    private fun loadAndParseTvGuide(context: Context, countryCode: String): MutableMap<String, String> {
        val c = countryCode.uppercase().ifEmpty { "TR" }
        val cacheFile = File(context.cacheDir, "tv_epg_${c.lowercase()}.xml")

        if (cacheFile.exists() && System.currentTimeMillis() - cacheFile.lastModified() < EPG_CACHE_MAX_AGE_MS) {
            try {
                FileInputStream(cacheFile).use { input ->
                    val result = parseXmltypeStream(input)
                    if (result.isNotEmpty()) return result
                }
            } catch (_: Exception) {}
        }

        val urlsToTry = listOf(
            "https://epg.lat/files/${c.lowercase()}.xml.gz",
            "https://epg.lat/files/tr.xml.gz",
            "https://epgshare01.online/epgshare01/epg_ripper_${c}1.xml.gz"
        )

        for (urlString in urlsToTry) {
            try {
                val url = URL(urlString)
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12_000
                    readTimeout = 12_000
                    setRequestProperty("User-Agent", USER_AGENT)
                }
                if (connection.responseCode in 200..299) {
                    val rawStream = connection.inputStream
                    val inputStream = if (urlString.endsWith(".gz", true)) GZIPInputStream(rawStream) else rawStream

                    FileOutputStream(cacheFile).use { output ->
                        val buffer = ByteArray(8192)
                        var bytesRead: Int
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                        }
                    }
                    rawStream.close()

                    FileInputStream(cacheFile).use { input ->
                        val parsed = parseXmltypeStream(input)
                        if (parsed.isNotEmpty()) return parsed
                    }
                }
            } catch (_: Exception) {
                continue
            }
        }

        if (cacheFile.exists()) {
            try {
                FileInputStream(cacheFile).use { input ->
                    return parseXmltypeStream(input)
                }
            } catch (_: Exception) {}
        }
        return mutableMapOf()
    }

    private fun parseXmltypeStream(inputStream: InputStream): MutableMap<String, String> {
        val result = mutableMapOf<String, String>()
        val nameToChannelId = mutableMapOf<String, String>()
        val currentPrograms = mutableMapOf<String, String>()
        val nextPrograms = mutableMapOf<String, String>()
        val now = ZonedDateTime.now(GUIDE_ZONE)

        try {
            val parser = Xml.newPullParser()
            val reader = inputStream.bufferedReader(StandardCharsets.UTF_8)
            reader.mark(1)
            var c = reader.read()
            while (c != -1 && c != '<'.code) {
                reader.mark(1)
                c = reader.read()
            }
            if (c == '<'.code) {
                reader.reset()
            }
            parser.setInput(reader)
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    val tag = parser.name
                    if ("channel" == tag) {
                        val channelId = clean(parser.getAttributeValue(null, "id"))
                        if (channelId.isNotEmpty()) {
                            while (parser.next() != XmlPullParser.END_DOCUMENT) {
                                if (parser.eventType == XmlPullParser.START_TAG && "display-name" == parser.name) {
                                    val normName = normalizeName(parser.nextText())
                                    if (normName.isNotEmpty()) {
                                        nameToChannelId[normName] = channelId
                                    }
                                } else if (parser.eventType == XmlPullParser.END_TAG && "channel" == parser.name) {
                                    break
                                }
                            }
                        }
                    } else if ("programme" == tag) {
                        val channelId = clean(parser.getAttributeValue(null, "channel"))
                        val startStr = parser.getAttributeValue(null, "start")
                        val stopStr = parser.getAttributeValue(null, "stop")
                        val start = parseXmltypeTime(startStr)
                        val stop = parseXmltypeTime(stopStr)
                        var title = ""
                        while (parser.next() != XmlPullParser.END_DOCUMENT) {
                            if (parser.eventType == XmlPullParser.START_TAG && "title" == parser.name) {
                                title = clean(parser.nextText())
                            } else if (parser.eventType == XmlPullParser.END_TAG && "programme" == parser.name) {
                                break
                            }
                        }
                        if (channelId.isNotEmpty() && start != null && stop != null && title.isNotEmpty() && "-" != title) {
                            if (!now.isBefore(start) && now.isBefore(stop)) {
                                currentPrograms[channelId] = title
                            } else if (now.isBefore(start) && !currentPrograms.containsKey(channelId) && !nextPrograms.containsKey(channelId)) {
                                nextPrograms[channelId] = "Sıradaki: $title"
                            }
                        }
                    }
                }
                event = parser.next()
            }
        } catch (e: Exception) {
            Log.e("TvProgramGuide", "Failed to parse XMLTV stream", e)
        }
        for ((normName, channelId) in nameToChannelId) {
            val prog = currentPrograms[channelId] ?: nextPrograms[channelId]
            if (prog != null) {
                result[normName] = prog
            }
        }
        return result
    }

    private fun parseXmltypeTime(value: String?): ZonedDateTime? {
        return try {
            OffsetDateTime.parse(clean(value), XMLTV_TIME_FORMATTER).atZoneSameInstant(GUIDE_ZONE)
        } catch (_: Exception) {
            null
        }
    }

    private fun namesMatch(channelName: String, guideName: String): Boolean {
        if (channelName == guideName) {
            return true
        }
        return channelName.length >= 4 && guideName.length >= 4 && (channelName.contains(guideName) || guideName.contains(channelName))
    }

    private fun normalizeName(value: String?): String {
        val cleanValue = clean(value)
            .replace('\u0130', 'I')
            .replace('\u0131', 'i')
            .replace('\u011E', 'G')
            .replace('\u011F', 'g')
            .replace('\u00DC', 'U')
            .replace('\u00FC', 'u')
            .replace('\u015E', 'S')
            .replace('\u015F', 's')
            .replace('\u00D6', 'O')
            .replace('\u00F6', 'o')
            .replace('\u00C7', 'C')
            .replace('\u00E7', 'c')
            .lowercase(Locale.US)
        return cleanValue.replace(Regex("[^a-z0-9]+"), "")
    }

    private fun clean(value: String?): String {
        if (value == null || "null".equals(value, ignoreCase = true)) {
            return ""
        }
        return value.trim()
    }
}
