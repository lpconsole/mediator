package com.lpconsole.mediator.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lpconsole.mediator.data.Channel

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import com.lpconsole.mediator.ui.theme.Primary

@Composable
fun ZappingOverlay(
    number: String,
    candidate: Channel?,
    modifier: Modifier = Modifier
) {
    if (number.isEmpty()) return

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(Color.Red.copy(alpha = 0.8f))
                .padding(horizontal = 48.dp, vertical = 32.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = number,
                    color = Color.White,
                    fontSize = 80.sp,
                    fontWeight = FontWeight.Black
                )
                candidate?.let {
                    Text(
                        text = it.name,
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold
                    )
                } ?: Text(
                    text = "---",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 24.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Zapping...",
                    color = Primary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
