package com.lpconsole.mediator.ui.features.main

import com.lpconsole.mediator.LyricsProvider
import com.lpconsole.mediator.RadioPosterCatalog
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.data.remote.models.CountryDto
import java.io.File

enum class SortMode {
    DEFAULT, NAME_ASC, NAME_DESC, COUNTRY_ASC, CATEGORY_ASC, POPULAR, NEWEST
}

enum class ListMode {
    ALL, FAVORITES, RECENTS, FILTER
}

data class MainUiState(
    val isFirstRun: Boolean = false,
    val countryList: List<CountryDto> = emptyList(),
    val expectedTvCount: Int = 0,
    val expectedRadioCount: Int = 0,
    val channels: List<Channel> = emptyList(),
    val TOTAL_COUNT: Int = 0,
    val TV_COUNT: Int = 0,
    val RADIO_COUNT: Int = 0,
    val SYNC_PROGRESS: String = "",
    val syncProgressFraction: Float = 0f,
    val syncError: String? = null,
    val isSyncActive: Boolean = false,
    val CURRENT_CHANNEL: Channel? = null,
    val previousChannelId: String? = null,
    val currentType: String = "TV",
    val listMode: ListMode = ListMode.ALL,
    val sortMode: SortMode = SortMode.DEFAULT,
    val isLoading: Boolean = false,
    val isSettingsVisible: Boolean = false,
    val isSearchVisible: Boolean = false,
    val isMenuVisible: Boolean = false,
    val isInfoVisible: Boolean = false,
    val isFilterDialogVisible: Boolean = false,
    val isEditMode: Boolean = false,
    val isBuffering: Boolean = false,
    val playbackError: String? = null,
    val zapNumber: String = "",
    val sleepTimerMinutes: Int = 0,
    val volumeLevel: Float = 1.0f,
    val isVolumeVisible: Boolean = false,
    val isTrackSelectorVisible: Boolean = false,
    val selectedStreamIndex: Int = 0,
    val selectedAudioIndex: Int = 0,
    val selectedSubtitleIndex: Int = -1,
    val isLyricsVisible: Boolean = false,
    val lyricsText: String? = null,
    val lyricsResult: LyricsProvider.Result? = null,
    val lyricsCurrentIndex: Int = 0,
    val nowPlayingMetadata: String? = null,
    val nowPlayingArtwork: Any? = null, // Artwork from metadata (ByteArray or Uri)
    val programInfo: String? = null,
    val audioTracks: List<String> = emptyList(),
    val subtitleTracks: List<String> = emptyList(),
    val radioPoster: File? = null,
    val isRadioPosterLoading: Boolean = false,
    val isPosterIndicatorVisible: Boolean = false,
    val audioAmplitudes: FloatArray? = null,
    // Update
    val updateAvailable: Boolean = false,
    val updateUrl: String? = null,
    val updateVersion: String = "",
    val updateNotes: String = "",
    val updateApkSize: Long = 0L,
    val downloadedBytes: Long = 0L,
    val isUpdating: Boolean = false,
    val updateProgress: Float = 0f,
    val isUpdateDialogVisible: Boolean = false,
    val isUpdateToastVisible: Boolean = false,
    val updateError: String? = null,
    // Filters
    val selectedCountry: String = "",
    val selectedCategory: String = "",
    val countryOptions: List<String> = emptyList(),
    val categoryOptions: List<String> = emptyList(),
    // Settings State
    val startupMode: String = "LAST",
    val videoScale: Int = 0,
    val autoSkipBroken: Boolean = false,
    val autoHideSeconds: Int = 5,
    val countryScope: String = "TR",
    val hideNsfw: Boolean = true,
    val remoteHost: String = "",
    val remoteLanIp: String = "",
    val selectedPosterCode: String = "default",
    val selectedRadioServer: String = "AUTO",
    val availablePosters: List<RadioPosterCatalog.Poster> = emptyList()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as MainUiState

        if (isFirstRun != other.isFirstRun) return false
        if (expectedTvCount != other.expectedTvCount) return false
        if (expectedRadioCount != other.expectedRadioCount) return false
        if (TOTAL_COUNT != other.TOTAL_COUNT) return false
        if (TV_COUNT != other.TV_COUNT) return false
        if (RADIO_COUNT != other.RADIO_COUNT) return false
        if (isSyncActive != other.isSyncActive) return false
        if (isLoading != other.isLoading) return false
        if (isSettingsVisible != other.isSettingsVisible) return false
        if (isSearchVisible != other.isSearchVisible) return false
        if (isMenuVisible != other.isMenuVisible) return false
        if (isInfoVisible != other.isInfoVisible) return false
        if (isFilterDialogVisible != other.isFilterDialogVisible) return false
        if (isEditMode != other.isEditMode) return false
        if (isBuffering != other.isBuffering) return false
        if (sleepTimerMinutes != other.sleepTimerMinutes) return false
        if (volumeLevel != other.volumeLevel) return false
        if (isVolumeVisible != other.isVolumeVisible) return false
        if (isTrackSelectorVisible != other.isTrackSelectorVisible) return false
        if (selectedStreamIndex != other.selectedStreamIndex) return false
        if (selectedAudioIndex != other.selectedAudioIndex) return false
        if (selectedSubtitleIndex != other.selectedSubtitleIndex) return false
        if (isLyricsVisible != other.isLyricsVisible) return false
        if (lyricsCurrentIndex != other.lyricsCurrentIndex) return false
        if (isRadioPosterLoading != other.isRadioPosterLoading) return false
        if (isPosterIndicatorVisible != other.isPosterIndicatorVisible) return false
        if (updateAvailable != other.updateAvailable) return false
        if (updateApkSize != other.updateApkSize) return false
        if (downloadedBytes != other.downloadedBytes) return false
        if (isUpdating != other.isUpdating) return false
        if (updateProgress != other.updateProgress) return false
        if (isUpdateDialogVisible != other.isUpdateDialogVisible) return false
        if (isUpdateToastVisible != other.isUpdateToastVisible) return false
        if (videoScale != other.videoScale) return false
        if (autoSkipBroken != other.autoSkipBroken) return false
        if (autoHideSeconds != other.autoHideSeconds) return false
        if (hideNsfw != other.hideNsfw) return false
        if (countryList != other.countryList) return false
        if (channels != other.channels) return false
        if (SYNC_PROGRESS != other.SYNC_PROGRESS) return false
        if (CURRENT_CHANNEL != other.CURRENT_CHANNEL) return false
        if (previousChannelId != other.previousChannelId) return false
        if (currentType != other.currentType) return false
        if (listMode != other.listMode) return false
        if (sortMode != other.sortMode) return false
        if (playbackError != other.playbackError) return false
        if (zapNumber != other.zapNumber) return false
        if (lyricsText != other.lyricsText) return false
        if (lyricsResult != other.lyricsResult) return false
        if (nowPlayingMetadata != other.nowPlayingMetadata) return false
        if (nowPlayingArtwork != other.nowPlayingArtwork) return false
        if (programInfo != other.programInfo) return false
        if (audioTracks != other.audioTracks) return false
        if (subtitleTracks != other.subtitleTracks) return false
        if (radioPoster != other.radioPoster) return false
        if (!audioAmplitudes.contentEquals(other.audioAmplitudes)) return false
        if (updateUrl != other.updateUrl) return false
        if (updateVersion != other.updateVersion) return false
        if (updateNotes != other.updateNotes) return false
        if (selectedCountry != other.selectedCountry) return false
        if (selectedCategory != other.selectedCategory) return false
        if (countryOptions != other.countryOptions) return false
        if (categoryOptions != other.categoryOptions) return false
        if (startupMode != other.startupMode) return false
        if (countryScope != other.countryScope) return false
        if (remoteHost != other.remoteHost) return false
        if (remoteLanIp != other.remoteLanIp) return false
        if (selectedPosterCode != other.selectedPosterCode) return false
        if (selectedRadioServer != other.selectedRadioServer) return false
        if (availablePosters != other.availablePosters) return false

        return true
    }

    override fun hashCode(): Int {
        var result = isFirstRun.hashCode()
        result = 31 * result + expectedTvCount
        result = 31 * result + expectedRadioCount
        result = 31 * result + TOTAL_COUNT
        result = 31 * result + TV_COUNT
        result = 31 * result + RADIO_COUNT
        result = 31 * result + isSyncActive.hashCode()
        result = 31 * result + isLoading.hashCode()
        result = 31 * result + isSettingsVisible.hashCode()
        result = 31 * result + isSearchVisible.hashCode()
        result = 31 * result + isMenuVisible.hashCode()
        result = 31 * result + isInfoVisible.hashCode()
        result = 31 * result + isFilterDialogVisible.hashCode()
        result = 31 * result + isEditMode.hashCode()
        result = 31 * result + isBuffering.hashCode()
        result = 31 * result + sleepTimerMinutes
        result = 31 * result + volumeLevel.hashCode()
        result = 31 * result + isVolumeVisible.hashCode()
        result = 31 * result + isTrackSelectorVisible.hashCode()
        result = 31 * result + selectedStreamIndex
        result = 31 * result + selectedAudioIndex
        result = 31 * result + selectedSubtitleIndex
        result = 31 * result + isLyricsVisible.hashCode()
        result = 31 * result + lyricsCurrentIndex
        result = 31 * result + isRadioPosterLoading.hashCode()
        result = 31 * result + isPosterIndicatorVisible.hashCode()
        result = 31 * result + updateAvailable.hashCode()
        result = 31 * result + updateApkSize.hashCode()
        result = 31 * result + downloadedBytes.hashCode()
        result = 31 * result + isUpdating.hashCode()
        result = 31 * result + updateProgress.hashCode()
        result = 31 * result + isUpdateDialogVisible.hashCode()
        result = 31 * result + isUpdateToastVisible.hashCode()
        result = 31 * result + videoScale
        result = 31 * result + autoSkipBroken.hashCode()
        result = 31 * result + autoHideSeconds
        result = 31 * result + hideNsfw.hashCode()
        result = 31 * result + countryList.hashCode()
        result = 31 * result + channels.hashCode()
        result = 31 * result + SYNC_PROGRESS.hashCode()
        result = 31 * result + CURRENT_CHANNEL.hashCode()
        result = 31 * result + previousChannelId.hashCode()
        result = 31 * result + currentType.hashCode()
        result = 31 * result + listMode.hashCode()
        result = 31 * result + sortMode.hashCode()
        result = 31 * result + playbackError.hashCode()
        result = 31 * result + zapNumber.hashCode()
        result = 31 * result + lyricsText.hashCode()
        result = 31 * result + lyricsResult.hashCode()
        result = 31 * result + nowPlayingMetadata.hashCode()
        result = 31 * result + nowPlayingArtwork.hashCode()
        result = 31 * result + programInfo.hashCode()
        result = 31 * result + audioTracks.hashCode()
        result = 31 * result + subtitleTracks.hashCode()
        result = 31 * result + radioPoster.hashCode()
        result = 31 * result + (audioAmplitudes?.contentHashCode() ?: 0)
        result = 31 * result + updateUrl.hashCode()
        result = 31 * result + updateVersion.hashCode()
        result = 31 * result + updateNotes.hashCode()
        result = 31 * result + selectedCountry.hashCode()
        result = 31 * result + selectedCategory.hashCode()
        result = 31 * result + countryOptions.hashCode()
        result = 31 * result + categoryOptions.hashCode()
        result = 31 * result + startupMode.hashCode()
        result = 31 * result + countryScope.hashCode()
        result = 31 * result + remoteHost.hashCode()
        result = 31 * result + remoteLanIp.hashCode()
        result = 31 * result + selectedPosterCode.hashCode()
        result = 31 * result + selectedRadioServer.hashCode()
        result = 31 * result + availablePosters.hashCode()
        return result
    }
}
