package com.lpconsole.mediator.util

import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

typealias LegacyUpdateInfo = GitHubManager.UpdateInfo

/**
 * Legacy wrapper for update management, delegating to [GitHubManager].
 */
@Deprecated("Use GitHubManager directly")
@Singleton
class GitHubUpdateManager @Inject constructor(
    private val gitHubManager: GitHubManager
) {
    suspend fun checkForUpdate(currentVersion: String, forceCheck: Boolean = false): GitHubManager.UpdateInfo? {
        return gitHubManager.checkForUpdate(currentVersion, forceCheck)
    }

    fun installApk(file: File) {
        gitHubManager.installApk(file)
    }
}
