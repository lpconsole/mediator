package com.lpconsole.mediator

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.security.MessageDigest
import java.util.Locale

object LyricsProvider {
    private const val API_BASE = "https://lrclib.net/api/"
    private const val CACHE_DIR_NAME = "lyrics"
    private const val USER_AGENT = "mediator/${BuildConfig.VERSION_NAME}"
    private const val CACHE_MAX_AGE_MS = 7L * 24L * 60L * 60L * 1000L

    @JvmStatic
    @Throws(IOException::class)
    fun find(context: Context, artistName: String?, trackName: String?): Result {
        val artist = clean(artistName)
        val track = clean(trackName)
        if (artist.isEmpty() && track.isEmpty()) {
            throw IOException("Parca bilgisi yok")
        }
        val cacheKey = "$artist|$track".lowercase(Locale.US)
        val cacheFile = cacheFile(context, cacheKey)
        if (cacheFile != null && cacheFile.exists() && System.currentTimeMillis() - cacheFile.lastModified() < CACHE_MAX_AGE_MS) {
            val cached = resultFromJson(readFile(cacheFile))
            if (cached != null && cached.hasText()) {
                return cached
            }
        }

        var lastError: IOException? = null
        for (url in candidateUrls(artist, track)) {
            try {
                val result = fetchResult(url)
                if (result != null && result.hasText()) {
                    if (cacheFile != null) {
                        writeFile(cacheFile, result.rawJson)
                    }
                    return result
                }
            } catch (error: IOException) {
                lastError = error
            }
        }
        throw lastError ?: IOException("Sarki sozu bulunamadi")
    }

    private fun candidateUrls(artist: String, track: String): List<String> {
        val urls = mutableListOf<String>()
        if (artist.isNotEmpty() && track.isNotEmpty()) {
            urls.add(API_BASE + "search?artist_name=" + encode(artist) + "&track_name=" + encode(track))
            urls.add(API_BASE + "get?artist_name=" + encode(artist) + "&track_name=" + encode(track))
        }
        val query = clean("$artist $track".trim())
        if (query.isNotEmpty()) {
            urls.add(API_BASE + "search?q=" + encode(query))
        }
        return urls
    }

    @Throws(IOException::class)
    private fun fetchResult(url: String): Result? {
        val json = readUrl(url)
        return resultFromJson(json)
    }

    private fun resultFromJson(json: String?): Result? {
        val value = clean(json)
        if (value.isEmpty()) return null
        return try {
            if (value.startsWith("[")) {
                val array = JSONArray(value)
                var plainFallback: Result? = null
                for (i in 0 until array.length()) {
                    val `object` = array.optJSONObject(i)
                    val candidate = resultFromObject(`object`, `object`?.toString() ?: "")
                    if (candidate == null || !candidate.hasText()) continue
                    if (candidate.synced) return candidate
                    if (plainFallback == null) plainFallback = candidate
                }
                plainFallback
            } else {
                val `object` = JSONObject(value)
                resultFromObject(`object`, value)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resultFromObject(`object`: JSONObject?, rawJson: String): Result? {
        if (`object` == null) return null
        val syncedLyrics = clean(`object`.optString("syncedLyrics", ""))
        val plainLyrics = clean(`object`.optString("plainLyrics", ""))
        var lines = parseSyncedLyrics(syncedLyrics)
        val synced = lines.isNotEmpty()
        if (!synced && plainLyrics.isNotEmpty()) {
            lines = parsePlainLyrics(plainLyrics)
        }
        if (lines.isEmpty()) return null
        return Result(
            clean(`object`.optString("artistName", "")),
            clean(`object`.optString("trackName", "")),
            synced,
            lines,
            rawJson
        )
    }

    private fun parseSyncedLyrics(value: String): List<Line> {
        val lines = mutableListOf<Line>()
        val rows = clean(value).split("\\r?\\n".toRegex()).toTypedArray()
        for (row in rows) {
            var search = 0
            val times = mutableListOf<Long>()
            while (search < row.length && row[search] == '[') {
                val close = row.indexOf(']', search)
                if (close < 0) break
                val timeMs = parseTimestamp(row.substring(search + 1, close))
                if (timeMs >= 0L) {
                    times.add(timeMs)
                }
                search = close + 1
            }
            var text = clean(row.substring(search.coerceAtMost(row.length)))
            if (text.isEmpty()) text = " "
            for (time in times) {
                lines.add(Line(time, text))
            }
        }
        lines.sortBy { it.timeMs }
        return lines
    }

    private fun parseTimestamp(value: String): Long {
        val parts = clean(value).split(":".toRegex()).toTypedArray()
        if (parts.size != 2) return -1L
        return try {
            val minutes = parts[0].toLong()
            val seconds = parts[1].toDouble()
            minutes * 60_000L + Math.round(seconds * 1000.0)
        } catch (_: NumberFormatException) {
            -1L
        }
    }

    private fun parsePlainLyrics(value: String): List<Line> {
        val lines = mutableListOf<Line>()
        val rows = clean(value).split("\\r?\\n".toRegex()).toTypedArray()
        for (row in rows) {
            val text = clean(row)
            if (text.isNotEmpty()) {
                lines.add(Line(-1L, text))
            }
        }
        return lines
    }

    @Throws(IOException::class)
    private fun readUrl(urlString: String): String {
        var connection: HttpURLConnection? = null
        try {
            connection = URL(urlString).openConnection() as HttpURLConnection
            connection.connectTimeout = 8000
            connection.readTimeout = 15000
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("User-Agent", USER_AGENT)
            val responseCode = connection.responseCode
            if (responseCode !in 200..299) {
                throw IOException("Lyrics HTTP $responseCode")
            }
            connection.inputStream.use { input ->
                ByteArrayOutputStream().use { output ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                    }
                    return String(output.toByteArray(), StandardCharsets.UTF_8)
                }
            }
        } finally {
            connection?.disconnect()
        }
    }

    private fun cacheFile(context: Context, key: String): File? {
        return try {
            val dir = File(context.cacheDir, CACHE_DIR_NAME)
            if (!dir.exists() && !dir.mkdirs()) return null
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(key.toByteArray(StandardCharsets.UTF_8))
            val name = StringBuilder()
            for (b in hash) {
                name.append(String.format(Locale.US, "%02x", b))
            }
            File(dir, "$name.json")
        } catch (_: Exception) {
            null
        }
    }

    @Throws(IOException::class)
    private fun readFile(file: File): String {
        return String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8)
    }

    private fun writeFile(file: File, value: String) {
        try {
            FileOutputStream(file, false).use { output ->
                output.write(value.toByteArray(StandardCharsets.UTF_8))
            }
        } catch (_: IOException) {
        }
    }

    private fun encode(value: String): String {
        return try {
            URLEncoder.encode(value, StandardCharsets.UTF_8.name())
        } catch (_: Exception) {
            value
        }
    }

    private fun clean(value: String?): String {
        return if (value == null || "null".equals(value, ignoreCase = true)) "" else value.trim()
    }

    data class Result(
        @JvmField val artistName: String,
        @JvmField val trackName: String,
        @JvmField val synced: Boolean,
        @JvmField val lines: List<Line>,
        @JvmField val rawJson: String
    ) {
        fun hasText(): Boolean = lines.isNotEmpty()
    }

    data class Line(
        @JvmField val timeMs: Long,
        @JvmField val text: String
    )
}
