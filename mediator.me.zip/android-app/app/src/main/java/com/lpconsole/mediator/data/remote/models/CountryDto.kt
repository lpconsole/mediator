package com.lpconsole.mediator.data.remote.models

import com.google.gson.annotations.SerializedName

data class CountryDto(
    @SerializedName("name") val name: String?,
    @SerializedName("code") val code: String?
)
