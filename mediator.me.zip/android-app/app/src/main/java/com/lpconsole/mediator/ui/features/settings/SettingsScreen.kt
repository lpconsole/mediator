package com.lpconsole.mediator.ui.features.settings

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.lpconsole.mediator.BuildConfig
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.ui.features.main.MainUiState
import com.lpconsole.mediator.ui.features.settings.logic.SettingsManager
import com.lpconsole.mediator.ui.theme.Primary
import java.util.Locale
import com.lpconsole.mediator.ui.util.dualControl
import kotlinx.coroutines.delay
import kotlin.time.Duration.Companion.milliseconds

enum class SettingsCategory {
    GENERAL, TV_SETTINGS, RADIO_SETTINGS, PLAYER, CENSORSHIP, UPDATES, ABOUT
}

@Composable
fun SettingsScreen(
    state: MainUiState,
    settingsManager: SettingsManager,
    onUpdateSetting: ((SettingsManager) -> Unit) -> Unit,
    onClearRecents: () -> Unit = {},
    onCheckUpdate: () -> Unit,
    onRefreshDatabase: () -> Unit,
    onSyncBackups: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf(SettingsCategory.GENERAL) }
    val firstCategoryFocusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(100.milliseconds)
        firstCategoryFocusRequester.requestFocus()
    }
    BackHandler {
        onDismiss()
    }
    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0F1115))) {
        Row(modifier = Modifier.fillMaxSize()) {
            // 1. Sidebar
            Column(
                modifier = Modifier
                    .width(280.dp)
                    .fillMaxHeight()
                    .background(Color(0xFF1A1C23))
                    .verticalScroll(rememberScrollState())
                    .padding(start = 20.dp, top = 28.dp, end = 16.dp, bottom = 28.dp)
            ) {
                // Header (Ayarlar)
                val interactionSourceBack = remember { MutableInteractionSource() }
                Surface(
                    onClick = onDismiss,
                    colors = ClickableSurfaceDefaults.colors(containerColor = Color.Transparent),
                    interactionSource = interactionSourceBack,
                    modifier = Modifier
                        .padding(bottom = 24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .dualControl(
                            onClick = onDismiss,
                            onFocus = {},
                            interactionSource = interactionSourceBack
                        )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Ayarlar",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "MEDIATOR",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.5f),
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                // Categories
                SettingsCategory.entries.forEachIndexed { index, category ->
                    CategoryItem(
                        label = when(category) {
                            SettingsCategory.GENERAL -> "Genel"
                            SettingsCategory.TV_SETTINGS -> "TV Ayarları"
                            SettingsCategory.RADIO_SETTINGS -> "Radyo Ayarları"
                            SettingsCategory.PLAYER -> "Oynatıcı"
                            SettingsCategory.CENSORSHIP -> "Güvenlik"
                            SettingsCategory.UPDATES -> "Sistem"
                            SettingsCategory.ABOUT -> "Hakkında"
                        },
                        icon = when(category) {
                            SettingsCategory.GENERAL -> Icons.Default.Settings
                            SettingsCategory.TV_SETTINGS -> Icons.Default.Tv
                            SettingsCategory.RADIO_SETTINGS -> Icons.Default.Radio
                            SettingsCategory.PLAYER -> Icons.Default.PlayArrow
                            SettingsCategory.CENSORSHIP -> Icons.Default.Lock
                            SettingsCategory.UPDATES -> Icons.Default.Sync
                            SettingsCategory.ABOUT -> Icons.Default.Info
                        },
                        isSelected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        onFocus = { selectedCategory = category },
                        modifier = if (index == 0) Modifier.focusRequester(firstCategoryFocusRequester) else Modifier
                    )
                }
            }

            // 2. Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 36.dp, top = 32.dp, end = 36.dp, bottom = 32.dp)
            ) {
                AnimatedContent(
                    targetState = selectedCategory,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "SettingsContent"
                ) { category ->
                    Column(modifier = Modifier.fillMaxSize()) {
                        Text(
                            text = when(category) {
                                SettingsCategory.GENERAL -> "Genel Yapılandırma"
                                SettingsCategory.TV_SETTINGS -> "Televizyon Tercihleri"
                                SettingsCategory.RADIO_SETTINGS -> "Radyo & Arkaplan"
                                SettingsCategory.PLAYER -> "Medya Oynatıcı"
                                SettingsCategory.CENSORSHIP -> "İçerik Filtreleme"
                                SettingsCategory.UPDATES -> "Sistem ve Güncelleme"
                                SettingsCategory.ABOUT -> "Uygulama Bilgileri"
                            },
                            style = MaterialTheme.typography.headlineMedium,
                            fontSize = 24.sp,
                            maxLines = 1,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 20.dp)
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 40.dp)
                        ) {
                            when (category) {
                                SettingsCategory.GENERAL -> {
                                    item { SettingsCategoryLabel("SİSTEM TERCİHLERİ") }
                                    item {
                                        SettingsItem(
                                            label = "Başlangıç Modu",
                                            value = when(state.startupMode) {
                                                "LAST" -> "Son Kaldığım Yer"
                                                "TV" -> "Her Zaman TV"
                                                else -> "Her Zaman Radyo"
                                            },
                                            icon = Icons.Default.PlayArrow,
                                            onClick = {
                                                onUpdateSetting { mgr ->
                                                    val next = when(state.startupMode) {
                                                        "LAST" -> "TV"
                                                        "TV" -> "FM"
                                                        else -> "LAST"
                                                    }
                                                    mgr.setStartupMode(next)
                                                }
                                            }
                                        )
                                    }
                                    item {
                                        SettingsItem(
                                            label = "Yan Menü Zamanlayıcı",
                                            value = if (state.autoHideSeconds <= 0) "Kapanmasın" else "${state.autoHideSeconds} Saniye",
                                            icon = Icons.Default.Timer,
                                            onClick = {
                                                onUpdateSetting { mgr ->
                                                    val next = when(state.autoHideSeconds) {
                                                        0 -> 3
                                                        3 -> 5
                                                        5 -> 10
                                                        else -> 0
                                                    }
                                                    mgr.setAutoHideSeconds(next)
                                                }
                                            }
                                        )
                                    }
                                }
                                SettingsCategory.TV_SETTINGS -> {
                                    item { SettingsCategoryLabel("BÖLGE & İÇERİK") }
                                    item {
                                        SettingsValueSelector(
                                            label = "Varsayılan TV Ülkesi",
                                            value = settingsManager.getDefaultCountry(Prefs.TYPE_TV).takeIf { it.isNotEmpty() } ?: "Tümü",
                                            icon = Icons.Default.Language,
                                            options = listOf("") + state.countryOptions,
                                            onSelect = { country ->
                                                onUpdateSetting { mgr ->
                                                    mgr.setDefaultCountry(Prefs.TYPE_TV, country)
                                                }
                                            }
                                        )
                                    }
                                }
                                SettingsCategory.RADIO_SETTINGS -> {
                                    item { SettingsCategoryLabel("BÖLGE & BAĞLANTI") }
                                    item {
                                        SettingsValueSelector(
                                            label = "Varsayılan Radyo Ülkesi",
                                            value = settingsManager.getDefaultCountry(Prefs.TYPE_FM).takeIf { it.isNotEmpty() } ?: "Tümü",
                                            icon = Icons.Default.Language,
                                            options = listOf("") + state.countryOptions,
                                            onSelect = { country ->
                                                onUpdateSetting { mgr ->
                                                    mgr.setDefaultCountry(Prefs.TYPE_FM, country)
                                                }
                                            }
                                        )
                                    }
                                    item {
                                        val serverMap = mapOf(
                                            Prefs.RADIO_SERVER_AUTO to "Otomatik (Sırayla)",
                                            "ALL" to "Genel (All)",
                                            "DE" to "Almanya",
                                            "FR" to "Fransa",
                                            "NL" to "Hollanda",
                                            "IT" to "İtalya"
                                        )
                                        SettingsValueSelector(
                                            label = "Radyo Veri Sunucusu",
                                            value = serverMap[state.selectedRadioServer] ?: "Otomatik",
                                            icon = Icons.Default.Dns,
                                            options = serverMap.keys.toList(),
                                            optionLabelMapper = { serverMap[it] ?: it },
                                            onSelect = { server ->
                                                onUpdateSetting { mgr ->
                                                    mgr.setRadioServer(server)
                                                }
                                            }
                                        )
                                    }
                                    item { SettingsCategoryLabel("AKTİF ARKAPLAN") }
                                    items(state.availablePosters) { poster ->
                                        val activeCode = if (state.selectedPosterCode.equals("default", ignoreCase = true) || state.selectedPosterCode.isBlank()) "1.gif" else state.selectedPosterCode
                                        val isSelected = activeCode.equals(poster.code, ignoreCase = true)
                                        SettingsItem(
                                            label = poster.label,
                                            value = if (isSelected) "Seçili" else "",
                                            icon = Icons.Default.Image,
                                            isActive = isSelected,
                                            onClick = {
                                                onUpdateSetting { mgr ->
                                                    mgr.setSelectedPosterCode(poster.code)
                                                }
                                            }
                                        )
                                    }
                                }
                                SettingsCategory.PLAYER -> {
                                    item { SettingsCategoryLabel("OYNATMA SEÇENEKLERİ") }
                                    item {
                                        SettingsItem(
                                            label = "Görüntü Formatı",
                                            value = when(state.videoScale) {
                                                0 -> "Orijinal (Fit)"
                                                1 -> "Tam Ekran (Fill)"
                                                else -> "Genişlet (Stretch)"
                                            },
                                            icon = Icons.Default.AspectRatio,
                                            onClick = {
                                                onUpdateSetting { mgr ->
                                                    mgr.setVideoScale((state.videoScale + 1) % 3)
                                                }
                                            }
                                        )
                                    }
                                    item {
                                        SettingsItem(
                                            label = "Otomatik Kanal Geçişi (Hatalı Yayınlarda)",
                                            value = if (state.autoSkipBroken) "Açık (Yayın açılamazsa sonraki kanala otomatik geçer)" else "Kapalı (Kanal değiştirilmez, hata mesajı gösterilir)",
                                            icon = Icons.Default.SkipNext,
                                            isActive = state.autoSkipBroken,
                                            onClick = {
                                                onUpdateSetting { mgr ->
                                                    mgr.setAutoSkipBroken(!state.autoSkipBroken)
                                                }
                                            }
                                        )
                                    }
                                }
                                SettingsCategory.CENSORSHIP -> {
                                    item { SettingsCategoryLabel("EBEVEYN KONTROLLERİ") }
                                    item {
                                        SettingsItem(
                                            label = "Yetişkin İçerik Kilidi (+18)",
                                            value = if (state.hideNsfw) "Aktif" else "Devre Dışı",
                                            icon = Icons.Default.Lock,
                                            isActive = state.hideNsfw,
                                            onClick = {
                                                onUpdateSetting { mgr ->
                                                    mgr.setHideNsfw(!state.hideNsfw)
                                                }
                                            }
                                        )
                                    }
                                }
                                SettingsCategory.UPDATES -> {
                                    item { SettingsCategoryLabel("VERİ YÖNETİMİ") }
                                    item {
                                        var isBackupsSyncing by remember { mutableStateOf(false) }
                                        SettingsItem(
                                            label = "Yedek Yayınları Senkronize Et",
                                            value = if (isBackupsSyncing) "Gist'ten indiriliyor..." else "GitHub Gist'teki yedek linkleri hemen çek",
                                            icon = Icons.Default.CloudDownload,
                                            isLoading = isBackupsSyncing,
                                            onClick = {
                                                if (!isBackupsSyncing) {
                                                    isBackupsSyncing = true
                                                    Toast.makeText(context, "Yedek yayın kaynakları indiriliyor...", Toast.LENGTH_SHORT).show()
                                                    onSyncBackups()
                                                    // Reset indicator after short delay
                                                    isBackupsSyncing = false
                                                    Toast.makeText(context, "Yedek yayınlar başarıyla güncellendi.", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        )
                                    }
                                    item {
                                        SettingsItem(
                                            label = "Tüm Veri Kaynağını Güncelle",
                                            value = if (state.isSyncActive) "Kanallar senkronize ediliyor... Lütfen bekleyin" else "Tüm TV & Radyo listesini sıfırla ve yeniden çek",
                                            icon = Icons.Default.Sync,
                                            isLoading = state.isSyncActive,
                                            onClick = {
                                                Toast.makeText(context, "Tüm kanal verileri senkronize ediliyor...", Toast.LENGTH_SHORT).show()
                                                onRefreshDatabase()
                                            }
                                        )
                                    }
                                    item {
                                        SettingsItem(
                                            label = "İzleme Geçmişini Temizle",
                                            value = "Tüm geçmişi sıfırla",
                                            icon = Icons.Default.Delete,
                                            onClick = {
                                                onClearRecents()
                                                Toast.makeText(context, "İzleme geçmişi temizlendi.", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }
                                    item { SettingsCategoryLabel("YAZILIM") }
                                    item {
                                        val updateSubtitle = when {
                                            state.isUpdating -> {
                                                val progress = state.updateProgress.toInt()
                                                val downloaded = String.format(Locale.US, "%.1f", state.downloadedBytes / (1024f * 1024f))
                                                val total = String.format(Locale.US, "%.1f", state.updateApkSize / (1024f * 1024f))
                                                "İndiriliyor... %$progress ($downloaded / $total MB)"
                                            }
                                            state.updateAvailable -> "Yeni Sürüm Var (v${state.updateVersion} - Yüklemek için tıklayın)"
                                            else -> "Sürümünüz Güncel (v${BuildConfig.VERSION_NAME})"
                                        }
                                        SettingsItem(
                                            label = "Uygulama Güncelleme",
                                            value = updateSubtitle,
                                            icon = Icons.Default.SystemUpdate,
                                            onClick = {
                                                Toast.makeText(context, "Güncellemeler kontrol ediliyor...", Toast.LENGTH_SHORT).show()
                                                onCheckUpdate()
                                            }
                                        )
                                    }
                                }
                                SettingsCategory.ABOUT -> {
                                    item { SettingsCategoryLabel("BİLGİLER") }
                                    item {
                                        SettingsItem(
                                            label = "Versiyon",
                                            value = "v${BuildConfig.VERSION_NAME}",
                                            icon = Icons.Default.Code,
                                            onClick = {
                                                Toast.makeText(context, "Mediator v${BuildConfig.VERSION_NAME}", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }
                                    item {
                                        SettingsItem(
                                            label = "Geliştirici",
                                            value = "LPConsole",
                                            icon = Icons.Default.Person,
                                            onClick = {
                                                Toast.makeText(context, "Geliştirici: LPConsole", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }
                                    item {
                                        SettingsItem(
                                            label = "İletişim",
                                            value = BuildConfig.SUPPORT_MAIL,
                                            icon = Icons.Default.Email,
                                            onClick = {
                                                Toast.makeText(context, "Destek: ${BuildConfig.SUPPORT_MAIL}", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    onFocus: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val isPressed by interactionSource.collectIsPressedAsState()

    LaunchedEffect(isFocused) {
        if (isFocused) {
            onFocus()
        }
    }

    val containerColor = if (isFocused || isPressed) Primary
    else if (isSelected) Color(0xFF282420)
    else Color.Transparent

    val contentColor = if (isFocused || isPressed) Color.Black
    else if (isSelected) Primary
    else Color.White.copy(alpha = 0.6f)

    val borderModifier = if (isSelected && !isFocused && !isPressed) {
        Modifier.border(1.dp, Primary, RoundedCornerShape(12.dp))
    } else {
        Modifier
    }

    Surface(
        onClick = onClick,
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.03f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = containerColor,
            contentColor = contentColor,
            focusedContainerColor = Primary,
            focusedContentColor = Color.Black
        ),
        interactionSource = interactionSource,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(12.dp)),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .dualControl(
                onClick = onClick,
                onFocus = onFocus,
                interactionSource = interactionSource
            )
            .then(borderModifier)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (isSelected || isFocused || isPressed) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
fun SettingsItem(
    label: String,
    value: String,
    icon: ImageVector? = null,
    isActive: Boolean? = null,
    isLoading: Boolean = false,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val containerColor = if (isPressed) Color(0xFF2C3242) else Color(0xFF232732)
    val focusedContainerColor = Color(0xFF2A2F3D)
    
    Surface(
        onClick = onClick,
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.01f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = containerColor,
            focusedContainerColor = focusedContainerColor,
            contentColor = Color.White
        ),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(16.dp)),
        interactionSource = interactionSource,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .dualControl(
                onClick = onClick,
                onFocus = {},
                interactionSource = interactionSource
            )
            .then(
                if (isFocused || isPressed) Modifier.border(2.dp, Primary, RoundedCornerShape(16.dp))
                else Modifier.border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
            )
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isFocused || isPressed) Primary else Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
            }
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label, 
                    style = MaterialTheme.typography.titleMedium, 
                    fontWeight = FontWeight.Medium
                )
                if (value.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = value, 
                        style = MaterialTheme.typography.bodyMedium, 
                        color = if (isLoading) Primary else Color.White.copy(alpha = 0.5f)
                    )
                }
            }
            
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp,
                    color = Primary
                )
            } else if (isActive != null) {
                // Switch
                Box(
                    modifier = Modifier
                        .size(width = 44.dp, height = 24.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isActive) Primary else Color.White.copy(alpha = 0.2f))
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .align(if (isActive) Alignment.CenterEnd else Alignment.CenterStart)
                            .clip(CircleShape)
                            .background(if (isActive) Color(0xFF1E2029) else Color(0xFF909090))
                    )
                }
            } else {
                Icon(
                    Icons.Default.ChevronRight, 
                    contentDescription = null, 
                    tint = if (isFocused || isPressed) Primary else Color.White.copy(alpha = 0.4f)
                )
            }
        }
    }
}

@Composable
fun SettingsValueSelector(
    label: String,
    value: String,
    icon: ImageVector? = null,
    options: List<String>,
    optionLabelMapper: (String) -> String = { it },
    onSelect: (String) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }

    SettingsItem(
        label = label,
        value = value,
        icon = icon,
        isActive = null,
        onClick = { showDialog = true }
    )

    if (showDialog) {
        val dialogFocusRequester = remember { FocusRequester() }

        LaunchedEffect(showDialog) {
            if (showDialog) {
                delay(100)
                dialogFocusRequester.requestFocus()
            }
        }

        Dialog(onDismissRequest = { showDialog = false }) {
            BackHandler { showDialog = false }
            Box(
                modifier = Modifier
                    .width(420.dp)
                    .fillMaxHeight(0.85f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF16181F))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(label, style = MaterialTheme.typography.headlineSmall, color = Primary, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        itemsIndexed(options) { index, opt ->
                            val display = if (opt.isEmpty()) "Tüm Ülkeler" else optionLabelMapper(opt)
                            val isSelected = opt == value || (opt.isEmpty() && (value.isEmpty() || value == "Tümü"))
                            val itemInteractionSource = remember { MutableInteractionSource() }
                            val isFocused by itemInteractionSource.collectIsFocusedAsState()
                            val isPressed by itemInteractionSource.collectIsPressedAsState()

                            Surface(
                                onClick = { onSelect(opt); showDialog = false },
                                interactionSource = itemInteractionSource,
                                colors = ClickableSurfaceDefaults.colors(
                                    containerColor = if (isSelected) Primary.copy(alpha = 0.2f) else if (isPressed) Color(0xFF282C38) else Color.Transparent,
                                    focusedContainerColor = Primary,
                                    focusedContentColor = Color.Black
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .then(if (index == 0) Modifier.focusRequester(dialogFocusRequester) else Modifier)
                                    .then(if (isSelected) Modifier.border(1.dp, Primary, RoundedCornerShape(8.dp)) else Modifier)
                                    .dualControl(
                                        onClick = { onSelect(opt); showDialog = false },
                                        onFocus = {},
                                        interactionSource = itemInteractionSource
                                    )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = display,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (isFocused) Color.Black else Color.White
                                    )
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Seçili",
                                            tint = if (isFocused) Color.Black else Primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsCategoryLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = Primary,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
    )
}
