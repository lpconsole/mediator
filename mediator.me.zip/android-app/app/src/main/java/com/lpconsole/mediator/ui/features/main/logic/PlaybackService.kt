package com.lpconsole.mediator.ui.features.main.logic

import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class PlaybackService : MediaSessionService() {
    @Inject
    lateinit var playerManager: PlayerManager
    override fun onCreate() {
        super.onCreate()
        val session = playerManager.getMediaSession()
        if (session != null) {
            try {
                addSession(session)
            } catch (_: Exception) {}
        }
    }

    @OptIn(UnstableApi::class)
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return playerManager.getMediaSession()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        val session = playerManager.getMediaSession()
        if (session != null) {
            try { addSession(session) } catch (_: Exception) {}
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        try {
            val session = playerManager.getMediaSession()
            if (session != null) {
                removeSession(session)
            }
        } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        val session = playerManager.getMediaSession()
        if (session != null) {
            try {
                removeSession(session)
            } catch (_: Exception) {}
        }
        super.onDestroy()
    }
}
