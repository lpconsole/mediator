package com.lpconsole.mediator.ui.features.settings.logic

import android.content.Context
import android.content.SharedPreferences
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.RadioPosterCatalog
import com.lpconsole.mediator.util.GitHubManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import androidx.core.content.edit
import java.util.Locale

@Singleton
class SettingsManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val gitHubManager: GitHubManager
) {
    private val prefs: SharedPreferences = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
    fun getStartupMode(): String = prefs.getString("startup_mode", "LAST") ?: "LAST"
    fun setStartupMode(mode: String) = prefs.edit { putString("startup_mode", mode) }
    fun getVideoScale(): Int = prefs.getInt("video_scale", 0) // 0: Fit, 1: Fill, 2: Stretch
    fun setVideoScale(scale: Int) = prefs.edit { putInt("video_scale", scale) }
    fun getAutoSkipBroken(): Boolean = prefs.getBoolean(Prefs.KEY_AUTO_SKIP, false)
    fun setAutoSkipBroken(skip: Boolean) = prefs.edit { putBoolean(Prefs.KEY_AUTO_SKIP, skip) }
    fun getAutoHideSeconds(): Int = prefs.getInt(Prefs.KEY_AUTO_HIDE_SECONDS, 5)
    fun setAutoHideSeconds(seconds: Int) = prefs.edit { putInt(Prefs.KEY_AUTO_HIDE_SECONDS, seconds) }
    fun getCountryScope(): String {
        val saved = prefs.getString(Prefs.KEY_COUNTRY_SCOPE, null)
        if (saved == null) {
            val deviceCountry = getDeviceCountry()
            setCountryScope(deviceCountry)
            return deviceCountry
        }
        return saved
    }
    fun setCountryScope(scope: String) = prefs.edit { putString(Prefs.KEY_COUNTRY_SCOPE, scope) }
    fun getHideNsfw(): Boolean = prefs.getBoolean(Prefs.KEY_HIDE_NSFW, true)
    fun setHideNsfw(hide: Boolean) = prefs.edit { putBoolean(Prefs.KEY_HIDE_NSFW, hide) }
    fun getDefaultCountry(type: String): String {
        val key = "default_country_$type"
        val saved = prefs.getString(key, null)
        if (saved == null) {
            val deviceCountry = getDeviceCountry()
            setDefaultCountry(type, deviceCountry)
            return deviceCountry
        }
        return saved
    }
    fun setDefaultCountry(type: String, country: String) = prefs.edit { putString("default_country_$type", country) }
    private fun getDeviceCountry(): String { return Locale.getDefault().country.uppercase() }
    fun getSelectedCategory(type: String): String = prefs.getString("selected_category_$type", "") ?: ""
    fun setSelectedCategory(type: String, category: String) = prefs.edit { putString("selected_category_$type", category) }
    fun clearRecents() {
        // This triggers a refresh in VM
    }
    // Radio
    fun getSelectedPosterCode(): String = prefs.getString(Prefs.KEY_RADIO_POSTER, "default") ?: "default"
    fun setSelectedPosterCode(code: String) = prefs.edit { putString(Prefs.KEY_RADIO_POSTER, code) }
    fun getRadioServer(): String = prefs.getString(Prefs.KEY_RADIO_SERVER, Prefs.RADIO_SERVER_AUTO) ?: Prefs.RADIO_SERVER_AUTO
    fun setRadioServer(server: String) = prefs.edit { putString(Prefs.KEY_RADIO_SERVER, server) }
    fun getLastType(): String = prefs.getString(Prefs.KEY_LAST_TYPE, Prefs.TYPE_TV) ?: Prefs.TYPE_TV
    fun setLastType(type: String) = prefs.edit(commit = true) { putString(Prefs.KEY_LAST_TYPE, type) }
    fun getLastChannelId(type: String): String? = prefs.getString("${Prefs.KEY_LAST_CHANNEL}_$type", null)
    fun setLastChannelId(type: String, id: String?) = prefs.edit(commit = true) { putString("${Prefs.KEY_LAST_CHANNEL}_$type", id) }
    fun setGlobalLastChannelId(id: String?) = prefs.edit(commit = true) { putString(Prefs.KEY_LAST_CHANNEL, id) }
    suspend fun getAvailablePosters(): List<RadioPosterCatalog.Poster> { return gitHubManager.loadRadioPosters(preferFresh = false) }
}
