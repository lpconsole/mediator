package com.lpconsole.mediator.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val Background = Color(0xFF05080D)
val Surface = Color(0xFF101824)
val Primary = Color(0xFF6CE6B1)
val OnPrimary = Color(0xFF000000)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB3C0CE)
val Favorite = Color(0xFFFFD700)
val Selected = Color(0xFF1F6A51)
val AccentBlue = Color(0xFF4E8DFF)
val GlassBackground = Color(0x9905080D)
val GlassStroke = Color(0x33FFFFFF)
