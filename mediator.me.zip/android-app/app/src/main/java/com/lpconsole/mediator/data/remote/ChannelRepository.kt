package com.lpconsole.mediator.data.remote

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import android.util.Log
import androidx.core.content.edit
import com.google.gson.Gson
import com.lpconsole.mediator.BuildConfig
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.data.StreamInfo
import com.lpconsole.mediator.data.local.dao.ChannelDao
import com.lpconsole.mediator.data.local.entities.ChannelEntity
import com.lpconsole.mediator.data.local.entities.toDomain
import com.lpconsole.mediator.data.local.entities.toEntity
import com.lpconsole.mediator.data.remote.api.MediatorApi
import com.lpconsole.mediator.data.remote.models.ChannelDto
import com.lpconsole.mediator.data.remote.models.CountryDto
import com.lpconsole.mediator.iptv.IptvJson
import com.lpconsole.mediator.data.remote.models.BackupConfigDto
import com.lpconsole.mediator.data.remote.models.BackupChannelDto
import com.lpconsole.mediator.data.remote.models.BackupStreamDto
import okhttp3.OkHttpClient
import okhttp3.Request
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChannelRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val api: MediatorApi,
    private val dao: ChannelDao,
    private val okHttpClient: OkHttpClient
) {
    val activeMedia = MediatorApi.RADIO_SERVERS
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val prefs = context.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)

    private val backupTvList = mutableListOf<BackupChannelDto>()
    private val backupRadioList = mutableListOf<BackupChannelDto>()
    private var lastBackupSyncTime = 0L

    private val _syncStatus = MutableStateFlow("")
    val syncStatus: StateFlow<String> = _syncStatus.asStateFlow()

    private val _syncProgressFraction = MutableStateFlow(0f)
    val syncProgressFraction: StateFlow<Float> = _syncProgressFraction.asStateFlow()

    private val _syncError = MutableStateFlow<String?>(null)
    val syncError: StateFlow<String?> = _syncError.asStateFlow()

    private val _isSyncActive = MutableStateFlow(false)
    val isSyncActive: StateFlow<Boolean> = _isSyncActive.asStateFlow()

    private val isSyncing = AtomicBoolean(false)

    fun sanitizeGistUrl(url: String): String {
        val cleaned = url.trim().replace(Regex("""/raw/[0-9a-fA-F]{40}/"""), "/raw/")
        return if (!cleaned.contains("?")) "$cleaned?t=${System.currentTimeMillis()}" else "$cleaned&t=${System.currentTimeMillis()}"
    }

    suspend fun fetchBackupConfig(rawUrl: String): BackupConfigDto? = withContext(Dispatchers.IO) {
        val targetUrl = sanitizeGistUrl(rawUrl)
        try {
            val request = Request.Builder()
                .url(targetUrl)
                .header("Cache-Control", "no-cache, no-store")
                .header("Pragma", "no-cache")
                .header("Accept", "application/json")
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.w("ChannelRepository", "Backup config fetch failed ($targetUrl): HTTP ${response.code}")
                    return@withContext null
                }
                val body = response.body.string()
                if (body.isBlank()) return@withContext null
                Gson().fromJson(body, BackupConfigDto::class.java)
            }
        } catch (e: Exception) {
            Log.w("ChannelRepository", "Failed to fetch backup streams from $targetUrl: ${e.message}")
            null
        }
    }

    fun enrichChannelWithBackup(channel: Channel, type: String) {
        val backupList = if (type == Prefs.TYPE_TV) backupTvList else backupRadioList
        if (backupList.isEmpty()) return

        val normalizedChannelName = channel.name.trim().lowercase()
        val normalizedChannelId = channel.id.trim().lowercase()
        val channelCountry = channel.country.trim().uppercase()

        val matched = synchronized(backupList) {
            backupList.firstOrNull { backup ->
                val bId = backup.id?.trim()?.lowercase() ?: ""
                if (bId.isNotEmpty()) {
                    if (bId == normalizedChannelId || 
                        normalizedChannelId.startsWith("$bId@") || 
                        normalizedChannelId.startsWith("$bId.") || 
                        bId.startsWith("$normalizedChannelId.")) {
                        return@firstOrNull true
                    }
                }

                val bName = backup.name?.trim()?.lowercase() ?: ""
                if (bName.isNotEmpty()) {
                    val bCountry = backup.country?.trim()?.uppercase() ?: ""
                    val countryMatches = bCountry.isEmpty() || channelCountry.isEmpty() || bCountry == channelCountry
                    if (countryMatches) {
                        if (bName == normalizedChannelName) return@firstOrNull true
                        val cleanB = bName.replace(" ", "").replace("tv", "").replace("hd", "")
                        val cleanCh = normalizedChannelName.replace(" ", "").replace("tv", "").replace("hd", "")
                        if (cleanB.isNotEmpty() && cleanB == cleanCh) {
                            return@firstOrNull true
                        }
                    }
                }
                false
            }
        } ?: return

        val backupStreams = matched.streams?.mapNotNull { bStream ->
            val url = bStream.url?.trim() ?: return@mapNotNull null
            if (url.isBlank()) return@mapNotNull null
            StreamInfo(
                url = url,
                quality = bStream.quality ?: "HD",
                label = bStream.label ?: "Yedek",
                referrer = bStream.referrer ?: "",
                userAgent = bStream.userAgent ?: ""
            )
        } ?: emptyList()

        if (backupStreams.isNotEmpty()) {
            val backupUrlsSet = backupStreams.map { it.url.trim().lowercase() }.toSet()

            val mainStream = channel.streams.firstOrNull { s ->
                !backupUrlsSet.contains(s.url.trim().lowercase()) &&
                !s.label.contains("Yedek", ignoreCase = true) &&
                !s.label.contains("SV-", ignoreCase = true)
            } ?: channel.streams.firstOrNull { s ->
                !s.label.contains("Yedek", ignoreCase = true) &&
                !s.label.contains("SV-", ignoreCase = true)
            }

            channel.streams.clear()

            if (matched.priority) {
                channel.streams.addAll(backupStreams)
                if (mainStream != null && !backupUrlsSet.contains(mainStream.url.trim().lowercase())) {
                    channel.streams.add(mainStream)
                }
            } else {
                if (mainStream != null && !backupUrlsSet.contains(mainStream.url.trim().lowercase())) {
                    channel.streams.add(mainStream)
                }
                channel.streams.addAll(backupStreams)
            }
        }

        if (channel.logo.isBlank() && !matched.logo.isNullOrBlank()) {
            channel.logo = matched.logo
        }
    }

    suspend fun syncBackupStreams(force: Boolean = false) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (force) {
            lastBackupSyncTime = 0L
        } else if (now - lastBackupSyncTime < 15 * 60 * 1000L && (backupTvList.isNotEmpty() || backupRadioList.isNotEmpty())) {
            return@withContext
        }

        try {
            val tvUrl = prefs.getString(Prefs.KEY_BACKUP_TV_URL, Prefs.DEFAULT_BACKUP_TV_URL) ?: Prefs.DEFAULT_BACKUP_TV_URL
            val radioUrl = prefs.getString(Prefs.KEY_BACKUP_RADIO_URL, Prefs.DEFAULT_BACKUP_RADIO_URL) ?: Prefs.DEFAULT_BACKUP_RADIO_URL

            val tvConfig = fetchBackupConfig(tvUrl)
            if (tvConfig?.channels != null) {
                synchronized(backupTvList) {
                    backupTvList.clear()
                    backupTvList.addAll(tvConfig.channels)
                }
                applyBackupToDb(tvConfig.channels, Prefs.TYPE_TV)
            }

            val radioConfig = fetchBackupConfig(radioUrl)
            if (radioConfig?.channels != null) {
                synchronized(backupRadioList) {
                    backupRadioList.clear()
                    backupRadioList.addAll(radioConfig.channels)
                }
                applyBackupToDb(radioConfig.channels, Prefs.TYPE_FM)
            }

            lastBackupSyncTime = now
            Log.d("ChannelRepository", "Backup streams synchronized: ${backupTvList.size} TV, ${backupRadioList.size} Radio")
        } catch (e: Exception) {
            Log.w("ChannelRepository", "Failed to sync backup streams: ${e.message}")
        }
    }

    private suspend fun applyBackupToDb(backupChannels: List<BackupChannelDto>, type: String) {
        val newEntitiesToInsert = mutableListOf<ChannelEntity>()
        for (backup in backupChannels) {
            val bId = backup.id?.trim() ?: ""
            val bName = backup.name?.trim() ?: ""
            if (bId.isEmpty() && bName.isEmpty()) continue

            var existing = if (bId.isNotEmpty()) dao.getChannelById(bId) else null
            if (existing == null && bName.isNotEmpty()) {
                existing = dao.findChannelByNameAndType(bName, type)
            }

            if (existing != null) {
                val domain = existing.toDomain()
                enrichChannelWithBackup(domain, type)
                val updatedStreamsJson = Gson().toJson(domain.streams)
                val firstUrl = domain.streams.firstOrNull()?.url ?: ""
                val firstQuality = domain.streams.firstOrNull()?.quality ?: ""
                dao.updateChannelStreams(existing.id, updatedStreamsJson, firstUrl, firstQuality)
            } else if (backup.streams?.isNotEmpty() == true) {
                val domainChannel = Channel(
                    id = if (bId.isNotEmpty()) bId else UUID.randomUUID().toString(),
                    name = if (bName.isNotEmpty()) bName else "Özel Kanal",
                    logo = backup.logo ?: "",
                    country = backup.country ?: "TR",
                    category = backup.category ?: "general",
                    type = type,
                    sortWeight = 9999
                ).apply {
                    val sList = backup.streams.mapNotNull { bStream ->
                        val u = bStream.url?.trim() ?: return@mapNotNull null
                        StreamInfo(
                            url = u,
                            quality = bStream.quality ?: "HD",
                            label = bStream.label ?: "Yedek",
                            referrer = bStream.referrer ?: "",
                            userAgent = bStream.userAgent ?: ""
                        )
                    }
                    streams.addAll(sList)
                }
                newEntitiesToInsert.add(domainChannel.toEntity())
            }
        }
        if (newEntitiesToInsert.isNotEmpty()) {
            dao.insertChannelsIgnore(newEntitiesToInsert)
            Log.i("ChannelRepository", "Inserted ${newEntitiesToInsert.size} new custom backup channels for $type")
        }
    }

    suspend fun getChannels(type: String, country: String = "", category: String = "", sortMode: String = "DEFAULT", favoritesOnly: Boolean = false, recentsOnly: Boolean = false, hideNsfw: Boolean = true, forceRefresh: Boolean = false): List<Channel> = withContext(Dispatchers.IO) {
        val count = dao.getCountByType(type, "", "") 
        val lastUpdate = prefs.getLong("${Prefs.KEY_EXTRA_CHANNELS_UPDATED_AT}_$type", 0L)
        val sevenDaysMs = 7L * 24 * 60 * 60 * 1000
        val isStale = System.currentTimeMillis() - lastUpdate > sevenDaysMs

        // FAST LOAD: Return local data immediately
        if (count > 0) {
            val entities = when {
                recentsOnly -> dao.getRecentChannels(type)
                favoritesOnly -> dao.getFavoritesPagedSorted(type, country, category, sortMode, 100, 0)
                else -> dao.getChannelsByTypePagedSorted(type, country, category, sortMode, 100, 0)
            }
            // Trigger refresh in background if stale
            if ((forceRefresh || isStale) && !isSyncing.get()) {
                scope.launch { 
                    startInitialSync(type)
                }
            } else if (System.currentTimeMillis() - lastBackupSyncTime > 15 * 60 * 1000L) {
                scope.launch {
                    syncBackupStreams(force = false)
                }
            }
            val domainChannels = entities.filter { !hideNsfw || !it.nsfw }.map { it.toDomain() }
            domainChannels.forEach { enrichChannelWithBackup(it, type) }
            return@withContext domainChannels
        } else {
            // INITIAL LOAD: If DB is empty, run sequential priority sync first
            startInitialSync(type)
            val entities = dao.getChannelsByTypePagedSorted(type, country, category, sortMode, 100, 0)
            val domainChannels = entities.filter { !hideNsfw || !it.nsfw }.map { it.toDomain() }
            domainChannels.forEach { enrichChannelWithBackup(it, type) }
            return@withContext domainChannels
        }
    }

    suspend fun getCountriesList(): List<CountryDto> = withContext(Dispatchers.IO) {
        val result = IptvJson.fetchAndParse(IptvJson.Endpoint.COUNTRIES) { json ->
            Gson().fromJson(json, Array<CountryDto>::class.java)?.toList() ?: emptyList()
        }
        result.getOrDefault(emptyList())
    }

    suspend fun getExpectedTotalCount(type: String, selectedCountries: Set<String>): Int = withContext(Dispatchers.IO) {
        if (type.equals(Prefs.TYPE_TV, true)) {
            30000
        } else {
            runCatching { api.getRadioStats().stations }.getOrDefault(45000)
        }
    }

    suspend fun startInitialSync(initialType: String, force: Boolean = false) = withContext(Dispatchers.IO) {
        if (force) {
            isSyncing.set(false)
        }
        if (!isSyncing.compareAndSet(false, true)) return@withContext
        try {
            _isSyncActive.value = true
            _syncError.value = null
            _syncProgressFraction.value = 0.05f
            val selectedCountries = prefs.getStringSet("selected_countries", setOf("ALL")) ?: setOf("ALL")
            
            if (System.currentTimeMillis() - lastBackupSyncTime > 30_000L) {
                _syncStatus.value = "Yedek yayın kaynakları senkronize ediliyor..."
                syncBackupStreams(force = true)
            } else {
                syncBackupStreams(force = false)
            }

            if (initialType == Prefs.TYPE_TV) {
                _syncStatus.value = "TV sunucusuna bağlanılıyor..."
                fetchTvChannelsForCountries(selectedCountries)
                val finalTvCount = dao.getCountByType(Prefs.TYPE_TV, "", "")
                if (finalTvCount == 0) {
                    _syncError.value = "TV kanalları indirilemedi. İnternet bağlantınızı kontrol edip tekrar deneyin."
                    _syncStatus.value = "Hata: TV kanalları yüklenemedi."
                } else {
                    _syncStatus.value = "TV kanalları başarıyla eklendi ($finalTvCount kanal)."
                    _syncProgressFraction.value = 1.0f
                    _syncError.value = null
                }
            } else {
                _syncStatus.value = "Radyo sunucusuna bağlanılıyor..."
                fetchRadioForSelectedCountries(initialType, selectedCountries)
                val finalRadioCount = dao.getCountByType(Prefs.TYPE_FM, "", "")
                if (finalRadioCount == 0) {
                    _syncError.value = "Radyo istasyonları indirilemedi. İnternet bağlantınızı kontrol edip tekrar deneyin."
                    _syncStatus.value = "Hata: Radyo istasyonları yüklenemedi."
                } else {
                    _syncStatus.value = "Radyo istasyonları başarıyla eklendi ($finalRadioCount istasyon)."
                    _syncProgressFraction.value = 1.0f
                    _syncError.value = null
                }
            }
            prefs.edit { 
                putLong("${Prefs.KEY_EXTRA_CHANNELS_UPDATED_AT}_$initialType", System.currentTimeMillis())
            }
        } catch (e: Exception) {
            Log.e("ChannelRepository", "Initial sync for $initialType failed", e)
            _syncError.value = e.localizedMessage ?: "Senkronizasyon sırasında beklenmeyen bir hata oluştu."
            _syncStatus.value = "Hata: ${_syncError.value}"
        } finally {
            _isSyncActive.value = false
            isSyncing.set(false)
            scope.launch {
                kotlinx.coroutines.delay(4000L)
                if (!_isSyncActive.value) {
                    _syncStatus.value = ""
                }
            }
        }
    }

    suspend fun triggerBackgroundGlobalSync() {
        // Disabled: Country-specific setup should never silently download 30,000+ global stations in the background during playback.
    }

    private suspend fun fetchTvChannelsForCountries(countries: Set<String>): List<ChannelEntity> = withContext(Dispatchers.IO) {
        val entities = mutableListOf<ChannelEntity>()
        try {
            _syncStatus.value = "Yayın akışları sunucudan indiriliyor..."
            _syncProgressFraction.value = 0.15f
            val streamMap = fetchAllStreamsMap()

            _syncStatus.value = "TV kanal listesi indiriliyor..."
            _syncProgressFraction.value = 0.30f

            val connection = (URL(IptvJson.CHANNELS).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 20_000
                readTimeout = 20_000
                setRequestProperty("User-Agent", "${BuildConfig.APP_NAME}/${BuildConfig.VERSION_NAME}")
                setRequestProperty("Accept", "application/json")
            }
            if (connection.responseCode in 200..299) {
                JsonReader(connection.inputStream.bufferedReader()).use { reader ->
                    reader.beginArray()
                    val batch = mutableListOf<ChannelDto>()
                    var processedCount = 0
                    while (reader.hasNext()) {
                        reader.beginObject()
                        var id: String? = null
                        var name: String? = null
                        var country: String? = null
                        var logo: String? = null
                        var website: String? = null
                        var network: String? = null
                        var owner: String? = null
                        var launched: String? = null
                        var category: String? = null
                        while (reader.hasNext()) {
                            when (reader.nextName()) {
                                "id" -> id = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "name" -> name = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "country" -> country = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "logo" -> logo = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "website" -> website = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "network" -> network = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "owner" -> owner = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "launched" -> launched = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "categories" -> {
                                    if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                                        reader.beginArray()
                                        if (reader.hasNext() && reader.peek() == JsonToken.STRING) {
                                            category = reader.nextString()
                                        }
                                        while (reader.hasNext()) reader.skipValue()
                                        reader.endArray()
                                    } else {
                                        reader.skipValue()
                                    }
                                }
                                else -> reader.skipValue()
                            }
                        }
                        reader.endObject()
                        val cCode = country?.uppercase() ?: ""
                        if (countries.contains("ALL") || countries.contains(cCode)) {
                            batch.add(
                                ChannelDto(
                                    id = id,
                                    name = name,
                                    country = country,
                                    logo = logo,
                                    website = website,
                                    network = network,
                                    owner = owner,
                                    launched = launched,
                                    stationuuid = null,
                                    urlResolved = null,
                                    favicon = null,
                                    countryCode = country,
                                    url = null,
                                    clickcount = null,
                                    channelId = id,
                                    categories = if (category != null) listOf(category) else null,
                                    tags = null,
                                    width = null,
                                    height = null
                                )
                            )
                        }
                        if (batch.size >= 300) {
                            val mapped = mapTvChannels(batch, streamMap, Prefs.TYPE_TV)
                            entities.addAll(mapped)
                            upsertPreservingUserData(mapped)
                            processedCount += mapped.size
                            _syncStatus.value = "Veritabanına işleniyor... ($processedCount kanal)"
                            _syncProgressFraction.value = (0.30f + (processedCount.toFloat() / 15000f) * 0.65f).coerceAtMost(0.95f)
                            batch.clear()
                        }
                    }
                    if (batch.isNotEmpty()) {
                        val mapped = mapTvChannels(batch, streamMap, Prefs.TYPE_TV)
                        entities.addAll(mapped)
                        upsertPreservingUserData(mapped)
                        processedCount += mapped.size
                        _syncStatus.value = "Veritabanına işleniyor... ($processedCount kanal)"
                        _syncProgressFraction.value = 0.98f
                        batch.clear()
                    }
                    reader.endArray()
                }
            } else {
                _syncError.value = "TV sunucusu yanıt vermedi (HTTP ${connection.responseCode})."
            }
        } catch (e: Exception) {
            Log.e("ChannelRepository", "Streaming parse of CHANNELS failed", e)
            _syncError.value = "TV kanalları çekilirken hata oluştu: ${e.localizedMessage}"
        }
        entities
    }

    private suspend fun fetchAllStreamsMap(): Map<String, List<StreamInfo>> = withContext(Dispatchers.IO) {
        val result = mutableMapOf<String, MutableList<StreamInfo>>()
        try {
            val connection = (URL(IptvJson.STREAMS).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 20_000
                readTimeout = 20_000
                setRequestProperty("User-Agent", "${BuildConfig.APP_NAME}/${BuildConfig.VERSION_NAME}")
                setRequestProperty("Accept", "application/json")
            }
            if (connection.responseCode in 200..299) {
                JsonReader(connection.inputStream.bufferedReader()).use { reader ->
                    reader.beginArray()
                    while (reader.hasNext()) {
                        reader.beginObject()
                        var channelId: String? = null
                        var url: String? = null
                        var height = 0
                        while (reader.hasNext()) {
                            when (reader.nextName()) {
                                "channel" -> channelId = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "url" -> url = if (reader.peek() != JsonToken.NULL) reader.nextString() else { reader.skipValue(); null }
                                "height" -> height = if (reader.peek() != JsonToken.NULL) reader.nextInt() else { reader.skipValue(); 0 }
                                else -> reader.skipValue()
                            }
                        }
                        reader.endObject()
                        if (!channelId.isNullOrEmpty() && !url.isNullOrEmpty()) {
                            val quality = when {
                                height >= 4320 -> "8K"
                                height >= 2160 -> "4K"
                                height >= 1080 -> "FHD"
                                height >= 720 -> "HD"
                                height > 0 -> "SD"
                                else -> "HD"
                            }
                            result.getOrPut(channelId) { mutableListOf() }.add(StreamInfo(url = url, quality = quality))
                        }
                    }
                    reader.endArray()
                }
            }
        } catch (e: Exception) {
            Log.e("ChannelRepository", "Failed to stream parse STREAMS", e)
        }
        result
    }

    suspend fun search(query: String, type: String? = null): List<Channel> = withContext(Dispatchers.IO) {
        val sanitized = if (query.isNotEmpty()) "$query*" else ""
        if (sanitized.isEmpty()) return@withContext emptyList()
        
        val entities = if (type != null) {
            dao.searchByType(sanitized, type)
        } else {
            dao.searchGlobal(sanitized)
        }
        val domainChannels = entities.map { it.toDomain() }
        domainChannels.forEach { enrichChannelWithBackup(it, it.type) }
        domainChannels
    }

    suspend fun searchGlobal(query: String): List<Channel> = search(query)

    suspend fun getChannelsPaged(type: String, country: String, category: String, sortMode: String, favoritesOnly: Boolean, recentsOnly: Boolean, hideNsfw: Boolean, limit: Int, offset: Int): List<Channel> = withContext(Dispatchers.IO) {
        if (recentsOnly) return@withContext emptyList()
        val entities = if (favoritesOnly) {
            dao.getFavoritesPagedSorted(type, country, category, sortMode, limit, offset)
        } else {
            dao.getChannelsByTypePagedSorted(type, country, category, sortMode, limit, offset)
        }
        val domainChannels = entities.filter { !hideNsfw || !it.nsfw }.map { it.toDomain() }
        domainChannels.forEach { enrichChannelWithBackup(it, type) }
        domainChannels
    }

    suspend fun getTotalCount(type: String, country: String = "", category: String = "", favoritesOnly: Boolean = false, recentsOnly: Boolean = false): Int = withContext(Dispatchers.IO) {
        when {
            recentsOnly -> 20
            favoritesOnly -> dao.getFavoritesCount(type)
            else -> dao.getCountByType(type, country, category)
        }
    }

    suspend fun getFilterOptions(type: String): Pair<List<String>, List<String>> = withContext(Dispatchers.IO) {
        val countries = dao.getCountries(type)
        val categories = dao.getCategories(type)
        countries to categories
    }

    suspend fun getChannelById(id: String): Channel? = withContext(Dispatchers.IO) {
        val domain = dao.getChannelById(id)?.toDomain() ?: return@withContext null
        enrichChannelWithBackup(domain, domain.type)
        domain
    }

    suspend fun setFavorite(id: String, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        dao.setFavorite(id, isFavorite)
    }

    suspend fun swapOrder(c1: Channel, c2: Channel) = withContext(Dispatchers.IO) {
        val currentOrder1 = if (c1.userOrder == Int.MAX_VALUE) 1000000 else c1.userOrder
        val currentOrder2 = if (c2.userOrder == Int.MAX_VALUE) 1000001 else c2.userOrder
        dao.setUserOrder(c1.id, currentOrder2)
        dao.setUserOrder(c2.id, currentOrder1)
    }

    suspend fun updateLastViewed(channelId: String) = withContext(Dispatchers.IO) {
        dao.updateLastViewed(channelId, System.currentTimeMillis())
    }

    suspend fun clearRecents() = withContext(Dispatchers.IO) {
        dao.clearRecentChannels()
    }

    private fun mapTvChannels(channels: List<ChannelDto>, streamMap: Map<String, List<StreamInfo>>, type: String): List<ChannelEntity> {
        val selectedCountries = prefs.getStringSet("selected_countries", setOf("ALL")) ?: setOf("ALL")
        val filteredChannels = if (selectedCountries.contains("ALL")) {
            channels
        } else {
            channels.filter { dto ->
                val cCode = dto.country?.uppercase() ?: ""
                selectedCountries.contains(cCode)
            }
        }
        val validChannels = filteredChannels.filter { dto ->
            val id = dto.id ?: ""
            !streamMap[id].isNullOrEmpty() || !dto.url.isNullOrEmpty()
        }
        return validChannels.map { dto ->
            val popularityWeight = dto.clickcount ?: ChannelPriorityRegistry.getChannelWeight(dto.country, dto.name)
            val domainChannel = Channel(
                id = dto.id ?: "",
                name = dto.name ?: "Unknown",
                logo = dto.logo ?: "",
                country = dto.country ?: "",
                website = dto.website ?: "",
                network = dto.network ?: "",
                owner = dto.owner ?: "",
                launched = dto.launched ?: "",
                sortWeight = popularityWeight,
                type = type
            ).apply {
                val channelStreams = streamMap[id]
                if (!channelStreams.isNullOrEmpty()) {
                    this.streams.addAll(channelStreams)
                } else if (!dto.url.isNullOrEmpty()) {
                    this.streams.add(StreamInfo(url = dto.url))
                }
                val primaryCategory = dto.categories?.firstOrNull() ?: ""
                if (primaryCategory.isNotEmpty()) {
                    this.category = primaryCategory
                    this.categories.add(primaryCategory)
                }
                enrichChannelWithBackup(this, type)
            }
            domainChannel.toEntity()
        }
    }

    private fun mapRadioStations(stations: List<ChannelDto>, type: String): List<ChannelEntity> {
        return stations.map { dto ->
            val domainChannel = Channel(
                id = dto.stationuuid ?: UUID.randomUUID().toString(),
                name = dto.name ?: "Unknown",
                logo = dto.favicon ?: "",
                country = dto.countryCode ?: "",
                sortWeight = dto.clickcount ?: 0,
                type = type
            ).apply {
                val resolved = dto.urlResolved?.trim()
                val raw = dto.url?.trim()
                if (!resolved.isNullOrBlank()) {
                    this.streams.add(StreamInfo(url = resolved))
                }
                if (!raw.isNullOrBlank() && raw != resolved) {
                    this.streams.add(StreamInfo(url = raw))
                }
                val primaryTag = dto.tags?.split(",")?.firstOrNull()?.trim() ?: ""
                if (primaryTag.isNotEmpty()) {
                    this.category = primaryTag
                    this.categories.add(primaryTag)
                }
                enrichChannelWithBackup(this, type)
            }
            domainChannel.toEntity()
        }
    }

    private suspend fun fetchRadioForSelectedCountries(type: String, selectedCountries: Set<String>): List<ChannelEntity> {
        if (selectedCountries.contains("ALL") || selectedCountries.isEmpty()) {
            return fetchFullRadioList(type)
        }
        val entities = mutableListOf<ChannelEntity>()
        val preferredServer = prefs.getString(Prefs.KEY_RADIO_SERVER, Prefs.RADIO_SERVER_AUTO) ?: Prefs.RADIO_SERVER_AUTO
        val serversToTry = if (preferredServer != Prefs.RADIO_SERVER_AUTO && MediatorApi.RADIO_SERVERS.containsKey(preferredServer)) {
            val preferred = preferredServer to MediatorApi.RADIO_SERVERS[preferredServer]!!
            val others = MediatorApi.RADIO_SERVERS.filterKeys { it != preferredServer }
            mapOf(preferred) + others
        } else {
            MediatorApi.RADIO_SERVERS
        }
        val totalCc = selectedCountries.size
        var currentCcIndex = 0
        for (cc in selectedCountries) {
            currentCcIndex++
            var fetchSuccess = false
            for ((serverKey, baseUrl) in serversToTry) {
                try {
                    _syncStatus.value = "Radyo istasyonları indiriliyor ($cc / $serverKey)..."
                    _syncProgressFraction.value = 0.10f + (currentCcIndex.toFloat() / totalCc.toFloat()) * 0.40f
                    val url = "${baseUrl}json/stations/search?countrycode=$cc&hidebroken=true&order=clickcount&reverse=true&limit=1000"
                    val stations = api.getRadioChannels(url)
                    val mapped = mapRadioStations(stations, type)
                    entities.addAll(mapped)
                    fetchSuccess = true
                    break
                } catch (e: Exception) {
                    Log.w("ChannelRepository", "Radio server ($serverKey) failed for $cc, trying next...", e)
                }
            }
            if (!fetchSuccess) {
                Log.e("ChannelRepository", "All radio servers failed for country $cc")
            }
        }

        if (entities.isNotEmpty()) {
            _syncStatus.value = "Radyo istasyonları veritabanına işleniyor... (${entities.size} istasyon)"
            _syncProgressFraction.value = 0.70f
            entities.chunked(500).forEachIndexed { index, batch ->
                upsertPreservingUserData(batch)
                val savedCount = ((index + 1) * 500).coerceAtMost(entities.size)
                _syncStatus.value = "Veritabanına kaydediliyor... ($savedCount / ${entities.size})"
                _syncProgressFraction.value = 0.70f + ((index + 1).toFloat() / (entities.size / 500f + 1)) * 0.28f
            }
        } else {
            _syncError.value = "Seçilen ülkeler için radyo istasyonları çekilemedi."
        }

        return entities
    }

    private suspend fun fetchFullRadioList(type: String): List<ChannelEntity> {
        var stations: List<ChannelDto> = emptyList()
        var fetchSuccess = false
        val preferredServer = prefs.getString(Prefs.KEY_RADIO_SERVER, Prefs.RADIO_SERVER_AUTO) ?: Prefs.RADIO_SERVER_AUTO
        val serversToTry = if (preferredServer != Prefs.RADIO_SERVER_AUTO && MediatorApi.RADIO_SERVERS.containsKey(preferredServer)) {
            val preferred = preferredServer to MediatorApi.RADIO_SERVERS[preferredServer]!!
            val others = MediatorApi.RADIO_SERVERS.filterKeys { it != preferredServer }
            mapOf(preferred) + others
        } else {
            MediatorApi.RADIO_SERVERS
        }

        _syncStatus.value = "Radyo sunucusuna bağlanılıyor..."
        _syncProgressFraction.value = 0.10f

        // Try limit=30000 with hidebroken=true for fast response
        for ((serverKey, baseUrl) in serversToTry) {
            try {
                val fullUrl = "${baseUrl}json/stations/search?hidebroken=true&order=clickcount&reverse=true&limit=30000"
                Log.d("ChannelRepository", "Radio server ($serverKey) deneniyor: $fullUrl")
                _syncStatus.value = "Radyo istasyonları sunucudan indiriliyor ($serverKey)..."
                _syncProgressFraction.value = 0.25f
                stations = api.getRadioChannels(fullUrl)
                if (stations.isNotEmpty()) {
                    fetchSuccess = true
                    Log.d("ChannelRepository", "$serverKey sunucusundan ${stations.size} radyo istasyonu çekildi")
                    break
                }
            } catch (e: Exception) {
                Log.w("ChannelRepository", "Radyo sunucusu ($serverKey) yanıt vermedi: ${e.message}, alternatif deneniyor...")
            }
        }

        // Fallback: If full search failed or timed out, try smaller query with limit=10000
        if (!fetchSuccess) {
            _syncStatus.value = "Alternatif radyo sunucusu deneniyor..."
            for ((serverKey, baseUrl) in serversToTry) {
                try {
                    val fallbackUrl = "${baseUrl}json/stations/search?hidebroken=true&order=clickcount&reverse=true&limit=10000"
                    _syncStatus.value = "Popüler radyo istasyonları indiriliyor ($serverKey)..."
                    _syncProgressFraction.value = 0.35f
                    stations = api.getRadioChannels(fallbackUrl)
                    if (stations.isNotEmpty()) {
                        fetchSuccess = true
                        Log.d("ChannelRepository", "Fallback: $serverKey sunucusundan ${stations.size} radyo istasyonu çekildi")
                        break
                    }
                } catch (e: Exception) {
                    Log.w("ChannelRepository", "Fallback radio server ($serverKey) failed", e)
                }
            }
        }

        if (fetchSuccess && stations.isNotEmpty()) {
            _syncStatus.value = "Radyo istasyonları işleniyor (${stations.size} istasyon)..."
            _syncProgressFraction.value = 0.50f
            val mapped = mapRadioStations(stations, type)
            _syncStatus.value = "Veritabanına kaydediliyor..."
            _syncProgressFraction.value = 0.65f

            mapped.chunked(500).forEachIndexed { index, batch ->
                upsertPreservingUserData(batch)
                val savedSoFar = ((index + 1) * 500).coerceAtMost(mapped.size)
                _syncStatus.value = "Veritabanına kaydediliyor... ($savedSoFar / ${mapped.size})"
                _syncProgressFraction.value = 0.65f + ((index + 1).toFloat() / (mapped.size / 500f + 1)) * 0.33f
            }
            return mapped
        } else {
            _syncError.value = "Radyo sunucularından hiç istasyon çekilemedi. İnternet bağlantınızı kontrol edip tekrar deneyin."
            return emptyList()
        }
    }

    private suspend fun upsertPreservingUserData(newEntities: List<ChannelEntity>) {
        if (newEntities.isEmpty()) return
        newEntities.chunked(500).forEach { batch -> dao.upsertPreservingUserData(batch) }
    }
}
