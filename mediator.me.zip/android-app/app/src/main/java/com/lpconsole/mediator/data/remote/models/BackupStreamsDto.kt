package com.lpconsole.mediator.data.remote.models

import com.google.gson.annotations.SerializedName

data class BackupConfigDto(
    @SerializedName("version") val version: Int? = 1,
    @SerializedName("updatedAt") val updatedAt: String? = null,
    @SerializedName("channels") val channels: List<BackupChannelDto>? = emptyList()
)

data class BackupChannelDto(
    @SerializedName("id") val id: String? = null,
    @SerializedName("name") val name: String? = null,
    @SerializedName("country") val country: String? = null,
    @SerializedName("category") val category: String? = null,
    @SerializedName("logo") val logo: String? = null,
    @SerializedName("priority") val priority: Boolean = false,
    @SerializedName("streams") val streams: List<BackupStreamDto>? = emptyList()
)

data class BackupStreamDto(
    @SerializedName("url") val url: String? = null,
    @SerializedName("quality") val quality: String? = null,
    @SerializedName("label") val label: String? = null,
    @SerializedName("referrer") val referrer: String? = null,
    @SerializedName("userAgent") val userAgent: String? = null
)
