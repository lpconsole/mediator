package com.lpconsole.mediator.data.remote.models

import com.google.gson.annotations.SerializedName

data class ChannelDto(
    @SerializedName("id") val id: String?,
    @SerializedName("name") val name: String?,
    @SerializedName("country") val country: String?,
    @SerializedName("logo") val logo: String?,
    @SerializedName("website") val website: String?,
    @SerializedName("network") val network: String?,
    @SerializedName("owner") val owner: String?,
    @SerializedName("launched") val launched: String?,
    
    // Radio specific
    @SerializedName("stationuuid") val stationuuid: String?,
    @SerializedName("url_resolved") val urlResolved: String?,
    @SerializedName("favicon") val favicon: String?,
    @SerializedName("countrycode") val countryCode: String?,
    @SerializedName("url") val url: String?,
    @SerializedName("clickcount") val clickcount: Int?,
    
    // IPTV Stream specific
    @SerializedName("channel") val channelId: String?,
    @SerializedName("categories") val categories: List<String>?,
    @SerializedName("tags") val tags: String?,
    @SerializedName("width") val width: Int?,
    @SerializedName("height") val height: Int?
)
