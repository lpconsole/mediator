package com.lpconsole.mediator.data.local.entities

import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.Index
import androidx.room.PrimaryKey
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.data.StreamInfo

@Entity(
    tableName = "channels",
    indices = [
        Index(value = ["name"]),
        Index(value = ["type"]),
        Index(value = ["isFavorite"]),
        Index(value = ["lastViewedAt"]),
        Index(value = ["type", "country", "category"])
    ]
)
data class ChannelEntity(
    @PrimaryKey val id: String,
    val type: String,
    val name: String,
    val country: String,
    val website: String,
    val logo: String,
    val network: String,
    val owner: String,
    val launched: String,
    val nsfw: Boolean,
    val sortWeight: Int,
    val category: String = "",
    val streamUrl: String = "",
    val quality: String = "",
    val streamsJson: String = "",
    val isFavorite: Boolean = false,
    val lastViewedAt: Long = 0,
    val userOrder: Int = Int.MAX_VALUE
)

@Fts4(contentEntity = ChannelEntity::class)
@Entity(tableName = "channels_fts")
data class ChannelFtsEntity(
    val name: String,
    val country: String,
    val category: String
)

fun ChannelEntity.toDomain(): Channel {
    return Channel(
        id = id,
        type = type,
        name = name,
        country = country,
        website = website,
        logo = logo,
        network = network,
        owner = owner,
        launched = launched,
        nsfw = nsfw,
        sortWeight = sortWeight,
        category = category,
        isFavorite = isFavorite,
        lastViewedAt = lastViewedAt,
        userOrder = userOrder
    ).apply {
        if (streamsJson.isNotBlank()) {
            try {
                val listType = object : com.google.gson.reflect.TypeToken<List<StreamInfo>>() {}.type
                val parsed: List<StreamInfo>? = com.google.gson.Gson().fromJson(streamsJson, listType)
                if (!parsed.isNullOrEmpty()) {
                    streams.addAll(parsed)
                }
            } catch (_: Throwable) {}
        }
        if (streams.isEmpty() && streamUrl.isNotEmpty()) {
            streams.add(StreamInfo(url = streamUrl, quality = this@toDomain.quality))
        }
    }
}

fun Channel.toEntity(): ChannelEntity = ChannelEntity(
    id = id,
    type = type,
    name = name,
    country = country,
    website = website,
    logo = logo,
    network = network,
    owner = owner,
    launched = launched,
    nsfw = nsfw,
    sortWeight = sortWeight,
    category = category,
    streamUrl = streams.firstOrNull()?.url ?: "",
    quality = streams.firstOrNull()?.quality ?: "",
    streamsJson = if (streams.isNotEmpty()) com.google.gson.Gson().toJson(streams) else "",
    isFavorite = isFavorite,
    lastViewedAt = lastViewedAt,
    userOrder = userOrder
)
