package com.lpconsole.mediator.ui.features.player

import android.graphics.Color
import android.view.LayoutInflater
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.lpconsole.mediator.R

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayer(
    player: ExoPlayer,
    videoScale: Int = 0,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            (LayoutInflater.from(context).inflate(R.layout.view_player, null) as PlayerView).apply {
                this.player = player
            }
        },
        update = { view ->
            if (view.player != player) {
                view.player = player
            }
            val targetMode = when (videoScale) {
                1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM // Fill
                2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL // Stretch
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT // Fit
            }
            if (view.resizeMode != targetMode) {
                view.resizeMode = targetMode
            }
        },
        onRelease = { view ->
            // ExoPlayer ile Surface bağlantısını güvenli şekilde kopar (Google AI tavsiyesi 1 & 2)
            view.player = null
        },
        modifier = modifier
            .fillMaxSize()
            .background(ComposeColor.Black)
    )
}
