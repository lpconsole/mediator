package com.lpconsole.mediator.di

import android.content.Context
import androidx.room.Room
import com.lpconsole.mediator.data.local.MediatorDatabase
import com.lpconsole.mediator.data.local.dao.ChannelDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MediatorDatabase {
        return Room.databaseBuilder(context, MediatorDatabase::class.java, "mediator_v3.db")
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideChannelDao(db: MediatorDatabase): ChannelDao = db.channelDao()
}
