package com.lpconsole.mediator.iptv

import com.lpconsole.mediator.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object IptvJson {
    const val BASE_URL = "https://iptv-org.github.io/api/"
    const val CHANNELS = "${BASE_URL}channels.json"
    const val STREAMS = "${BASE_URL}streams.json"
    const val GUIDES = "${BASE_URL}guides.json"
    const val BLOCKLIST = "${BASE_URL}blocklist.json"
    const val CATEGORIES = "${BASE_URL}categories.json"
    const val COUNTRIES = "${BASE_URL}countries.json"
    const val LANGUAGES = "${BASE_URL}languages.json"
    const val REGIONS = "${BASE_URL}regions.json"
    const val SUBDIVISIONS = "${BASE_URL}subdivisions.json"
    enum class Endpoint(val url: String) {
        CHANNELS(IptvJson.CHANNELS),
        STREAMS(IptvJson.STREAMS),
        GUIDES(IptvJson.GUIDES),
        BLOCKLIST(IptvJson.BLOCKLIST),
        CATEGORIES(IptvJson.CATEGORIES),
        COUNTRIES(IptvJson.COUNTRIES),
        LANGUAGES(IptvJson.LANGUAGES),
        REGIONS(IptvJson.REGIONS),
        SUBDIVISIONS(IptvJson.SUBDIVISIONS),
    }
    /**
     * Ham JSON metnini ağdan indirir (IO Thread)
     */
    suspend fun fetchRaw(url: String, timeoutMillis: Int = 12_000): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = timeoutMillis
                readTimeout = timeoutMillis
                setRequestProperty("User-Agent", "MediaTor/${BuildConfig.VERSION_NAME}")
                setRequestProperty("Accept", "application/json")
            }
            val statusCode = connection.responseCode
            if (statusCode in 200..299) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                throw IllegalStateException("Sunucu hatası: HTTP $statusCode")
            }
        }
    }
    /**
     * Verilen JSON metnini arayüzü kitlemeden CPU iş parçacığında parse eder.
     */
    suspend fun <T> parse(jsonString: String, parser: (String) -> T): Result<T> = withContext(Dispatchers.Default) {
        runCatching {
            parser(jsonString)
        }
    }
    /**
     * Hem indirme hem de parse işlemini tek adımda tamamlar.
     * İndirmeyi IO, parse işlemini CPU (Default) iş parçacığında yapar.
     * @param endpoint Hedef API ucu
     * @param parser İndirilen JSON string'ini hedef modele çeviren lambda fonksiyonu
     */
    suspend fun <T> fetchAndParse(endpoint: Endpoint, parser: (String) -> T): Result<T> = withContext(Dispatchers.IO) {
        val rawResult = fetchRaw(endpoint.url)
        rawResult.mapCatching { json ->
            withContext(Dispatchers.Default) {
                parser(json)
            }
        }
    }
    // Parse için
    suspend fun <T> fetchAndParse(url: String, parser: (String) -> T): Result<T> = withContext(Dispatchers.IO) {
        val rawResult = fetchRaw(url)
        rawResult.mapCatching { json ->
            withContext(Dispatchers.Default) {
                parser(json)
            }
        }
    }
}