package com.lpconsole.mediator.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Tv
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Icon
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.util.LogoManager
import com.lpconsole.mediator.util.LogoManagerEntryPoint
import dagger.hilt.android.EntryPointAccessors

@Composable
fun ChannelLogo(
    channel: Channel?,
    nowPlayingArtwork: Any? = null,
    modifier: Modifier = Modifier,
    iconSize: Dp = 24.dp,
    tint: Color = Color.White.copy(alpha = 0.7f),
    logoManager: LogoManager? = null
) {
    if (channel == null) return
    val context = LocalContext.current
    val manager = logoManager ?: remember(context) {
        try {
            EntryPointAccessors.fromApplication(
                context.applicationContext,
                LogoManagerEntryPoint::class.java
            ).logoManager()
        } catch (_: Exception) {
            null
        }
    }

    val candidates = remember(channel.id, channel.logo, channel.website, nowPlayingArtwork, manager) {
        manager?.getLogoCandidates(channel, nowPlayingArtwork) ?: emptyList()
    }

    var sourceIndex by remember(channel.id, nowPlayingArtwork) { mutableIntStateOf(0) }
    val activeCandidate = candidates.getOrNull(sourceIndex)
    val iconVector = if (channel.type == Prefs.TYPE_FM) Icons.Default.Radio else Icons.Default.Tv

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        if (activeCandidate != null) {
            val request = remember(activeCandidate) {
                ImageRequest.Builder(context)
                    .data(activeCandidate)
                    .crossfade(true)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .memoryCachePolicy(CachePolicy.ENABLED)
                    .build()
            }
            AsyncImage(
                model = request,
                contentDescription = channel.name,
                contentScale = ContentScale.Fit,
                onError = {
                    if (activeCandidate is String) {
                        manager?.markCandidateFailed(channel.id, activeCandidate)
                    }
                    if (sourceIndex + 1 < candidates.size) {
                        sourceIndex++
                    } else {
                        sourceIndex = candidates.size
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                imageVector = iconVector,
                contentDescription = channel.name,
                tint = tint,
                modifier = Modifier.size(iconSize)
            )
        }
    }
}
