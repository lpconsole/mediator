package com.lpconsole.mediator.data.remote.api

import com.lpconsole.mediator.data.remote.models.ChannelDto
import com.lpconsole.mediator.data.remote.models.CountryDto
import retrofit2.http.GET
import retrofit2.http.Url

data class ChannelsStat(val total: Int = 0)
data class TvStatsDto(val channels: ChannelsStat = ChannelsStat())
data class RadioStatsDto(val stations: Int = 0)
interface MediatorApi {
    companion object {
        const val TV_BASE_URL = "https://iptv-org.github.io/"
        @Volatile
        var RADIO_API_LIMIT: Int = 0
        const val RADIO_ALL_STATS = "https://all.api.radio-browser.info/json/stats"
        val RADIO_SERVERS = mapOf(
            "ALL" to "https://all.api.radio-browser.info/",
            "DE" to "https://de1.api.radio-browser.info/",
            "NL" to "https://nl1.api.radio-browser.info/",
            "FR" to "https://fr1.api.radio-browser.info/",
            "AT" to "https://at1.api.radio-browser.info/",
            "IT" to "https://it1.api.radio-browser.info/"
        )
    }
    @GET("api/channels.json")
    suspend fun getTvChannels(): List<ChannelDto>
    @GET("api/streams.json")
    suspend fun getTvStreams(): List<ChannelDto>
    @GET("api/countries.json")
    suspend fun getCountries(): List<CountryDto>
    @GET
    suspend fun getChannelsByUrl(@Url url: String): List<ChannelDto>
    @GET(RADIO_ALL_STATS)
    suspend fun getRadioStats(): RadioStatsDto
    @GET
    suspend fun getRadioChannels(@Url url: String): List<ChannelDto>
    suspend fun refreshRadioLimit(): Int {
        return runCatching {
            val stats = getRadioStats()
            RADIO_API_LIMIT = stats.stations
            stats.stations
        }.getOrDefault(RADIO_API_LIMIT)
    }
}
