package com.lpconsole.mediator.data

import com.lpconsole.mediator.Prefs

data class Channel(
    var id: String = "",
    var type: String = Prefs.TYPE_TV,
    var name: String = "",
    var country: String = "",
    var website: String = "",
    var logo: String = "",
    var network: String = "",
    var owner: String = "",
    var launched: String = "",
    var nsfw: Boolean = false,
    var sortWeight: Int = 0,
    var category: String = "",
    var isFavorite: Boolean = false,
    var lastViewedAt: Long = 0,
    var userOrder: Int = Int.MAX_VALUE,
    val categories: MutableList<String> = mutableListOf(),
    val streams: MutableList<StreamInfo> = mutableListOf()
)

data class StreamInfo(
    var title: String = "",
    var url: String = "",
    var quality: String = "",
    var label: String = "",
    var userAgent: String = "",
    var referrer: String = ""
)

data class ExtraJsonResult(
    val text: String?,
    val fetchedFromNetwork: Boolean,
    val fileDateMs: Long
)
