package com.lpconsole.mediator.ui.features.main

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.SurfaceDefaults
import com.lpconsole.mediator.Prefs
import com.lpconsole.mediator.data.Channel
import com.lpconsole.mediator.data.StreamInfo
import com.lpconsole.mediator.ui.components.ChannelLogo
import com.lpconsole.mediator.ui.components.LyricsOverlay
import com.lpconsole.mediator.ui.components.UpdateDialog
import com.lpconsole.mediator.ui.features.player.RadioPoster
import com.lpconsole.mediator.ui.features.player.VideoPlayer
import com.lpconsole.mediator.ui.features.settings.SettingsScreen
import com.lpconsole.mediator.ui.theme.Primary
import com.lpconsole.mediator.ui.util.dualControl
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.time.Duration.Companion.milliseconds

@Composable
fun MainScreen(viewModel: MainViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    val itemHeightPx = with(density) { 70.dp.roundToPx() }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) {
                viewModel.resumePlaybackIfNeeded()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    if (uiState.isFirstRun) {
        WelcomeScreen(
            uiState = uiState,
            onStartSync = { countries, type, onDone -> viewModel.startSyncForType(countries, type, onDone) },
            onComplete = { viewModel.completeSetup() }
        )
        return
    }

    BackHandler(enabled = uiState.isSettingsVisible || uiState.isSearchVisible || uiState.isMenuVisible || uiState.isTrackSelectorVisible || uiState.isFilterDialogVisible || uiState.isLyricsVisible) {
        if (uiState.isSettingsVisible) {
            viewModel.toggleSettings()
        } else if (uiState.isLyricsVisible) {
            viewModel.toggleLyrics()
        } else if (uiState.isFilterDialogVisible) {
            viewModel.toggleFilterDialog()
        } else if (uiState.isTrackSelectorVisible) {
            viewModel.toggleTrackSelector()
        } else if (uiState.isSearchVisible) {
            viewModel.toggleSearch()
        } else if (uiState.isMenuVisible) {
            viewModel.hideMenuManually()
        }
    }
    
    val playerFocusRequester = remember { FocusRequester() }
    val channelListFocusRequester = remember { FocusRequester() }

    val isAnyOverlayOpen = uiState.isMenuVisible ||
            uiState.isSettingsVisible ||
            uiState.isSearchVisible ||
            uiState.isFilterDialogVisible ||
            uiState.isTrackSelectorVisible ||
            uiState.isLyricsVisible

    LaunchedEffect(isAnyOverlayOpen) {
        if (!isAnyOverlayOpen) {
            delay(100.milliseconds)
            playerFocusRequester.requestFocus()
        }
    }

    LaunchedEffect(uiState.isMenuVisible, uiState.isSettingsVisible, uiState.CURRENT_CHANNEL?.id, uiState.channels) {
        if (uiState.isMenuVisible && !uiState.isSettingsVisible && uiState.channels.isNotEmpty()) {
            val targetIndex = uiState.channels.indexOfFirst { it.id == uiState.CURRENT_CHANNEL?.id }.coerceAtLeast(0)
            val viewportHeight = listState.layoutInfo.viewportSize.height
            val centerOffsetPx = if (viewportHeight > 0) {
                -((viewportHeight - itemHeightPx) / 2)
            } else {
                with(density) { -280.dp.roundToPx() }
            }
            
            listState.scrollToItem(targetIndex, centerOffsetPx)
            
            delay(80.milliseconds)
            
            try {
                channelListFocusRequester.requestFocus()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black)
    ) {
        // 1. Background Player
        Box(
            modifier = Modifier
                .fillMaxSize()
                .focusRequester(playerFocusRequester)
                .focusable()
                .onKeyEvent { keyEvent ->
                    keyEvent.type == KeyEventType.KeyDown && when (keyEvent.key) {
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                            if (!isAnyOverlayOpen) {
                                viewModel.onInteraction()
                                true
                            } else false
                        }

                        Key.Menu, Key.Settings -> {
                            if (!isAnyOverlayOpen) {
                                viewModel.toggleTrackSelector()
                                true
                            } else false
                        }

                        Key.DirectionUp -> {
                            if (!isAnyOverlayOpen) {
                                viewModel.zapNext()
                                true
                            } else false
                        }

                        Key.DirectionDown -> {
                            if (!isAnyOverlayOpen) {
                                viewModel.zapPrevious()
                                true
                            } else false
                        }

                        Key.DirectionLeft -> {
                            if (!isAnyOverlayOpen) {
                                if (uiState.currentType == Prefs.TYPE_FM) {
                                    viewModel.cycleRadioPoster(-1)
                                } else {
                                    viewModel.onInteraction()
                                }
                                true
                            } else false
                        }

                        Key.DirectionRight -> {
                            if (!isAnyOverlayOpen) {
                                if (uiState.currentType == Prefs.TYPE_FM) {
                                    viewModel.cycleRadioPoster(1)
                                } else {
                                    viewModel.onInteraction()
                                }
                                true
                            } else false
                        }

                        Key.Zero, Key.NumPad0 -> { viewModel.enterDigit(0); true }
                        Key.One, Key.NumPad1 -> { viewModel.enterDigit(1); true }
                        Key.Two, Key.NumPad2 -> { viewModel.enterDigit(2); true }
                        Key.Three, Key.NumPad3 -> { viewModel.enterDigit(3); true }
                        Key.Four, Key.NumPad4 -> { viewModel.enterDigit(4); true }
                        Key.Five, Key.NumPad5 -> { viewModel.enterDigit(5); true }
                        Key.Six, Key.NumPad6 -> { viewModel.enterDigit(6); true }
                        Key.Seven, Key.NumPad7 -> { viewModel.enterDigit(7); true }
                        Key.Eight, Key.NumPad8 -> { viewModel.enterDigit(8); true }
                        Key.Nine, Key.NumPad9 -> { viewModel.enterDigit(9); true }
                        Key.Back, Key.Escape -> false

                        else -> false
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            viewModel.onInteraction()
                        },
                        onLongPress = {
                            viewModel.toggleTrackSelector()
                        }
                    )
                }
        ) {
            if (uiState.currentType == Prefs.TYPE_FM) {
                RadioPoster(
                    posterFile = uiState.radioPoster,
                    selectedPosterCode = uiState.selectedPosterCode,
                    audioAmplitudes = uiState.audioAmplitudes,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                VideoPlayer(
                    player = viewModel.player,
                    videoScale = uiState.videoScale,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // --- FULL SCREEN INITIAL LOADING OVERLAY ---
        AnimatedVisibility(
            visible = uiState.isLoading && uiState.channels.isEmpty(),
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = uiState.SYNC_PROGRESS.ifEmpty { "Veriler hazırlanıyor..." },
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Normal
                )
            }
        }

        // --- RADIO POSTER LOADING OVERLAY ---
        AnimatedVisibility(
            visible = uiState.currentType == Prefs.TYPE_FM && uiState.isRadioPosterLoading,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 40.dp, end = 160.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Arka plan yükleniyor...",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        // --- RADIO POSTER INDEX INDICATOR OVERLAY ---
        AnimatedVisibility(
            visible = uiState.currentType == Prefs.TYPE_FM && uiState.isPosterIndicatorVisible && uiState.availablePosters.isNotEmpty(),
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 48.dp)
        ) {
            val activeCode = if (uiState.selectedPosterCode.equals("default", ignoreCase = true) || uiState.selectedPosterCode.isBlank()) "1.gif" else uiState.selectedPosterCode
            val foundIdx = uiState.availablePosters.indexOfFirst { it.code.equals(activeCode, ignoreCase = true) }
            val currentIndex = if (foundIdx >= 0) foundIdx + 1 else 1
            val totalCount = uiState.availablePosters.size
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "<",
                        color = Primary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$currentIndex / $totalCount",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = ">",
                        color = Primary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // --- BACKGROUND SYNC NOTIFICATION ---
        AnimatedVisibility(
            visible = uiState.SYNC_PROGRESS.isNotEmpty() && (uiState.channels.isNotEmpty() || !uiState.isLoading),
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.Black.copy(alpha = 0.85f))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (uiState.isSyncActive) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = Primary
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = uiState.SYNC_PROGRESS,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        // TV Channel Number Overlay (Top Right)
        if (uiState.currentType == Prefs.TYPE_TV && uiState.isInfoVisible && !uiState.isMenuVisible && !uiState.isSettingsVisible) {
            val channelIndex = remember(uiState.CURRENT_CHANNEL, uiState.channels) {
                uiState.channels.indexOfFirst { it.id == uiState.CURRENT_CHANNEL?.id } + 1
            }
            if (channelIndex > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 40.dp, end = 40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.6f))
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = channelIndex.toString(),
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // --- DYNAMIC OVERLAY (TV auto-hides, FM stays) ---
        val showOverlay = remember(uiState.isInfoVisible, uiState.currentType, uiState.isMenuVisible, uiState.isSettingsVisible, uiState.isLyricsVisible) {
            (uiState.isInfoVisible || uiState.currentType == Prefs.TYPE_FM) && !uiState.isMenuVisible && !uiState.isSettingsVisible && !uiState.isLyricsVisible
        }
        AnimatedVisibility(
            visible = showOverlay,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            if (uiState.currentType == Prefs.TYPE_FM) {
                RadioInfoOverlay(channel = uiState.CURRENT_CHANNEL, state = uiState)
            } else {
                TvInfoOverlay(channel = uiState.CURRENT_CHANNEL, programInfo = uiState.programInfo, selectedStreamIndex = uiState.selectedStreamIndex)
            }
        }
        // Zap Number Overlay (TV Style)
        if (uiState.zapNumber.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 40.dp, end = 40.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0C1017).copy(alpha = 0.92f))
                    .border(1.5.dp, Primary, RoundedCornerShape(16.dp))
                    .padding(horizontal = 24.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Kanal",
                        style = MaterialTheme.typography.labelMedium,
                        color = Primary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = uiState.zapNumber,
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 36.sp,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
        
        // --- NON-INTRUSIVE UPDATE TOAST WITH COUNTDOWN PROGRESS BAR ---
        AnimatedVisibility(
            visible = uiState.isUpdateToastVisible && uiState.updateAvailable && !uiState.isUpdating,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 32.dp, end = 32.dp)
        ) {
            UpdateToast(
                version = uiState.updateVersion,
                onDismiss = { viewModel.hideUpdateToast() },
                onClick = { viewModel.toggleUpdateDialog(true) }
            )
        }

        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (uiState.isBuffering && !uiState.isLoading) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Primary, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Yükleniyor...", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                }
            }
            uiState.playbackError?.let { error ->
                Surface(
                    colors = SurfaceDefaults.colors(containerColor = Color.Red.copy(alpha = 0.8f)),
                    modifier = Modifier.padding(16.dp).clip(RoundedCornerShape(8.dp))
                ) {
                    Text(error, color = Color.White, modifier = Modifier.padding(16.dp))
                }
            }
        }

        // Side Panel Overlay (Tek parça, bütünleşik cam tasarımı)
        AnimatedVisibility(
            visible = !uiState.isSettingsVisible && uiState.isMenuVisible,
            enter = slideInHorizontally() + fadeIn(),
            exit = slideOutHorizontally() + fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .width(520.dp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp))
                    .background(Color(0xFF0C1017).copy(alpha = 0.88f))
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp)
                    )
            ) {
                SideMenu(
                    selectedType = uiState.currentType,
                    onTypeAndModeSelect = { type, mode -> viewModel.setTypeAndMode(type, mode) },
                    onSearchClick = { viewModel.toggleSearch() },
                    onSettingsClick = { viewModel.toggleSettings() },
                    onInteraction = { viewModel.onInteraction() }
                )
                // İnce Dikey Ayırıcı Çizgi
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                        .padding(vertical = 24.dp)
                        .background(Color.White.copy(alpha = 0.08f))
                )
                Column(
                    modifier = Modifier.weight(1f).fillMaxHeight().padding(horizontal = 8.dp)
                ) {
                    AnimatedVisibility(visible = uiState.isSearchVisible) {
                        SearchBar(
                            onSearch = { viewModel.search(it) },
                            onClose = { viewModel.toggleSearch() }
                        )
                    }
                    TopTabRow(
                        currentMode = uiState.listMode,
                        onModeChange = { viewModel.setListMode(it) },
                        onInteraction = { viewModel.onInteraction() }
                    )
                    StatusLine(uiState = uiState)
                    Box(modifier = Modifier.weight(1f)) {
                        ChannelList(
                            channels = uiState.channels,
                            totalCount = uiState.TOTAL_COUNT,
                            currentChannel = uiState.CURRENT_CHANNEL,
                            nowPlayingMetadata = uiState.nowPlayingMetadata,
                            onChannelClick = { viewModel.selectChannel(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onMoveChannel = { channel, dir -> viewModel.moveChannel(channel, dir) },
                            isEditMode = uiState.isEditMode,
                            onLoadMore = { viewModel.loadMore() },
                            onInteraction = { viewModel.onInteraction() },
                            listState = listState,
                            focusRequester = channelListFocusRequester,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }

        if (uiState.isFilterDialogVisible) {
            FilterDialog(
                uiState = uiState,
                onCountrySelect = { viewModel.setFilters(it, uiState.selectedCategory) },
                onCategorySelect = { viewModel.setFilters(uiState.selectedCountry, it) },
                onSortSelect = { viewModel.setSortMode(it) },
                onEditModeToggle = { viewModel.toggleEditMode() },
                onDismiss = { viewModel.toggleFilterDialog() },
                onInteraction = { viewModel.onInteraction() }
            )
        }

        if (uiState.isTrackSelectorVisible) {
            TrackSelectorDialog(
                streams = uiState.CURRENT_CHANNEL?.streams ?: emptyList(),
                selectedStreamIndex = uiState.selectedStreamIndex,
                onSelectStream = { viewModel.selectStream(it) },
                audioTracks = uiState.audioTracks,
                subtitleTracks = uiState.subtitleTracks,
                selectedAudioIndex = uiState.selectedAudioIndex,
                selectedSubtitleIndex = uiState.selectedSubtitleIndex,
                isRadio = uiState.currentType == Prefs.TYPE_FM,
                onSelectAudio = { viewModel.selectAudioTrack(it) },
                onSelectSubtitle = { viewModel.selectSubtitleTrack(it) },
                onToggleLyrics = { viewModel.toggleLyrics() },
                onDismiss = { viewModel.toggleTrackSelector() },
                onInteraction = { viewModel.onInteraction() }
            )
        }


        UpdateDialog(
            state = uiState,
            onConfirmUpdate = { viewModel.downloadAndInstallUpdate() },
            onDismiss = { viewModel.toggleUpdateDialog(false) }
        )

        if (uiState.isSettingsVisible) {
            SettingsScreen(
                state = uiState,
                settingsManager = viewModel.settingsManager,
                onUpdateSetting = { viewModel.updateSetting(it) },
                onClearRecents = { viewModel.clearRecents() },
                onCheckUpdate = {
                    if (uiState.updateAvailable) {
                        viewModel.toggleUpdateDialog(true)
                    } else {
                        viewModel.checkUpdate(forceCheck = true)
                    }
                },
                onRefreshDatabase = { viewModel.forceRefresh() },
                onSyncBackups = { viewModel.syncBackupsNow() },
                onDismiss = { viewModel.toggleSettings() }
            )
        }

        if (uiState.isLyricsVisible) {
            val rawMetadata = uiState.nowPlayingMetadata?.takeIf { it.isNotBlank() }
            val (artist, track) = remember(rawMetadata, uiState.CURRENT_CHANNEL?.name) {
                if (rawMetadata != null && rawMetadata.contains(" - ")) {
                    val parts = rawMetadata.split(" - ")
                    val a = parts[0].trim()
                    val t = parts.drop(1).joinToString(" - ").trim()
                    a to t
                } else {
                    val channelName = uiState.CURRENT_CHANNEL?.name ?: "Radyo"
                    val songTitle = rawMetadata ?: "Canlı Yayın"
                    channelName to songTitle
                }
            }
            LyricsOverlay(
                lines = uiState.lyricsResult?.lines ?: emptyList(),
                currentIndex = uiState.lyricsCurrentIndex,
                artist = artist,
                track = track,
                channel = uiState.CURRENT_CHANNEL,
                nowPlayingArtwork = uiState.nowPlayingArtwork,
                onClose = { viewModel.toggleLyrics() }
            )
        }
    }
}

@Composable
fun TvInfoOverlay(
    channel: Channel?,
    programInfo: String?,
    selectedStreamIndex: Int = 0
) {
    if (channel == null) return
    Box(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .padding(bottom = 32.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.Black.copy(alpha = 0.35f), // Üst kısım: Daha transparan
                        Color.Black.copy(alpha = 0.85f)  // Alt kısım: Daha koyu/opak
                    )
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(70.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.1f))
                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                ChannelLogo(
                    channel = channel,
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    iconSize = 36.dp
                )
            }
            Spacer(modifier = Modifier.width(20.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = channel.name,
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    val streams = channel.streams
                    if (streams.size > 1) {
                        Spacer(modifier = Modifier.width(12.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            streams.indices.forEach { index ->
                                val isActive = (index == selectedStreamIndex)
                                Icon(
                                    imageVector = Icons.Default.Tv,
                                    contentDescription = "Yayın ${index + 1}",
                                    modifier = Modifier.size(20.dp),
                                    tint = if (isActive) Color(0xFF4CAF50) else Color.White.copy(alpha = 0.35f)
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = programInfo ?: "Canlı Yayın",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.6f),
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun RadioInfoOverlay(
    channel: Channel?,
    state: MainUiState,
    modifier: Modifier = Modifier
) {
    if (channel == null) return
    Box(
        modifier = modifier
            .fillMaxWidth(0.8f)
            .padding(bottom = 32.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.Black.copy(alpha = 0.35f),
                        Color.Black.copy(alpha = 0.85f)
                    )
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Radyo / Şarkı Görseli
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.05f))
                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                ChannelLogo(
                    channel = channel,
                    nowPlayingArtwork = state.nowPlayingArtwork,
                    modifier = Modifier.fillMaxSize().padding(6.dp),
                    iconSize = 32.dp
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            // Kanal ve Çalan Şarkı Bilgisi
            Column(modifier = Modifier.weight(1f)) {
                val hasMetadata = !state.nowPlayingMetadata.isNullOrBlank() && !state.nowPlayingMetadata.equals(channel.name, ignoreCase = true)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Text(
                            text = channel.name,
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val streams = channel.streams
                        if (streams.size > 1) {
                            Spacer(modifier = Modifier.width(10.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                streams.indices.forEach { index ->
                                    val isActive = (index == state.selectedStreamIndex)
                                    Icon(
                                        imageVector = Icons.Default.Tv,
                                        contentDescription = "Yayın ${index + 1}",
                                        modifier = Modifier.size(18.dp),
                                        tint = if (isActive) Color(0xFF4CAF50) else Color.White.copy(alpha = 0.35f)
                                    )
                                }
                            }
                        }
                    }
                    if (hasMetadata) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Primary.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Şarkı Sözü",
                                tint = Primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Sözler",
                                color = Primary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                val metadata = state.nowPlayingMetadata?.trim()
                val displayMetadata = if (hasMetadata) {
                    metadata!!
                } else {
                    "Canlı"
                }

                Text(
                    text = displayMetadata,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.65f),
                    maxLines = 1,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    modifier = Modifier.basicMarquee() // Uzun şarkı isimleri için kayan yazı
                )
            }
        }
    }
}




@Composable
fun FilterDialog(
    uiState: MainUiState,
    onCountrySelect: (String) -> Unit,
    onCategorySelect: (String) -> Unit,
    onSortSelect: (SortMode) -> Unit,
    onEditModeToggle: () -> Unit,
    onDismiss: () -> Unit,
    onInteraction: () -> Unit
) {
    val firstFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(120.milliseconds)
        try {
            firstFocusRequester.requestFocus()
        } catch (_: Exception) {}
    }

    Dialog(onDismissRequest = onDismiss) {
        BackHandler { onDismiss() }
        Surface(
            onClick = {},
            colors = ClickableSurfaceDefaults.colors(containerColor = Color(0xFF161B22)),
            modifier = Modifier
                .width(480.dp)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
        ) {
            Column(modifier = Modifier.padding(28.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Kanal Filtreleri",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White.copy(alpha = 0.1f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Kapat",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                FilterDialogItem(
                    label = "Ülke Filtresi",
                    value = uiState.selectedCountry.ifEmpty { "Tümü" },
                    options = listOf("") + uiState.countryOptions,
                    onSelect = { onCountrySelect(it) },
                    onInteraction = onInteraction,
                    modifier = Modifier.focusRequester(firstFocusRequester)
                )

                Spacer(modifier = Modifier.height(16.dp))

                FilterDialogItem(
                    label = "Kategori Filtresi",
                    value = uiState.selectedCategory.ifEmpty { "Tüm kategoriler" },
                    options = listOf("") + uiState.categoryOptions,
                    onSelect = { onCategorySelect(it) },
                    onInteraction = onInteraction
                )

                Spacer(modifier = Modifier.height(16.dp))

                FilterDialogItem(
                    label = "Sıralama",
                    value = when(uiState.sortMode) {
                        SortMode.DEFAULT -> "Varsayılan Sıralama"
                        SortMode.NAME_ASC -> "Ada Göre (A-Z)"
                        SortMode.NAME_DESC -> "Ada Göre (Z-A)"
                        SortMode.COUNTRY_ASC -> "Ülkeye Göre"
                        SortMode.CATEGORY_ASC -> "Türe / Kategoriye Göre"
                        SortMode.POPULAR -> "Popülerliğe Göre"
                        SortMode.NEWEST -> "En Yeni"
                    },
                    options = listOf("DEFAULT", "NAME_ASC", "NAME_DESC", "COUNTRY_ASC", "CATEGORY_ASC", "POPULAR", "NEWEST"),
                    onSelect = {
                        onSortSelect(SortMode.valueOf(it))
                    },
                    onInteraction = onInteraction
                )

                Spacer(modifier = Modifier.height(28.dp))

                Button(
                    onClick = { onDismiss(); onEditModeToggle() },
                    colors = ButtonDefaults.colors(containerColor = Primary.copy(alpha = 0.2f), contentColor = Primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                ) {
                    Text(if (uiState.isEditMode) "Düzenlemeyi Bitir" else "Özel Sıra Düzenle", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Primary)
                }
            }
        }
    }
}

@Composable
fun FilterDialogItem(
    label: String,
    value: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    onInteraction: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showOptions by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    val displayValue = remember(value) {
        if (label.contains("Ülke") && value.length == 2) {
            Locale.Builder().setRegion(value).build().displayCountry
        } else if (value.isEmpty() || value == "Tümü" || value == "Tüm kategoriler") {
            if (label.contains("Kategori")) "Tüm kategoriler" else "Tümü"
        } else value
    }

    Surface(
        onClick = { onInteraction(); showOptions = true },
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color.White.copy(alpha = 0.05f),
            contentColor = Color.White,
            focusedContainerColor = Primary,
            focusedContentColor = Color.Black
        ),
        interactionSource = interactionSource,
        modifier = modifier
            .fillMaxWidth()
            .height(68.dp)
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.Center) {
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Primary, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(displayValue, style = MaterialTheme.typography.bodyMedium, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 15.sp)
        }
    }

    if (showOptions) {
        val optionsFocusRequester = remember { FocusRequester() }

        LaunchedEffect(Unit) {
            delay(120.milliseconds)
            try {
                optionsFocusRequester.requestFocus()
            } catch (_: Exception) {}
        }

        Dialog(onDismissRequest = { showOptions = false }) {
            Surface(
                onClick = {},
                colors = ClickableSurfaceDefaults.colors(containerColor = Color(0xFF161B22)),
                modifier = Modifier
                    .width(460.dp)
                    .fillMaxHeight(0.75f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
            ) {
                Column(modifier = Modifier.padding(28.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$label Seçin",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        IconButton(
                            onClick = { showOptions = false },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = 0.1f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Kapat",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(options.size) { index ->
                            val option = options[index]
                            val isSelected = if (option.isEmpty()) value == "" || value == "Tümü" || value == "Tüm kategoriler" else value == option
                            val itemInteractionSource = remember { MutableInteractionSource() }
                            
                            val displayOption = remember(option) {
                                if (label.contains("Ülke") && option.length == 2) {
                                    Locale.Builder().setRegion(option).build().displayCountry
                                } else if (option.isEmpty()) {
                                    if (label.contains("Kategori")) "Tüm kategoriler" else "Tümü"
                                } else when(option) {
                                    "DEFAULT" -> "Varsayılan Sıralama"
                                    "NAME_ASC" -> "Ada Göre (A-Z)"
                                    "NAME_DESC" -> "Ada Göre (Z-A)"
                                    "COUNTRY_ASC" -> "Ülkeye Göre"
                                    "CATEGORY_ASC" -> "Türe / Kategoriye Göre"
                                    "POPULAR" -> "Popülerliğe Göre"
                                    "NEWEST" -> "En Yeni"
                                    else -> option
                                }
                            }

                            val itemModifier = if (index == 0) Modifier.focusRequester(optionsFocusRequester) else Modifier

                            Surface(
                                onClick = { onSelect(option); showOptions = false },
                                interactionSource = itemInteractionSource,
                                colors = ClickableSurfaceDefaults.colors(
                                    containerColor = if (isSelected) Primary.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.04f),
                                    contentColor = if (isSelected) Primary else Color.White,
                                    focusedContainerColor = Primary,
                                    focusedContentColor = Color.Black
                                ),
                                modifier = itemModifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Text(
                                        text = displayOption,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        color = if (isSelected) Primary else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrackOptionItem(
    label: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onInteraction: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val isPressed by interactionSource.collectIsPressedAsState()
    val containerColor = when {
        isFocused -> Primary
        isPressed -> Color(0xFF282C38)
        isSelected -> Primary.copy(alpha = 0.22f)
        else -> Color.White.copy(alpha = 0.06f)
    }
    val textColor = when {
        isFocused -> Color.Black
        else -> Color.White
    }
    val iconColor = when {
        isFocused -> Color.Black
        else -> Primary
    }
    val borderModifier = when {
        isFocused -> Modifier.border(2.5.dp, Color.White, RoundedCornerShape(12.dp))
        isSelected -> Modifier.border(1.5.dp, Primary, RoundedCornerShape(12.dp))
        else -> Modifier.border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp))
    }
    Surface(
        onClick = onClick,
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.02f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = containerColor,
            contentColor = textColor,
            focusedContainerColor = Primary,
            focusedContentColor = Color.Black
        ),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(12.dp)),
        interactionSource = interactionSource,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .then(borderModifier)
            .dualControl(
                onClick = onClick,
                onFocus = onInteraction,
                interactionSource = interactionSource
            )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Medium,
                fontSize = 15.sp,
                color = textColor
            )
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Seçili",
                    tint = iconColor,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun StreamDropdownSelector(
    streams: List<StreamInfo>,
    selectedIndex: Int,
    onSelectStream: ((Int) -> Unit)?,
    modifier: Modifier = Modifier,
    onInteraction: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    val selectedStream = streams.getOrNull(selectedIndex)
    val selectedLabel = remember(selectedStream, selectedIndex) {
        if (selectedStream == null) "Yayın Seçin"
        else buildString {
            if (selectedIndex == 0) {
                append("Varsayılan")
            } else {
                append("YAYIN ${selectedIndex + 1} (SV-$selectedIndex)")
            }
            if (selectedStream.label.isNotBlank() && !selectedStream.label.equals("Yedek", ignoreCase = true)) {
                append(" • ${selectedStream.label}")
            }
            if (selectedStream.quality.isNotBlank()) {
                append(" • ${selectedStream.quality}")
            }
        }
    }
    Column(modifier = Modifier.fillMaxWidth()) {
        val interactionSource = remember { MutableInteractionSource() }
        val isFocused by interactionSource.collectIsFocusedAsState()
        Surface(
            onClick = { isExpanded = !isExpanded },
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.02f),
            colors = ClickableSurfaceDefaults.colors(
                containerColor = if (isFocused) Primary else Color.White.copy(alpha = 0.08f),
                contentColor = if (isFocused) Color.Black else Color.White,
                focusedContainerColor = Primary,
                focusedContentColor = Color.Black
            ),
            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(12.dp)),
            interactionSource = interactionSource,
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .border(
                    width = if (isFocused) 2.5.dp else 1.dp,
                    color = if (isFocused) Color.White else Color.White.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp)
                )
                .dualControl(
                    onClick = { isExpanded = !isExpanded },
                    onFocus = onInteraction,
                    interactionSource = interactionSource
                )
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = selectedLabel,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = if (isFocused) Color.Black else Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = "Yayın Seçin",
                    tint = if (isFocused) Color.Black else Primary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        AnimatedVisibility(
            visible = isExpanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .padding(top = 6.dp)
                    .fillMaxWidth()
                    .background(Color(0xFF1E2430), RoundedCornerShape(12.dp))
                    .border(1.dp, Primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .padding(6.dp)
            ) {
                streams.forEachIndexed { index, stream ->
                    val itemLabel = buildString {
                        if (index == 0) {
                            append("Varsayılan")
                        } else {
                            append("YAYIN ${index + 1} (SV-$index)")
                        }
                        if (stream.label.isNotBlank() && !stream.label.equals("Yedek", ignoreCase = true)) {
                            append(" • ${stream.label}")
                        }
                        if (stream.quality.isNotBlank()) {
                            append(" • ${stream.quality}")
                        }
                    }

                    TrackOptionItem(
                        label = itemLabel,
                        isSelected = index == selectedIndex,
                        onClick = {
                            onSelectStream?.invoke(index)
                            isExpanded = false
                        },
                        onInteraction = onInteraction
                    )
                }
            }
        }
    }
}

@Composable
fun TrackSelectorDialog(
    streams: List<StreamInfo> = emptyList(),
    selectedStreamIndex: Int = 0,
    onSelectStream: ((Int) -> Unit)? = null,
    audioTracks: List<String>,
    subtitleTracks: List<String>,
    selectedAudioIndex: Int = 0,
    selectedSubtitleIndex: Int = -1,
    isRadio: Boolean = false,
    onSelectAudio: (Int) -> Unit,
    onSelectSubtitle: (Int) -> Unit,
    onToggleLyrics: (() -> Unit)? = null,
    onDismiss: () -> Unit,
    onInteraction: () -> Unit
) {
    val firstFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(120.milliseconds)
        try {
            firstFocusRequester.requestFocus()
        } catch (_: Exception) {}
    }

    Dialog(onDismissRequest = onDismiss) {
        BackHandler { onDismiss() }
        Box(
            modifier = Modifier
                .width(460.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF161B22))
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .heightIn(max = 560.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header (Title & Close Button)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Oynatıcı Seçenekleri",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )

                    val closeInteractionSource = remember { MutableInteractionSource() }
                    val isCloseFocused by closeInteractionSource.collectIsFocusedAsState()
                    Surface(
                        onClick = onDismiss,
                        colors = ClickableSurfaceDefaults.colors(
                            containerColor = if (isCloseFocused) Primary else Color.White.copy(alpha = 0.1f),
                            contentColor = if (isCloseFocused) Color.Black else Color.White,
                            focusedContainerColor = Primary,
                            focusedContentColor = Color.Black
                        ),
                        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(10.dp)),
                        interactionSource = closeInteractionSource,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .then(if (isCloseFocused) Modifier.border(2.dp, Color.White, RoundedCornerShape(10.dp)) else Modifier)
                            .dualControl(
                                onClick = onDismiss,
                                onFocus = onInteraction,
                                interactionSource = closeInteractionSource
                            )
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Kapat",
                                tint = if (isCloseFocused) Color.Black else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                var hasAssignedFirstFocus = false
                if (isRadio && onToggleLyrics != null) {
                    val focusMod = run {
                        hasAssignedFirstFocus = true
                        Modifier.focusRequester(firstFocusRequester)
                    }
                    TrackOptionItem(
                        label = "Şarkı Sözleri (Lyrics)",
                        isSelected = false,
                        modifier = focusMod,
                        onClick = { onToggleLyrics(); onDismiss() },
                        onInteraction = onInteraction
                    )
                    Spacer(Modifier.height(12.dp))
                }
                // --- 1. YAYIN KAYNAKLARI (YEDEKLER) ---
                if (streams.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Yayın Kaynağı / Alternatifler",
                            style = MaterialTheme.typography.labelLarge,
                            color = Primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        if (streams.size > 1) {
                            Text(
                                "${streams.size} Kaynak",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 12.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    val focusMod = if (!hasAssignedFirstFocus) {
                        hasAssignedFirstFocus = true
                        Modifier.focusRequester(firstFocusRequester)
                    } else Modifier

                    StreamDropdownSelector(
                        streams = streams,
                        selectedIndex = selectedStreamIndex,
                        onSelectStream = onSelectStream,
                        modifier = focusMod,
                        onInteraction = onInteraction
                    )
                    Spacer(Modifier.height(16.dp))
                }

                // --- 2. SES DİLİ ---
                if (audioTracks.isNotEmpty()) {
                    Text(
                        "Ses Dili",
                        style = MaterialTheme.typography.labelLarge,
                        color = Primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(8.dp))

                    audioTracks.forEachIndexed { index, track ->
                        val focusMod = if (!hasAssignedFirstFocus) {
                            hasAssignedFirstFocus = true
                            Modifier.focusRequester(firstFocusRequester)
                        } else Modifier

                        TrackOptionItem(
                            label = track.uppercase(),
                            isSelected = index == selectedAudioIndex,
                            modifier = focusMod,
                            onClick = { onSelectAudio(index) },
                            onInteraction = onInteraction
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }

                // --- 3. ALTYAZI ---
                Text(
                    "Altyazı",
                    style = MaterialTheme.typography.labelLarge,
                    color = Primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(8.dp))

                val subNoneFocusMod = if (!hasAssignedFirstFocus) {
                    hasAssignedFirstFocus = true
                    Modifier.focusRequester(firstFocusRequester)
                } else Modifier

                TrackOptionItem(
                    label = "KAPALI",
                    isSelected = selectedSubtitleIndex == -1,
                    modifier = subNoneFocusMod,
                    onClick = { onSelectSubtitle(-1) },
                    onInteraction = onInteraction
                )

                subtitleTracks.forEachIndexed { index, track ->
                    val focusMod = if (!hasAssignedFirstFocus) {
                        hasAssignedFirstFocus = true
                        Modifier.focusRequester(firstFocusRequester)
                    } else Modifier

                    TrackOptionItem(
                        label = track.uppercase(),
                        isSelected = index == selectedSubtitleIndex,
                        modifier = focusMod,
                        onClick = { onSelectSubtitle(index) },
                        onInteraction = onInteraction
                    )
                }
            }
        }
    }
}

@Composable
fun TopTabRow(
    currentMode: ListMode,
    onModeChange: (ListMode) -> Unit,
    onInteraction: () -> Unit
) {
    Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 16.dp).fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        val interactionSourceAll = remember { MutableInteractionSource() }
        TabItem(
            label = "Tüm", 
            isSelected = currentMode == ListMode.ALL, 
            onClick = { onModeChange(ListMode.ALL) }, 
            modifier = Modifier.weight(1f)
                .dualControl(onClick = { onModeChange(ListMode.ALL) }, 
                    onFocus = onInteraction, 
                    interactionSource = interactionSourceAll),
            interactionSource = interactionSourceAll
        )
        val interactionSourceFav = remember { MutableInteractionSource() }
        TabItem(label = "Favori", isSelected = currentMode == ListMode.FAVORITES, onClick = { onModeChange(ListMode.FAVORITES) }, modifier = Modifier.weight(1f).dualControl(onClick = { onModeChange(ListMode.FAVORITES) }, onFocus = onInteraction, interactionSource = interactionSourceFav), interactionSource = interactionSourceFav)
        
        val interactionSourceFil = remember { MutableInteractionSource() }
        TabItem(label = "Filtre", isSelected = false, onClick = { onModeChange(ListMode.FILTER) }, modifier = Modifier.weight(1f).dualControl(onClick = { onModeChange(ListMode.FILTER) }, onFocus = onInteraction, interactionSource = interactionSourceFil), interactionSource = interactionSourceFil)
    }
}

@Composable
fun TabItem(label: String, isSelected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, interactionSource: MutableInteractionSource = remember { MutableInteractionSource() }) {
    Surface(
        onClick = onClick,
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.1f),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (isSelected) Primary.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.18f),
            focusedContainerColor = Primary,
            contentColor = if (isSelected) Primary else Color.White,
            focusedContentColor = Color.Black
        ),
        interactionSource = interactionSource,
        modifier = modifier
            .height(40.dp)
            .clip(RoundedCornerShape(10.dp))
            .then(if(isSelected) Modifier.border(1.2.dp, Primary, RoundedCornerShape(10.dp)) else Modifier)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Text(
                text = label, 
                style = MaterialTheme.typography.labelLarge, 
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                color = if (isSelected) Primary else Color.White
            )
        }
    }
}

@Composable
fun StatusLine(uiState: MainUiState) {
    val countryText = remember(uiState.selectedCountry) {
        if (uiState.selectedCountry.length == 2) {
            Locale.Builder().setRegion(uiState.selectedCountry).build().displayCountry
        } else {
            uiState.selectedCountry.ifEmpty { "Tüm Dünya" }
        }
    }
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // SOL TARAFA DAYALI: Medya tipleri ve sayaçları
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TV  ${uiState.TV_COUNT}",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.9f),
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "•",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.3f)
            )
            Text(
                text = "FM  ${uiState.RADIO_COUNT}",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.9f),
                fontWeight = FontWeight.SemiBold
            )
        }
        // SAĞA DAYALI: Toplam kanal sayısı ve Bölge/Ülke
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${uiState.TOTAL_COUNT} kanal",
                style = MaterialTheme.typography.labelMedium,
                color = Primary,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "|",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.3f)
            )
            Text(
                text = countryText,
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.7f),
                fontWeight = FontWeight.Normal
            )
        }
    }
}

@Composable
fun SearchBar(
    onSearch: (String) -> Unit,
    onClose: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150.milliseconds)
        focusRequester.requestFocus()
        keyboardController?.show()
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
            .clickable {
                focusRequester.requestFocus()
                keyboardController?.show()
            }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search, 
                contentDescription = null, 
                tint = Primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            BasicTextField(
                value = query,
                onValueChange = { query = it;onSearch(it) },
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Primary),
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester)
                    .onFocusChanged { state ->
                        if (state.isFocused) {
                            keyboardController?.show()
                        }
                    },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { 
                    focusManager.clearFocus()
                    keyboardController?.hide()
                }),
                decorationBox = { innerTextField ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Text("Kanal ara...", color = Color.White.copy(alpha = 0.35f), fontSize = 16.sp)
                        }
                        innerTextField()
                    }
                }
            )
            if (query.isNotEmpty()) {
                IconButton(onClick = { query = ""; onSearch("") }) {
                    Icon(
                        imageVector = Icons.Default.Close, 
                        contentDescription = "Temizle",
                        tint = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            } else {
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.Close, 
                        contentDescription = "Kapat",
                        tint = Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun UpdateToast(
    version: String,
    onDismiss: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 0f,
            animationSpec = tween(
                durationMillis = 8000,
                easing = LinearEasing
            )
        )
        onDismiss()
    }
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    Surface(
        onClick = {
            onClick()
            onDismiss()
        },
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Color(0xFF161821).copy(alpha = 0.95f),
            focusedContainerColor = Color(0xFF1F2230),
            contentColor = Color.White,
            focusedContentColor = Color.White
        ),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(14.dp)),
        interactionSource = interactionSource,
        modifier = modifier
            .width(380.dp)
            .clip(RoundedCornerShape(14.dp))
            .border(
                if (isFocused) 2.dp else 1.dp,
                if (isFocused) Color.White else Primary.copy(alpha = 0.5f),
                RoundedCornerShape(14.dp)
            )
            .dualControl(
                onClick = {
                    onClick()
                    onDismiss()
                },
                interactionSource = interactionSource
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Primary.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SystemUpdate,
                        contentDescription = null,
                        tint = Primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Yeni Güncelleme Mevcut (v$version)",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Yüklemek için tıklayın veya Ayarlar'a gidin",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.65f),
                        fontSize = 11.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { progress.value },
                modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                color = Primary,
                trackColor = Color.White.copy(alpha = 0.12f)
            )
        }
    }
}
