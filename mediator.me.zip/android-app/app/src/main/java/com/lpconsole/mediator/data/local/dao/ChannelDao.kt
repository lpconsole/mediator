package com.lpconsole.mediator.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.lpconsole.mediator.data.local.entities.ChannelEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChannelDao {
    @Query("""
        SELECT * FROM channels 
        WHERE type = :type 
        AND (:country = '' OR country = :country)
        AND (:category = '' OR category = :category)
        ORDER BY isFavorite DESC, userOrder ASC, sortWeight DESC, name ASC
    """)
    fun getChannelsByType(type: String, country: String, category: String): Flow<List<ChannelEntity>>

    @Query("""
        SELECT * FROM channels 
        WHERE type = :type 
        AND (:country = '' OR country = :country)
        AND (:category = '' OR category = :category)
        ORDER BY 
            CASE WHEN :sortMode = 'NAME_ASC' THEN name END ASC,
            CASE WHEN :sortMode = 'NAME_DESC' THEN name END DESC,
            CASE WHEN :sortMode = 'COUNTRY_ASC' THEN country END ASC,
            CASE WHEN :sortMode = 'CATEGORY_ASC' THEN category END ASC,
            CASE WHEN :sortMode = 'POPULAR' THEN sortWeight END DESC,
            CASE WHEN :sortMode = 'NEWEST' THEN launched END DESC,
            isFavorite DESC, userOrder ASC, rowid ASC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getChannelsByTypePagedSorted(
        type: String, country: String, category: String, 
        sortMode: String, limit: Int, offset: Int
    ): List<ChannelEntity>

    @Query("""
        SELECT COUNT(*) FROM channels 
        WHERE type = :type 
        AND (:country = '' OR country = :country)
        AND (:category = '' OR category = :category)
    """)
    suspend fun getCountByType(type: String, country: String, category: String): Int

    @Query("SELECT DISTINCT country FROM channels WHERE type = :type AND country != '' ORDER BY country ASC")
    suspend fun getCountries(type: String): List<String>

    @Query("SELECT DISTINCT category FROM channels WHERE type = :type AND category != '' ORDER BY category ASC")
    suspend fun getCategories(type: String): List<String>

    @Query("SELECT * FROM channels WHERE type = :type AND isFavorite = 1 ORDER BY userOrder ASC, rowid ASC")
    suspend fun getFavorites(type: String): List<ChannelEntity>

    @Query("""
        SELECT * FROM channels 
        WHERE type = :type AND isFavorite = 1
        AND (:country = '' OR country = :country)
        AND (:category = '' OR category = :category)
        ORDER BY 
            CASE WHEN :sortMode = 'NAME_ASC' THEN name END ASC,
            CASE WHEN :sortMode = 'NAME_DESC' THEN name END DESC,
            CASE WHEN :sortMode = 'COUNTRY_ASC' THEN country END ASC,
            CASE WHEN :sortMode = 'CATEGORY_ASC' THEN category END ASC,
            CASE WHEN :sortMode = 'POPULAR' THEN sortWeight END DESC,
            CASE WHEN :sortMode = 'NEWEST' THEN launched END DESC,
            userOrder ASC, rowid ASC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getFavoritesPagedSorted(
        type: String, country: String, category: String, 
        sortMode: String, limit: Int, offset: Int
    ): List<ChannelEntity>

    @Query("SELECT COUNT(*) FROM channels WHERE type = :type AND isFavorite = 1")
    suspend fun getFavoritesCount(type: String): Int

    @Query("SELECT * FROM channels WHERE type = :type AND lastViewedAt > 0 ORDER BY lastViewedAt DESC LIMIT 20")
    suspend fun getRecentChannels(type: String): List<ChannelEntity>

    @Query("UPDATE channels SET lastViewedAt = :timestamp WHERE id = :id")
    suspend fun updateLastViewed(id: String, timestamp: Long)

    @Query("UPDATE channels SET lastViewedAt = 0")
    suspend fun clearRecentChannels()

    @Query("SELECT * FROM channels WHERE id = :id")
    suspend fun getChannelById(id: String): ChannelEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertChannelsIgnore(channels: List<ChannelEntity>): List<Long>

    @Query("UPDATE channels SET name = :name, country = :country, website = :website, logo = :logo, network = :network, owner = :owner, launched = :launched, nsfw = :nsfw, sortWeight = :sortWeight, category = :category, streamUrl = :streamUrl, quality = :quality, streamsJson = :streamsJson WHERE id = :id")
    suspend fun updateChannelMetadata(
        id: String, name: String, country: String, website: String, logo: String,
        network: String, owner: String, launched: String, nsfw: Boolean,
        sortWeight: Int, category: String, streamUrl: String, quality: String,
        streamsJson: String
    )

    @Query("UPDATE channels SET streamsJson = :streamsJson, streamUrl = :streamUrl, quality = :quality WHERE id = :id")
    suspend fun updateChannelStreams(id: String, streamsJson: String, streamUrl: String, quality: String)

    @Query("SELECT * FROM channels WHERE type = :type AND LOWER(TRIM(name)) = LOWER(TRIM(:name)) LIMIT 1")
    suspend fun findChannelByNameAndType(name: String, type: String): ChannelEntity?

    @Transaction
    suspend fun upsertPreservingUserData(newEntities: List<ChannelEntity>) {
        val insertResults = insertChannelsIgnore(newEntities)
        newEntities.forEachIndexed { index, entity ->
            if (insertResults[index] == -1L) {
                updateChannelMetadata(
                    entity.id, entity.name, entity.country, entity.website, entity.logo,
                    entity.network, entity.owner, entity.launched, entity.nsfw,
                    entity.sortWeight, entity.category, entity.streamUrl, entity.quality,
                    entity.streamsJson
                )
            }
        }
    }

    @Query("""
        SELECT channels.* FROM channels 
        JOIN channels_fts ON channels.rowid = channels_fts.rowid 
        WHERE channels_fts MATCH :query AND channels.type = :type
        ORDER BY isFavorite DESC, userOrder ASC, sortWeight DESC, name ASC
    """)
    suspend fun searchByType(query: String, type: String): List<ChannelEntity>

    @Query("""
        SELECT channels.* FROM channels 
        JOIN channels_fts ON channels.rowid = channels_fts.rowid 
        WHERE channels_fts MATCH :query
    """)
    suspend fun searchGlobal(query: String): List<ChannelEntity>

    @Query("UPDATE channels SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: String, isFavorite: Boolean)

    @Query("UPDATE channels SET userOrder = :order WHERE id = :id")
    suspend fun setUserOrder(id: String, order: Int)

    @Query("DELETE FROM channels WHERE type = :type")
    suspend fun deleteChannelsByType(type: String)

    @Query("SELECT COUNT(*) FROM channels")
    suspend fun getCount(): Int
}
