package com.lpconsole.mediator.util

import java.util.Locale

object GetAllCountry {
    enum class Type {
        ISO_2,      // "TR", "US", "DE"
        ISO_3,      // "TUR", "USA", "DEU"
        NAME,       // "Türkiye", "Almanya" (Cihaz dili)
        ENGLISH     // "Turkey", "Germany"
    }
    // İhtiyaç duyulduğunda bir kez hesaplanıp bellekte tutulan listeler (Lazy Cache)
    val iso2List: List<String> by lazy { load(Type.ISO_2) }
    val iso3List: List<String> by lazy { load(Type.ISO_3) }
    val localizedNames: List<String> by lazy { load(Type.NAME) }
    val englishNames: List<String> by lazy { load(Type.ENGLISH) }
    // Genel erişim fonksiyonu
    fun get(type: Type): List<String> = when (type) {
        Type.ISO_2 -> iso2List
        Type.ISO_3 -> iso3List
        Type.NAME -> localizedNames
        Type.ENGLISH -> englishNames
    }
    // Doğrudan sınıfı fonksiyon gibi çağırmak için: CountryProvider(Type.ISO_2)
    operator fun invoke(type: Type): List<String> = get(type)
    private fun load(type: Type): List<String> {
        return Locale.getISOCountries().mapNotNull { code ->
            val locale = Locale("", code)
            runCatching {
                when (type) {
                    Type.ISO_2 -> code
                    Type.ISO_3 -> locale.isO3Country
                    Type.NAME -> locale.displayCountry.takeIf { it.isNotBlank() }
                    Type.ENGLISH -> locale.getDisplayCountry(Locale.ENGLISH).takeIf { it.isNotBlank() }
                }
            }.getOrNull()
        }.distinct().sorted()
    }
}