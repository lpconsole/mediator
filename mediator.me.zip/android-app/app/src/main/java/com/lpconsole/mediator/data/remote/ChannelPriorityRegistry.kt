package com.lpconsole.mediator.data.remote

import java.util.Locale

object ChannelPriorityRegistry {

    private val turkishPriorityMap = listOf(
        // Major Turkish National Networks (Highest Priority)
        Regex(".*trt\\s*1.*") to 10000,
        Regex(".*atv.*") to 9900,
        Regex(".*kanal\\s*d.*") to 9800,
        Regex(".*show\\s*tv.*") to 9700,
        Regex(".*star\\s*tv.*") to 9600,
        Regex(".*now\\s*tv.*|.*fox\\s*tv.*|.*\\bfox\\b.*|.*\\bnow\\b.*") to 9500,
        Regex(".*tv\\s*8\\.5.*|.*tv\\s*8,5.*") to 9450,
        Regex(".*tv\\s*8.*") to 9400,
        Regex(".*haberturk.*|.*haber\\s*turk.*") to 9300,
        Regex(".*ntv.*") to 9200,
        Regex(".*cnn\\s*turk.*|.*cnn\\s*türk.*") to 9100,
        Regex(".*trt\\s*haber.*") to 9000,
        Regex(".*a\\s*haber.*") to 8900,
        Regex(".*trt\\s*spor\\s*yildiz.*|.*trt\\s*spor\\s*yıldız.*") to 8850,
        Regex(".*trt\\s*spor.*") to 8800,
        Regex(".*a\\s*spor.*") to 8700,
        Regex(".*halk\\s*tv.*") to 8600,
        Regex(".*szc\\s*tv.*|.*sozcu\\s*tv.*|.*sözcü\\s*tv.*|.*\\bszc\\b.*") to 8500,
        Regex(".*tele\\s*1.*|.*tele1.*") to 8400,
        Regex(".*kanal\\s*7.*") to 8300,
        Regex(".*ulke\\s*tv.*|.*ülke\\s*tv.*") to 8200,
        Regex(".*24\\s*tv.*|.*yirmidort.*|.*yirmidört.*") to 8100,
        Regex(".*360.*") to 8000,
        Regex(".*tv100.*|.*tv\\s*100.*") to 7900,
        Regex(".*ekol\\s*tv.*") to 7800,
        Regex(".*flash\\s*haber.*|.*flash\\s*tv.*") to 7700,
        Regex(".*ege\\s*tv.*") to 7600,
        Regex(".*tgrt\\s*haber.*") to 7500,
        Regex(".*bloomberg\\s*ht.*") to 7400,
        Regex(".*a\\s*para.*") to 7300,
        Regex(".*a\\s*news.*") to 7200,
        Regex(".*trt\\s*belgesel.*") to 7100,
        Regex(".*trt\\s*cocuk.*|.*trt\\s*çocuk.*") to 7000,
        Regex(".*trt\\s*muzik.*|.*trt\\s*müzik.*") to 6900,
        Regex(".*trt\\s*avaz.*") to 6800,
        Regex(".*trt\\s*world.*") to 6700,
        Regex(".*trt\\s*kurdi.*|.*trt\\s*kürdi.*") to 6600,
        Regex(".*trt\\s*turk.*|.*trt\\s*türk.*") to 6500,
        Regex(".*trt\\s*3.*|.*trt\\s*tbmm.*") to 6400,
        Regex(".*trt\\s*2.*") to 6300,
        Regex(".*dmax.*") to 6200,
        Regex(".*tlc.*") to 6100,
        Regex(".*dream\\s*turk.*|.*dream\\s*türk.*") to 6000,
        Regex(".*number1.*|.*nr1.*") to 5900,
        Regex(".*kral\\s*pop.*|.*kral\\s*tv.*") to 5800,
        Regex(".*tv4.*|.*tv\\s*4.*") to 5700,
        Regex(".*akilli\\s*tv.*|.*akıllı\\s*tv.*") to 5600,
        Regex(".*sports\\s*tv.*") to 5500,
        Regex(".*bein\\s*sports\\s*haber.*") to 5400,
        Regex(".*tmb.*") to 5300
    )

    private val internationalPriorityMap = listOf(
        // Germany
        Regex(".*das\\s*erste.*|.*ard\\b.*") to 9000,
        Regex(".*zdf\\b.*") to 8900,
        Regex(".*rtl\\b.*") to 8800,
        Regex(".*sat\\.1.*") to 8700,
        Regex(".*prosieben.*") to 8600,
        // UK
        Regex(".*bbc\\s*one.*") to 9000,
        Regex(".*bbc\\s*two.*") to 8900,
        Regex(".*itv1?.*") to 8800,
        Regex(".*channel\\s*4.*") to 8700,
        Regex(".*sky\\s*news.*") to 8600,
        // USA
        Regex(".*nbc\\b.*") to 9000,
        Regex(".*cbs\\b.*") to 8900,
        Regex(".*abc\\b.*") to 8800,
        Regex(".*cnn\\b.*") to 8700,
        Regex(".*fox\\s*news.*") to 8600
    )

    fun getChannelWeight(country: String?, channelName: String?): Int {
        if (channelName.isNullOrBlank()) return 0
        val normalized = channelName.lowercase(Locale.ROOT)
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        val countryUpper = country?.uppercase(Locale.ROOT) ?: ""

        if (countryUpper == "TR" || countryUpper == "TURKEY" || countryUpper == "TURKIYE") {
            for ((regex, weight) in turkishPriorityMap) {
                if (regex.matches(normalized)) {
                    return weight
                }
            }
        }

        for ((regex, weight) in turkishPriorityMap) {
            if (regex.matches(normalized)) {
                return weight
            }
        }

        for ((regex, weight) in internationalPriorityMap) {
            if (regex.matches(normalized)) {
                return weight / 2
            }
        }

        return 0
    }
}
