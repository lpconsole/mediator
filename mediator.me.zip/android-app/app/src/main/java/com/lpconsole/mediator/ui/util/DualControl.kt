package com.lpconsole.mediator.ui.util

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type

/**
 * Hem kumanda (D-Pad focus/click) hem de dokunmatik ekran (Touch tap) kontrolünü
 * kusursuz yöneten yardımcı fonksiyon.
 */
fun Modifier.dualControl(
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    onFocus: () -> Unit = {},
    interactionSource: MutableInteractionSource
): Modifier {
    return this
        .onFocusChanged { if (it.isFocused) onFocus() }
        .onKeyEvent { keyEvent ->
            if (keyEvent.type == KeyEventType.KeyDown) {
                if (onLongClick != null && keyEvent.nativeKeyEvent.repeatCount >= 1) {
                    when (keyEvent.key) {
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                            onLongClick()
                            return@onKeyEvent true
                        }
                    }
                }
            } else if (keyEvent.type == KeyEventType.KeyUp) {
                when (keyEvent.key) {
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                        onClick()
                        return@onKeyEvent true
                    }
                }
            }
            false
        }
        .clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = onClick
        )
}
