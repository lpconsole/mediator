package com.lpconsole.mediator.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.lpconsole.mediator.data.local.dao.ChannelDao
import com.lpconsole.mediator.data.local.entities.ChannelEntity

import com.lpconsole.mediator.data.local.entities.ChannelFtsEntity

@Database(
    entities = [ChannelEntity::class, ChannelFtsEntity::class],
    version = 8,
    exportSchema = false
)
abstract class MediatorDatabase : RoomDatabase() {
    abstract fun channelDao(): ChannelDao
}
