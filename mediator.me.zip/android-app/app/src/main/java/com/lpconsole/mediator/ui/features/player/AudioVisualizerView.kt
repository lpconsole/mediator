package com.lpconsole.mediator.ui.features.player

import android.graphics.BlurMaskFilter
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.core.graphics.toColorInt

@Composable
fun AudioVisualizerView(amplitudes: FloatArray?, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.fillMaxSize().background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF06080E), Color(0xFF0C1018), Color(0xFF06080E))
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val centerY = height / 2f
            val wavePath = Path()
            buildSpectrumPath(wavePath, amplitudes, width, height, centerY)
            // 1. Outer Neon Glow (Safeguarded for hardware acceleration compatibility on TV GPU drivers)
            drawIntoCanvas { canvas ->
                try {
                    val nativePaint = Paint().apply {
                        isAntiAlias = true
                        style = Paint.Style.STROKE
                        strokeWidth = 20f
                        color = "#00F0FF".toColorInt()
                        maskFilter = BlurMaskFilter(24f, BlurMaskFilter.Blur.NORMAL)
                    }
                    canvas.nativeCanvas.drawPath(wavePath.asAndroidPath(), nativePaint)
                } catch (_: Exception) {
                    // Fallback for older TV box GPU drivers that do not support hardware-accelerated BlurMaskFilter
                }
            }
            // 2. Core Bright Spectrum Wave
            drawPath(
                path = wavePath,
                color = Color(0xFF70F2FF),
                style = Stroke(
                    width = 6f,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}

private fun buildSpectrumPath(
    path: Path,
    amplitudes: FloatArray?,
    width: Float,
    height: Float,
    centerY: Float
) {
    path.reset()
    if (amplitudes == null || amplitudes.isEmpty()) {
        path.moveTo(0f, centerY)
        path.lineTo(width, centerY)
        return
    }
    val count = amplitudes.size
    val maxAmplitude = height * 0.18f
    val dx = width / (count + 1)
    path.moveTo(0f, centerY)
    for (i in 0 until count - 1) {
        val x1 = (i + 1) * dx
        val x2 = (i + 2) * dx
        val y1 = centerY + (amplitudes[i] * maxAmplitude)
        val y2 = centerY + (amplitudes[i + 1] * maxAmplitude)
        val controlX = (x1 + x2) / 2f
        path.quadraticTo(
            x1 = controlX,
            y1 = y1,
            x2 = x2,
            y2 = (y1 + y2) / 2f
        )
    }
    path.lineTo(width, centerY)
}
