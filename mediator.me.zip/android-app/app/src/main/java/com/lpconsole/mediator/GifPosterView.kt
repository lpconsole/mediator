package com.lpconsole.mediator

import android.content.Context
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Movie
import android.graphics.drawable.Animatable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import android.widget.ImageView
import androidx.annotation.WorkerThread
import androidx.core.graphics.withTranslation
import androidx.core.view.isVisible
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class GifPosterView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ImageView(context, attrs, defStyleAttr) {
    private val ui = Handler(Looper.getMainLooper())

    private val fallbackFrameRunnable = Runnable {
        if (shouldAnimateFallback()) {
            invalidate()
        }
    }

    private var nativeDrawable: Drawable? = null
    @Suppress("DEPRECATION")
    private var fallbackMovie: Movie? = null
    private var movieStartMs = 0L
    private var nextFallbackFrameMs = 0L
    private var currentSource = ""
    private var pendingSource = ""
    private var generation = 0
    private var attached = false
    private var released = false

    init {
        isFocusable = false
        setWillNotDraw(false)
        scaleType = ScaleType.CENTER_CROP
    }

    fun setPosterFile(file: File?) {
        released = false
        val sourcePath = file?.absolutePath ?: ""
        if (sourcePath == currentSource && (nativeDrawable != null || fallbackMovie != null)) return
        pendingSource = sourcePath
        currentSource = sourcePath
        val requestGeneration = ++generation

        if (file == null || !file.exists() || file.length() <= 0L) {
            postDecodeResult(requestGeneration, sourcePath, null, null)
            return
        }

        try {
            decodeExecutor.execute {
                try {
                    if (released || requestGeneration != generation) return@execute
                    if (isGifTooLarge(file)) {
                        postDecodeResult(requestGeneration, sourcePath, null, null)
                        return@execute
                    }
                    val drawable = decodeNativeDrawable(file)
                    if (drawable != null) {
                        postDecodeResult(requestGeneration, sourcePath, drawable, null)
                    } else {
                        val movie = decodeFallbackMovie(file)
                        postDecodeResult(requestGeneration, sourcePath, null, movie)
                    }
                } catch (_: Throwable) {
                    postDecodeResult(requestGeneration, sourcePath, null, null)
                }
            }
        } catch (_: Throwable) {
            postDecodeResult(requestGeneration, sourcePath, null, null)
        }
    }

    fun release() {
        released = true
        ++generation
        clearPoster()
        ui.removeCallbacksAndMessages(null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        attached = true
        startAnimationIfNeeded()
    }

    override fun onDetachedFromWindow() {
        attached = false
        stopAnimation()
        release()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            startAnimationIfNeeded()
        } else {
            stopAnimation()
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) {
            startAnimationIfNeeded()
        } else {
            stopAnimation()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val movie = fallbackMovie
        if (movie == null) {
            super.onDraw(canvas)
            return
        }
        drawFallbackMovie(canvas, movie)
    }

    @Suppress("DEPRECATION")
    private fun postDecodeResult(requestGeneration: Int, source: String, drawable: Drawable?, movie: Movie?) {
        try {
            ui.post {
                if (released || requestGeneration != generation || source != currentSource) {
                    (drawable as? Animatable)?.let {
                        try { it.stop() } catch (_: Throwable) {}
                    }
                    return@post
                }
                pendingSource = ""
                clearPoster()
                nativeDrawable = drawable
                fallbackMovie = movie
                movieStartMs = 0L
                nextFallbackFrameMs = 0L
                setImageDrawable(nativeDrawable)
                startAnimationIfNeeded()
                invalidate()
            }
        } catch (_: Throwable) {
            (drawable as? Animatable)?.let {
                try { it.stop() } catch (_: Throwable) {}
            }
        }
    }

    private fun clearPoster() {
        stopAnimation()
        fallbackMovie = null
        val oldDrawable = nativeDrawable
        nativeDrawable = null
        movieStartMs = 0L
        nextFallbackFrameMs = 0L
        setImageDrawable(null)
        if (oldDrawable is Animatable) {
            try { oldDrawable.stop() } catch (_: Throwable) {}
        }
    }

    private fun startAnimationIfNeeded() {
        if (!attached || windowVisibility != VISIBLE || visibility != VISIBLE) return
        val drawable = nativeDrawable
        if (drawable is Animatable) {
            try {
                if (!drawable.isRunning) {
                    drawable.start()
                }
            } catch (_: Throwable) {}
        }
        if (fallbackMovie != null) {
            removeCallbacks(fallbackFrameRunnable)
            invalidate()
        }
    }

    private fun stopAnimation() {
        removeCallbacks(fallbackFrameRunnable)
        (nativeDrawable as? Animatable)?.let {
            try { it.stop() } catch (_: Throwable) {}
        }
    }

    private fun shouldAnimateFallback(): Boolean {
        return attached && fallbackMovie != null && windowVisibility == VISIBLE && isVisible
    }

    private fun isGifTooLarge(file: File?): Boolean {
        return file == null || !file.exists() || file.length() <= 0L || file.length() > MAX_GIF_BYTES
    }

    @WorkerThread
    private fun decodeNativeDrawable(file: File): Drawable? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
        return try {
            val source = ImageDecoder.createSource(file)
            ImageDecoder.decodeDrawable(source) { decoder, info, _ ->
                decoder.memorySizePolicy = ImageDecoder.MEMORY_POLICY_LOW_RAM
                val size = info.size
                val width = size.width.coerceAtLeast(1)
                val height = size.height.coerceAtLeast(1)
                val largestEdge = maxOf(width, height)
                if (largestEdge > MAX_DECODE_EDGE) {
                    val scale = MAX_DECODE_EDGE.toFloat() / largestEdge
                    decoder.setTargetSize(
                        (width * scale).toInt().coerceAtLeast(1),
                        (height * scale).toInt().coerceAtLeast(1)
                    )
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    @WorkerThread
    @Suppress("DEPRECATION")
    private fun decodeFallbackMovie(file: File): Movie? {
        return try {
            FileInputStream(file).use { input -> Movie.decodeStream(input) }
        } catch (_: Throwable) {
            null
        }
    }

    @Suppress("DEPRECATION")
    private fun drawFallbackMovie(canvas: Canvas, movie: Movie) {
        var duration = movie.duration()
        if (duration <= 0) duration = 1000
        val now = SystemClock.uptimeMillis()
        if (movieStartMs == 0L) movieStartMs = now
        movie.setTime(((now - movieStartMs) % duration).toInt())
        val scale = maxOf(
            width.toFloat() / movie.width().coerceAtLeast(1),
            height.toFloat() / movie.height().coerceAtLeast(1)
        )
        val scaledWidth = movie.width() * scale
        val scaledHeight = movie.height() * scale
        val dx = (width - scaledWidth) / 2f
        val dy = (height - scaledHeight) / 2f
        canvas.withTranslation(dx, dy) {
            canvas.scale(scale, scale)
            movie.draw(canvas, 0f, 0f)
        }
        nextFallbackFrameMs = now + FALLBACK_FRAME_DELAY_MS
        if (shouldAnimateFallback()) {
            postDelayed(fallbackFrameRunnable, maxOf(16L, nextFallbackFrameMs - SystemClock.uptimeMillis()))
        }
    }

    companion object {
        private const val MAX_GIF_BYTES = 25L * 1024 * 1024
        private const val FALLBACK_FRAME_DELAY_MS = 83L
        private const val MAX_DECODE_EDGE = 720

        private val decodeExecutor: ExecutorService = Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "gif-poster-decode").apply {
                isDaemon = true
                priority = Thread.NORM_PRIORITY - 1
            }
        }
    }
}
